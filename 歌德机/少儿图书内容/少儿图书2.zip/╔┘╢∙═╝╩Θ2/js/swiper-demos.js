/*
Author: Vladimir Kharlampidi, The iDangero.us
*/
document.createElement('header');
document.createElement('footer');
$(function(){
	$(".navUl  li").each(function(){
		var index=$(this).index();
		$(".navUl li").eq(0).addClass("act");
		$(this).click(function(){
			$(this).addClass("act").siblings().removeClass("act");
			//function(){$(this).css({display:"block"});
			//$(".wrapT").stop(true).eq(index).css({display:"block"});
			$(".wrapT").stop(true).eq(index).css({display:"block"}).fadeIn(function(){
				switch (index){
					case 0:
						$(function() {
							//Main Swiper
							var swiper = new Swiper('.swiper1', {
								pagination: '.pagination1',
								loop: false,
								paginationType: 'fraction',
								grabCursor: true
							});
							$('.pagination1 .swiper-pagination-switch').click(function(){
								swiper.swipeTo($(this).index())
							});
							var puzzleParams = {
								mode : "horizontal",
								speed : 300,
								ratio : 1
							}
						});
						break;
					case 1:
						$(function(){
							var swiperTwo = new Swiper('.swiper2', {
								pagination : '.pagination2',
								loop:false,
								paginationType : 'fraction',
								grabCursor: true
							});
							$('.pagination2 .swiper-pagination-switch').click(function(){
								swiper.swipeTo($(this).index())
							});
							var puzzleParams = {
								mode : "horizontal2",
								speed : 300,
								ratio : 1
							}
						});
						break;
					case 2:
						$(function(){
							var swiperTwo = new Swiper('.swiper3', {
								pagination : '.pagination3',
								loop:false,
								paginationType : 'fraction',
								grabCursor: true
							});
							$('.pagination3 .swiper-pagination-switch').click(function(){
								swiper.swipeTo($(this).index())
							});
							var puzzleParams = {
								mode : "horizontal3",
								speed : 300,
								ratio : 1
							}
						});
						break;
					case 3:
						$(function(){
							var swiperTwo = new Swiper('.swiper4', {
								pagination : '.pagination4',
								loop:false,
								paginationType : 'fraction',
								grabCursor: true
							});
							$('.pagination4 .swiper-pagination-switch').click(function(){
								swiper.swipeTo($(this).index())
							});
							var puzzleParams = {
								mode : "horizontal4",
								speed : 300,
								ratio : 1
							}
						});
						break;
					case 4:
						$(function(){
							var swiperTwo = new Swiper('.swiper5', {
								pagination : '.pagination5',
								loop:false,
								paginationType : 'fraction',
								grabCursor: true
							});
							$('.pagination5 .swiper-pagination-switch').click(function(){
								swiper.swipeTo($(this).index())
							});
							var puzzleParams = {
								mode : "horizontal5",
								speed : 300,
								ratio : 1
							}
						});
						break;
					case 5:
						$(function(){
							var swiperTwo = new Swiper('.swiper6', {
								pagination : '.pagination6',
								loop:false,
								paginationType : 'fraction',
								grabCursor: true
							});
							$('.pagination6 .swiper-pagination-switch').click(function(){
								swiper.swipeTo($(this).index())
							});
							var puzzleParams = {
								mode : "horizontal6",
								speed : 300,
								ratio : 1
							}
						});
						break;
					case 6:
						$(function(){
							var swiperTwo = new Swiper('.swiper7', {
								pagination : '.pagination7',
								loop:false,
								paginationType : 'fraction',
								grabCursor: true
							});
							$('.pagination7 .swiper-pagination-switch').click(function(){
								swiper.swipeTo($(this).index())
							});
							var puzzleParams = {
								mode : "horizontal7",
								speed : 300,
								ratio : 1
							}
						});
						break;
					default :
						break;
				}
			}).siblings().stop(true).hide();
			return false;
		})
	})
})

$(function(){
	var cygs='cygs';
	var gxjd='gxjd';
	var kpbk='kpbk';
	var kcwg='kcwg';
	var mrgs='mrgs';
	var youer='youer';
	var zwmz='zwmz';
	bookType("成语故事",cygs);
	bookType("国学经典",gxjd);
	bookType("科普百科",kpbk);
	bookType("昆虫王国",kcwg);
	bookType("名人故事",mrgs);
	bookType("幼儿",youer);
	bookType("中外名著",zwmz);
});
function bookType(bookType,typeId){
	var typeData=_api()[bookType];
	/*//获取当前url
	var url = window.location.href;
	//截取当前url路劲
	var strs = new Array();
	strs = url.split("/");
	//当前url路劲
	var _url = '';
	for(var i=0; i<(strs.length - 1);i++){
		_url = _url + strs[i] + '/';
	}
	var str='';
	for (var o in typeData) {
		 str='';
		var appId = typeData[o].appId;
		var app = typeData[o].app;
		var cover = typeData[o].cover;
		var intro = typeData[o].intro;
		var appName = typeData[o].appName;
		var author = typeData[o].author;
		//组成图书URL路径
		var app_url = _url + 'stores' + '/' + appId + '/' + app + '/' + 'assets' + '/' + 'www' + '/' + 'index.html';
		//图书封面URL
		var cover_url = _url + 'stores' + '/' + appId + '/' + 'cover' + '/' + cover;
		for(var i=0;i<typeData.length;i++){
			if(i%8 == 0){
				str+='<div class="swiper-slide" style="background: #f2f2f2">';
				str+='<ul class="type-book">';
			}
			(function(i){
				str+="<li>";
				str+='<a href="'+ app_url +'" >';
				str+='<img src="'+ cover_url +'">';
				str+='<p>'+typeData[i].appName+'</p>';
				str += '</a>';
				str+='</li>';
			})(i);
			if(i%8==7){
				str+='</ul>';
				str+='<div class="clearfix"> </div>';
				str+='</div>';
			}
		}
		if(typeData.length%8!=0){
			str+='</ul>';
			str+='<div class="clearfix"> </div>';
			str+='</div>';
		}

	}
	$('#'+typeId).html(str);*/
		var typeBookTemplete=Handlebars.compile($("#books-template").html());
		var len=typeData.length;
		var screenNum=Math.ceil(len/8);
		for(var i=0;i<screenNum;i++){
			$('#'+typeId).append('<div class="swiper-slide" style="background: #f2f2f2"><ul class="type-book'+typeId+i+'"></ul><div class="clearfix"></div></div>')
		}
		for(var j=0;j<screenNum;j++){
			$('.type-book'+typeId+j).html(typeBookTemplete(typeData.slice(j*8,(j+1)*8)));
		}
	}
$(function(){
	//Main Swiper
	var swiper = new Swiper('.swiper1', {
		pagination : '.pagination1',
		loop:false,
        paginationType : 'fraction',
		grabCursor: true
	});
	//Navigation arrows
    //Clickable pagination
    $('.pagination1 .swiper-pagination-switch').click(function(){
    	swiper.swipeTo($(this).index())
    });
	//Puzzle
	var puzzleParams = {
		mode : "horizontal",
		speed : 300,
		ratio : 1
	}
});




