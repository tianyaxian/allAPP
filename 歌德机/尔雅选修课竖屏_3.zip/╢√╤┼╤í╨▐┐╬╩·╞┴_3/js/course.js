
$(function () {
    var xksy = 'xksy';
    var xqjn = 'xqjn';
    var ztjy = 'ztjy';
    var dxxx = 'dxxx';
    var gkzs = 'gkzs';
    bookType("学科素养", xksy);
    bookType("兴趣技能", xqjn);
    bookType("专题教育", ztjy);
    bookType("大学先修", dxxx);
    bookType("高考知识点", gkzs);
});
function bookType(bookType, typeId) {
    var typeData = books.list[bookType];
    var str = '';
    for (var i = 0; i < typeData.length; i++) {
        var courseid = typeData[i].courseid;
        var courseName = typeData[i].courseName;
        var bigImgUrl = typeData[i].bigImgUrl;
        var keySpeakPosition = typeData[i].keySpeakPosition;
        var keySpeakUnivercity = typeData[i].keySpeakUnivercity;
        if (i % 12 == 0) {
            str += '<div class="swiper-slide">';
        }
        (function (i) {
            str+='<div class="source"><a><input type="hidden" value="'+courseid+'"><dl><dt><img src="'+bigImgUrl+'"></dt><dd class="sourceNameOne">'+courseName+'</dd><dd class="speakName">'+keySpeakPosition+' （'+keySpeakUnivercity+'）</dd> </dl></a></div>';
        })(i);
        if (i % 12 ==11 ) {
            str += '<div class="clearfix"> </div>';
            str += '</div>';
        }
    }
    if (typeData.length % 12 != 0) {
        str += '<div class="clearfix"> </div>';
        str += '</div>';
    }
    $('#' + typeId).html(str);
    var swiperLength1=$(".swiper-wrapper").children(".swiper-slide").length+2;
    $("div.swiper-wrapper").width(1760*swiperLength1+'px');
}
function createSwiper(index){
    var swiper = new Swiper('.swiper'+index, {
        pagination: '.pagination'+index,
        paginationClickable: true,
        startSlide: 1,
        lazyLoading : true,
        paginationBulletRender: function (index, className) {
            return '<span class="' + className + '">'+(index+1)+'</span>';
        }
    });
    return swiper
}
$(function () {
    var swiper = new Swiper('.swiper1', {
        pagination: '.pagination1',
        paginationClickable: true,
        lazyLoading : true,
        startSlide: 1,
        paginationBulletRender: function (index, className) {
            return '<span class="' + className + '">' + (index + 1) + '</span>';
        }
    });
    var swiper1,swiper2,swiper3,swiper4,swiper5;
    $(".tab_menu  li").each(function () {
        var index = $(this).index();
        $(".wrapT").eq(0).show();
        $(".tab_menu li").eq(0).addClass("act");
        $(this).click(function () {
            $(".triggle img").css({"margin-left": 100 + index * 210 + "px"});
            $(this).addClass("selected").siblings().removeClass("selected");
            $(".wrapT").stop(true).eq(index).show().siblings().stop(true).hide();
            if(index === 0 && swiper1 === undefined && swiper === undefined) {
                swiper1 = createSwiper(1);
            } else if(index === 1 && swiper2 === undefined) {
                swiper2 = createSwiper(2);
            }
            else if(index === 2 && swiper3 === undefined) {
                swiper3 = createSwiper(3);
            }
            else if(index === 3 && swiper4 === undefined) {
                swiper4 = createSwiper(4);
            }
            else if(index === 4 && swiper5 === undefined) {
                swiper5 = createSwiper(5);
            }
            return false;
        })
    })
});
function gainVideoList(id) {
    var listStr = "";
    for (var key in books.list) {
        for (var key1 in books.list[key]) {
            var titt = books.list[key];
            if (titt[key1].courseid == id) {

                listStr += "<div class='contentL'>";
                listStr += "<div class='source'>";
                listStr += "<img src='" + titt[key1].bigImgUrl + "' class='img1'>";
                listStr += "<div class='sourceName'>";
                listStr += "<h1 title='" + titt[key1].courseName + "'>" + titt[key1].courseName + "</h1>";
                listStr += "<span>" + titt[key1].keySpeakName + "</span>";
                listStr += "</div>";

                listStr += "<div id='zvideo' style='width:650px;height:385px;overflow: hidden;background: white;border-radius: 10px 0 0 0'>";
                listStr += "<div id='myvideo' width='650' height='385'>";
                listStr += " <div id='videoShow' class='videoShow'><div id='a1'></div></div>";

                listStr += "</div>";
                listStr += " </div>";
                listStr += " <div id='zvideo_play'> </div>";

                listStr += "</div>";

                listStr += "<div class='speakMes'>";
                listStr += "<img src='QR_codes/" + titt[key1].courseid + ".png'>";
                listStr += "<h3 title='" + titt[key1].courseName + "'>" + titt[key1].courseName + "</h3>";
                listStr += " <p>主讲人：" + titt[key1].keySpeakName + "</p>";
                listStr += " <p>主讲人单位：" + titt[key1].keySpeakUnivercity + "</p>";
                listStr += " <p>主讲人信息：</p>";
                listStr += " <p class='speakIntro'>" + titt[key1].keySpeakIntroduce + "</p>";
                for (var i = 0; i < titt[key1].courseIntroduce.length; i++) {
                    listStr += " <p class='speakIntro'>" + titt[key1].courseIntroduce[i] + "</p>";
                }
                listStr += "</div>";
                listStr += "</div>";

                listStr += "<div class='contentR'>";
                listStr +="<div class='wrapDiv'>"
                listStr += "<h2>课程章节</h2>";
                var tittle = titt[key1].courseChapter;
                for (var key2 in tittle) {
                    var m = 1;
                    for (var key3 in tittle[key2]) {
                        listStr += "<div class='catalog'>";
                        listStr += "<div class='firstCatalog'>";
                        listStr += "<div class='aurl'>";
                        listStr += "<div class='numOne'>" + m + "</div>";
                        listStr += "<div class='tittleOne'>" + key3 + "</div>";
                        listStr += "</div>";
                        listStr += " <div class='clear'></div>";
                        listStr += "</div>";
                        listStr += "<ul>";
                        var tittleOne = tittle[key2][key3];
                        for (var key4 in tittleOne) {
                            listStr += "<li>";
                            listStr += "<div class='aurl'>";
                            listStr += "<div class='num'>" + tittleOne[key4].chapterNum + "</div>";
                            listStr += "<div class='tittle'>" + tittleOne[key4].chapterName + "</div>";
                            listStr += "</div>";
                            listStr += "</li>";
                        }
                        listStr += "</ul>";
                        listStr += "<div class='clear'></div>";
                        listStr += "</div>";
                        m++;
                    }
                }
                listStr +="</div>";
                $(".contentOne").html(listStr);
                var url1=titt[key1].videoUrl;
                if (url1 === "") {
                    $("#zvideo_play").hide();
                } else {
                    $("#zvideo_play").show();
                }

                $("#zvideo_play").click(function () {
                    $(this).hide();
                    $("#zvideo").show();
                    $(".source .img1").hide();
                    var flashvars = {
                        f:url1,
                        c:0,
                        p:1,
                        e:1,
                        wh:'3:2'
                    };
                    var video = [url1 + '->video/mp4'];
                    var support = ['all'];
                    CKobject.embedHTML5('a1', 'ckplayer_a1', 650, 366, video, flashvars, support);
                });

                $("#close1").click(function () {
                    $("#a1").empty();
                    $(".wrapCon").hide();
                    $(".maskLayer").hide();
                    return false;
                });
            }
        }
    }


}