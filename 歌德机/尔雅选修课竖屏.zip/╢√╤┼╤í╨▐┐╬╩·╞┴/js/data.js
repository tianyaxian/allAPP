/**
 * Created by jichu on 2016/5/11.
 */
// JavaScript Document
//var urlswf = "http://122.112.16.227:81/rs/resfile/word/";
var urlswf = "resfile/word/";
var swfType=".swf?gedecache=1";
var imgType=".gif?gedecache=1";
var books = {
    "list":[
        {
            "courseid":"86635396",
            "courseName":"“特立独行”精神之作品赏析",
            "typeOne":"学科素养",
            "typeTwo":"文学与经典",
            "keySpeakName":"周志强",
            "keySpeakUnivercity":"南开大学",
            "keySpeakPosition":"教授",
            "keySpeakIntroduce":"周志强：文学博士，南开大学文学院教授，博士生导师，南开大学东方审美文化研究中心主任、南开大学语文教育研究中心主任；《中国图书评论》执行主编；中华女子学院特聘教授；明道大学客座教授（台湾）；2012年入选“教育部新世纪优秀人才支持计划”、天津市第三批宣传文化“五个一批” 人才，中国大学语文学会、中国文艺理论学会员；南开大学国家级精品课程大学语文主讲教师；北京师大文学院国家级精品课程文学概论主讲教师。曾任《语文报•大学语文专版》执行主编、《中国图书评论》学术现场与读书一问栏目主持人。目前主要从事文艺美学、中国大众文化与中国现当代文学研究。",
            "courseIntroduce":["纵使侮辱与损害还在各种场合时常发生，但也有更多人为包括民主、道德、公民社会、权利在内的各种美好东西大声呐喊。在每个人的内心深处，依然有一种力量，驱使我们在纷繁的世界中“特立独行”，这不仅是知识分子的使命，也应该是时代公民的精神。王小波的《一只特立独行的猪》，从人的天性及人的权利角度启示我们，我们需要的是“特立独行”及某种必要的距离——显然，最能担负起这个职责的，就是知识分子。《天才梦》中的张爱玲、《金岳霖先生》中的金岳霖、《清华大学王观堂先生纪念碑铭》中的王国维，无不是具有独特性格，独立人格，追求自由精神的文人。南开大学周志强教授以幽默风趣的“脱口秀”形式，打破我们习以为常的思维惯式，挣脱狭隘的陈旧知识的束缚，从大历史、大文学的角度，带领我们重新审视文学、认识生活、了解自我。"],
            "bigImgUrl":"http://p.ananas.chaoxing.com/star3/733_434c/53cc725ea310a822ad8b37f2.jpg",
            "videoUrl":"http://s1.ananas.chaoxing.com/video/2d/56a816a6e4b0e85354bd0ed2/sd.mp4",
            "courseChapter":[
                {
                   "《一只特立独行的猪》":[
                       {"chapterNum":"1.1", "chapterName":"学习指导"},
                       {"chapterNum":"1.2", "chapterName":"王小波及其创作"},
                       {"chapterNum":"1.3", "chapterName":"韦小宝叙事大法"},
                       {"chapterNum":"1.4", "chapterName":"语法意义与修辞意义的分裂"},
                       {"chapterNum":"1.5", "chapterName":"叙事姿态与叙事内容的分裂"},
                       {"chapterNum":"1.6", "chapterName":"特立独行"},
                       {"chapterNum":"1.7", "chapterName":"形象的分析"},
                       {"chapterNum":"1.8", "chapterName":"走近人物"},
                       {"chapterNum":"1.9", "chapterName":"扩展阅读"}
                   ],
                    "《天才梦》":[
                        {"chapterNum":"2.1", "chapterName":"学习指导"},
                        {"chapterNum":"2.2", "chapterName":"张爱玲及其创作"},
                        {"chapterNum":"2.3", "chapterName":"张爱玲的爱情、时代与家庭"},
                        {"chapterNum":"2.4", "chapterName":"张爱玲与《十八春》"},
                        {"chapterNum":"2.5", "chapterName":"《天才梦》作品阅读"},
                        {"chapterNum":"2.6", "chapterName":"《天才梦》作品分析"},
                        {"chapterNum":"2.7", "chapterName":"《倾城之恋》作品赏析"},
                        {"chapterNum":"2.8", "chapterName":"走近人物"},
                        {"chapterNum":"2.9", "chapterName":"扩展阅读"}
                    ],
                    "《金岳霖先生》": [
                            {"chapterNum":"3.1", "chapterName":"学习指导"},
                            {"chapterNum":"3.2", "chapterName":"汪曾祺及其创作"},
                            {"chapterNum":"3.3", "chapterName":"《金岳霖先生》作品阅读"},
                            {"chapterNum":"3.4", "chapterName":"《金岳霖先生》人物分析及“闲笔”"},
                            {"chapterNum":"3.5", "chapterName":"《跑警报》作品赏析"},
                            {"chapterNum":"3.6", "chapterName":"走近人物"},
                            {"chapterNum":"3.7", "chapterName":"扩展阅读"}
                        ],
                    "《清华大学王观堂先生纪念碑铭》":[
                        {"chapterNum":"4.1", "chapterName":"学习指导"},
                        {"chapterNum":"4.2", "chapterName":"陈寅恪及其作品"},
                        {"chapterNum":"4.3", "chapterName":"王国维之死与文人“自杀”现象"},
                        {"chapterNum":"4.4", "chapterName":"作品阅读"},
                        {"chapterNum":"4.5", "chapterName":"王国维的治学精神"},
                        {"chapterNum":"4.6", "chapterName":"陈寅恪的治学精神"},
                        {"chapterNum":"4.7", "chapterName":"作品特色"},
                        {"chapterNum":"4.8", "chapterName":"走近人物"},
                        {"chapterNum":"4.9", "chapterName":"扩展阅读"}
                    ],
                    "《语言的功能与陷阱》":[
                        {"chapterNum":"5.1", "chapterName":"学习指导"},
                        {"chapterNum":"5.2", "chapterName":"王蒙及其作品介绍"},
                        {"chapterNum":"5.3", "chapterName":"绪论及语言的功能"},
                        {"chapterNum":"5.4", "chapterName":"语言的陷阱"},
                        {"chapterNum":"5.5", "chapterName":"语言与社会生活"},
                        {"chapterNum":"5.6", "chapterName":"如何认识语言的功能（一）"},
                        {"chapterNum":"5.7", "chapterName":"如何认识语言的功能（二）"},
                        {"chapterNum":"5.8", "chapterName":"演讲的原则与举例"},
                        {"chapterNum":"5.9", "chapterName":"走近人物"},
                        {"chapterNum":"5.10", "chapterName":"扩展阅读"}
                    ]
                }
            ]
        },
        {
            "courseid":"86359711",
            "courseName":"唐代小说经典导读",
            "typeOne":"学科素养",
            "typeTwo":"文学与经典",
            "keySpeakName":"董乃斌",
            "keySpeakUnivercity":"上海大学",
            "keySpeakPosition":"教授",
            "keySpeakIntroduce":"上海大学教授，博导。主要学术专长是中国古典文学,研究方向为唐宋文学。1963年毕业于复旦大学中文系。1981年毕业于中国社会科学院研究生院文学系，长期在中国社会科学院文学研究所工作，任研究员、该所副所长，兼该院研究生院教授、博士生导师。现为上海大学文学院教授，该校学报（社会科学版）主编。任中国唐代文学学会副会长、中国李商隐研究会会长、中国闻一多研究会副会长、上海古典文学学会副会长等。国家“有突出贡献中青年专家”。享受国家特殊津贴。著有《中国神话故事论集》《李福清论中国古典小说》《关公传说与三国演义》《三国演义与民间文学传统》等。",
            "courseIntroduce":["唐代商品经济的发展，都市的繁荣，民众文化生活的需求，促进了汉族小说文学的发展。唐人小说渊源于魏晋六朝的搜奇志怪，故被称为传奇。传奇是一种传录奇闻的文体，实际上是已具规模的小说。唐代传奇不仅数量很多，而且内容精彩，故事动人，文辞华丽，有些作品确实具有高度的文学价值，唐代许多著名的文学家都写过传奇。唐传奇的出现，标志着我国文言小说发展到了成熟的阶段。初、盛唐时代为传奇的发轫期，也是由六朝志怪到唐传奇的过渡阶段。中唐时代是传奇发展的兴盛期，名家名作蔚起，唐传奇的大部分作品都产生在这个时期。唐代传奇为后代小说奠定了基础，可说是历代文学中重要的一环。本课程通过对唐代传奇作品的阅读与分析，带领大家走进唐代传奇的世界，感受小说中反映出来的唐朝的社会习俗、生活方式与流行思想，深刻认识唐代文人的“婚”“宦”理想。"],
            "bigImgUrl":"http://p.ananas.chaoxing.com/star3/733_434c/5667a534498ed8a4294c9b18.png",
            "videoUrl":"http://s1.ananas.chaoxing.com/video/0c/5689c8e8e4b0e85354b309d1/sd.mp4",
            "courseChapter":[
                {
                    "两篇早期的唐传奇《古镜记》《补江总白猿传》":[
                        {"chapterNum":"1.1", "chapterName":"学习指导"},
                        {"chapterNum":"1.2", "chapterName":"两篇早期的唐传奇《古镜记》《补江总白猿传》（上）"},
                        {"chapterNum":"1.3", "chapterName":"两篇早期的唐传奇《古镜记》《补江总白猿传》（下）"},
                        {"chapterNum":"1.4", "chapterName":"走近作家"},
                        {"chapterNum":"1.5", "chapterName":"扩展阅读"}
                    ],
                    "张鷟与《游仙窟》":[
                        {"chapterNum":"2.1", "chapterName":"学习指导"},
                        {"chapterNum":"2.2", "chapterName":"张鷟与《游仙窟》（上）"},
                        {"chapterNum":"2.3", "chapterName":"张鷟与《游仙窟》（下）"},
                        {"chapterNum":"2.4", "chapterName":"走近作家"},
                        {"chapterNum":"2.5", "chapterName":"扩展阅读"}
                    ],
                    "人生如梦的感叹": [
                        {"chapterNum":"3.1", "chapterName":"学习指导"},
                        {"chapterNum":"3.2", "chapterName":"人生如梦的感叹（上）"},
                        {"chapterNum":"3.3", "chapterName":"人生如梦的感叹（下）"},
                        {"chapterNum":"3.4", "chapterName":"走近作家"},
                        {"chapterNum":"3.5", "chapterName":"扩展阅读"}
                    ],
                    "狂热的爱情追求":[
                        {"chapterNum":"4.1", "chapterName":"学习指导"},
                        {"chapterNum":"4.2", "chapterName":"狂热的爱情追求（上）"},
                        {"chapterNum":"4.3", "chapterName":"狂热的爱情追求（下）"},
                        {"chapterNum":"4.4", "chapterName":"走近作家"},
                        {"chapterNum":"4.5", "chapterName":"扩展阅读"}
                    ],
                    "龙女、狐女、虎女的故事":[
                        {"chapterNum":"5.1", "chapterName":"学习指导"},
                        {"chapterNum":"5.2", "chapterName":"龙女、狐女、虎女的故事（上）"},
                        {"chapterNum":"5.3", "chapterName":"龙女、狐女、虎女的故事（下）"},
                        {"chapterNum":"5.4", "chapterName":"走近作家"},
                        {"chapterNum":"5.5", "chapterName":"扩展阅读"}
                    ],
                    "唐代士人生活的悲喜剧":[
                        {"chapterNum":"6.1", "chapterName":"学习指导"},
                        {"chapterNum":"6.2", "chapterName":"唐代士人生活的悲喜剧（上）"},
                        {"chapterNum":"6.3", "chapterName":"唐代士人生活的悲喜剧（下）"},
                        {"chapterNum":"6.4", "chapterName":"走近作家"},
                        {"chapterNum":"6.5", "chapterName":"扩展阅读"}
                    ],
                    "侠女故事":[
                        {"chapterNum":"7.1", "chapterName":"学习指导"},
                        {"chapterNum":"7.2", "chapterName":"侠女故事（上）"},
                        {"chapterNum":"7.3", "chapterName":"侠女故事（下）"},
                        {"chapterNum":"7.4", "chapterName":"走近作家"},
                        {"chapterNum":"7.5", "chapterName":"扩展阅读"}
                    ],
                    "以《长恨歌传》为代表的历史小说":[
                        {"chapterNum":"8.1", "chapterName":"学习指导"},
                        {"chapterNum":"8.2", "chapterName":"以《长恨歌传》为代表的历史小说（上）"},
                        {"chapterNum":"8.3", "chapterName":"以《长恨歌传》为代表的历史小说（下）"},
                        {"chapterNum":"8.4", "chapterName":"走近作家"},
                        {"chapterNum":"8.5", "chapterName":"扩展阅读"}
                    ],
                    "寓意深刻的变形记":[
                        {"chapterNum":"9.1", "chapterName":"学习指导"},
                        {"chapterNum":"9.2", "chapterName":"寓意深刻的变形记（上）"},
                        {"chapterNum":"9.3", "chapterName":"寓意深刻的变形记（下）"},
                        {"chapterNum":"9.4", "chapterName":"走近作家"},
                        {"chapterNum":"9.5", "chapterName":"扩展阅读"}
                    ]
                }
            ]
        },
        {
            "courseid":"86347763",
            "courseName":"俄国文学经典导读（上）",
            "typeOne":"学科素养",
            "typeTwo":"文学与经典",
            "keySpeakName":"李毓榛",
            "keySpeakUnivercity":"北京大学",
            "keySpeakPosition":"教授",
            "keySpeakIntroduce":"李毓榛：北京大学教授。1960年毕业于北京大学俄罗斯语言文学系。历任北京大学俄语系教师及俄语系文学教研室主任、副教授，莫斯科大学亚非学院副教授，北京大学俄语系主任、教授、博士生导师。中国俄罗斯文学学会理事，中国翻译工作者协会理事，普希金研究会副会长，中俄比较文学学会秘书长。80年代开始发表作品。1990年加入中国作家协会。讲有《俄罗斯文学》等课程，译著《白天的星星》、《我这一代人眼里的斯大林》(合译)、《甜蜜的女人》(合译)、《西班牙日记》、《父与子》(合译)，论文《赫拉普钦科的历史诗学体系》、《肖洛霍夫的小说诗学及其影响》等。",
            "courseIntroduce":["俄罗斯文学是世界文学里最优秀、最震撼的现象之一。无论是它辉煌的黄金时代，多彩的白银时代，还是进步的社会主义时代、当下的转型时期，俄罗斯文学的天空总是星光灿烂，佳作满天，光彩照人，惊艳四方。俄罗斯经典小说代表着俄罗斯文学在世界文学里的高度，令人仰止。它塑造了大量深刻、震撼的经典人物，如可叹的小人物，可悲的多余人，可敬的革命者，形成了独特的深邃的创作主张，比如“生活的教科书”，“心灵的辩证法”，“含泪的笑”。本课程通过对普希金、果戈理、托尔斯泰、高尔基、萧洛霍夫等作家的经典作品的导读，为大家展开了一幅多彩的俄罗斯民族风情历史画卷。"],
            "bigImgUrl":"http://p.ananas.chaoxing.com/star3/733_434c/5642da67498e2c1aa71417e0.jpg",
            "videoUrl":"http://s1.ananas.chaoxing.com/video/d4/56833139e4b0e85354b05d34/sd.mp4",
            "courseChapter":[
                {
                    "普希金和俄罗斯诗歌":[
                        {"chapterNum":"1.1", "chapterName":"学习指导"},
                        {"chapterNum":"1.2", "chapterName":"普希金和俄罗斯诗歌（上）"},
                        {"chapterNum":"1.3", "chapterName":"普希金和俄罗斯诗歌（下）"},
                        {"chapterNum":"1.4", "chapterName":"走近作家"},
                        {"chapterNum":"1.5", "chapterName":"扩展阅读"}
                    ],
                    "果戈理和他的《死魂灵》":[
                        {"chapterNum":"2.1", "chapterName":"学习指导"},
                        {"chapterNum":"2.2", "chapterName":"果戈理和他的《死魂灵》（上）"},
                        {"chapterNum":"2.3", "chapterName":"果戈理和他的《死魂灵》（下）"},
                        {"chapterNum":"2.4", "chapterName":"走近作家"},
                        {"chapterNum":"2.5", "chapterName":"扩展阅读"}
                    ],
                    "俄罗斯文学中的“多余人": [
                        {"chapterNum":"3.1", "chapterName":"学习指导"},
                        {"chapterNum":"3.2", "chapterName":"俄罗斯文学中的“多余人”（上）"},
                        {"chapterNum":"3.3", "chapterName":"俄罗斯文学中的“多余人”（下）"},
                        {"chapterNum":"3.4", "chapterName":"走近作家"},
                        {"chapterNum":"3.5", "chapterName":"扩展阅读"}
                    ],
                    "托尔斯泰《战争与和平》":[
                        {"chapterNum":"4.1", "chapterName":"学习指导"},
                        {"chapterNum":"4.2", "chapterName":"托尔斯泰的生平与创作情况"},
                        {"chapterNum":"4.3", "chapterName":"《战争与和平》：概述"},
                        {"chapterNum":"4.4", "chapterName":"《战争与和平》：三次战役"},
                        {"chapterNum":"4.5", "chapterName":"《战争与和平》：四个家族"},
                        {"chapterNum":"4.6", "chapterName":"《战争与和平》：安德烈·保尔康斯基"},
                        {"chapterNum":"4.7", "chapterName":"《战争与和平》：皮埃尔·别祖霍夫"},
                        {"chapterNum":"4.8", "chapterName":"《战争与和平》：娜塔莎·罗斯托娃"},
                        {"chapterNum":"4.9", "chapterName":"走近作家"},
                        {"chapterNum":"4.10", "chapterName":"扩展阅读"}
                    ],
                    "俄罗斯文学中的“小人物”":[
                        {"chapterNum":"5.1", "chapterName":"学习指导"},
                        {"chapterNum":"5.2", "chapterName":"俄罗斯文学中的“小人物”（上）"},
                        {"chapterNum":"5.3", "chapterName":"俄罗斯文学中的“小人物”（中）"},
                        {"chapterNum":"5.4", "chapterName":"俄罗斯文学中的“小人物”（下）"},
                        {"chapterNum":"5.5", "chapterName":"走近作家"},
                        {"chapterNum":"5.6", "chapterName":"扩展阅读"}
                    ],
                    "俄罗斯诗歌的“白银时代”":[
                        {"chapterNum":"6.1", "chapterName":"学习指导"},
                        {"chapterNum":"6.2", "chapterName":"俄罗斯诗歌的“白银时代”（上）"},
                        {"chapterNum":"6.3", "chapterName":"俄罗斯诗歌的“白银时代”（下）"},
                        {"chapterNum":"6.4", "chapterName":"走近作家"},
                        {"chapterNum":"6.5", "chapterName":"扩展阅读"}
                    ],
                    "从生活底层奋斗出来的伟大作家——高尔基":[
                        {"chapterNum":"7.1", "chapterName":"学习指导"},
                        {"chapterNum":"7.2", "chapterName":"从生活底层奋斗出来的伟大作家——高尔基（上）"},
                        {"chapterNum":"7.3", "chapterName":"从生活底层奋斗出来的伟大作家——高尔基（下）"},
                        {"chapterNum":"7.4", "chapterName":"走近作家"},
                        {"chapterNum":"7.5", "chapterName":"扩展阅读"}
                    ]
                }
            ]
        },
        {
            "courseid":"81864042",
            "courseName":"《人间词话》导读",
            "typeOne":"学科素养",
            "typeTwo":"文学与经典",
            "keySpeakName":"叶嘉莹",
            "keySpeakUnivercity":"南开大学",
            "keySpeakPosition":"教授",
            "keySpeakIntroduce":"叶嘉莹，号迦陵。1924年7月出生于北京的一个书香世家，南开大学中华古典文化研究所所长，博士生导师，加拿大籍中国古典文学专家，加拿大皇家学会院士，曾任台湾大学教授、美国哈佛大学、密歇根大学及哥伦比亚大学客座教授、加拿大不列颠哥伦比亚大学终身教授，并受聘于国内多所大学客座教授及中国社会科学院文学所名誉研究员。2012年6月被聘任为中央文史研究馆馆员。",
            "courseIntroduce":["中华诗词滥觞于先秦，是有节奏、有韵律并富有感情色彩的一种语言艺术形式，也是世界上最古老、最基本的文学形式。严格的格律韵脚、凝练的语言、绵密的章法、充沛的情感以及丰富的意象是中华诗词美之所在，诗词是中华数千年社会文化生活的缩影。 本课通过对王国维《人间词话》的解读，进一步深入到《人间词话》问世百年的词学反思。 南开大学知名教授叶嘉莹，以独特的视角向你展示这一世界文学艺术的瑰宝。"],
            "bigImgUrl":"http://p.ananas.chaoxing.com/star2/2014-06/733_434/1402653716460etoel.jpg",
            "videoUrl":"http://s1.ananas.chaoxing.com/video/78/553767e0e4b0199d270494ad/sd.mp4",
            "courseChapter":[
                {
                    "《人间词话》导读":[
                        {"chapterNum":"1.1", "chapterName":"叶嘉莹的诗词人生"},
                        {"chapterNum":"1.2", "chapterName":"王国维其人"},
                        {"chapterNum":"1.3", "chapterName":"初探王国维“境界说”"},
                        {"chapterNum":"1.4", "chapterName":"关于“境界”内涵的争议"},
                        {"chapterNum":"1.5", "chapterName":"张惠言与王国维的词学思想比较"},
                        {"chapterNum":"1.6", "chapterName":"王国维对词的解读"},
                        {"chapterNum":"1.7", "chapterName":"词与诗的差异"},
                        {"chapterNum":"1.8", "chapterName":"词的美感特质"},
                        {"chapterNum":"1.9", "chapterName":"王国维对欧阳修、秦观之词的解读"},
                        {"chapterNum":"1.10", "chapterName":"词之高下的判断标准"},
                        {"chapterNum":"1.11", "chapterName":"“词别是一家”与“词自是一家”"},
                        {"chapterNum":"1.12", "chapterName":"王国维的“三境界”说"},
                        {"chapterNum":"1.13", "chapterName":"读词之法与孔子说诗的传统"},
                        {"chapterNum":"1.14", "chapterName":"联想式的读词之法"},
                        {"chapterNum":"1.15", "chapterName":"联想与文化语码"},
                        {"chapterNum":"1.16", "chapterName":"赏析苏轼之词"},
                        {"chapterNum":"1.17", "chapterName":"词之发展历程"},
                        {"chapterNum":"1.18", "chapterName":"赏析辛弃疾之词"},
                        {"chapterNum":"1.19", "chapterName":"辛弃疾词的特点"},
                        {"chapterNum":"1.20", "chapterName":"词的演变"},
                        {"chapterNum":"1.21", "chapterName":"赏析周邦彦之词"},
                        {"chapterNum":"1.22", "chapterName":"周邦彦对长调的突破"}
                    ]
                }
            ]
        },
        {
            "courseid":"81785380",
            "courseName":"《水浒传》鉴赏",
            "typeOne":"学科素养",
            "typeTwo":"文学与经典",
            "keySpeakName":"侯会",
            "keySpeakUnivercity":"首都师范大学",
            "keySpeakPosition":"教授",
            "keySpeakIntroduce":"侯会，男，1949年出生。首都师范大学文学院教授。主要从事明清小说教学、研究。兼任中国《西游记》研究会理事，北京文艺学会《水浒》研究会副会长，中国社会科学院文学研究所《中国古代小说研究》编委。主要专著：《水浒源流新证》（华文出版社，2002年版）《食货金瓶梅》（广西师范大学出版社，2007年版）《中华文学五千年（古代部分）》（中国青年出版社，1996年版）《世界文学五千年》（中国青年出版社，1993年版，台湾洪叶出版公司，1997年版）此外，曾在中央电视台“百家讲坛”及中国现代文学馆做小说专题演讲多场。",
            "courseIntroduce":["《水浒传》，是中国四大名著之一，全书描写北宋末年以宋江为首的108位好汉在梁山起义，以及聚义之后接受招安、四处征战的故事。《水浒传》也是汉语文学中最具备史诗特征的作品之一，是中国历史上最早用白话文写成的章回小说之一。版本众多，流传极广，脍炙人口，对中国乃至东亚的叙事文学都有极其深远的影响。《水浒传》是一部以描写古代农民起义为题材的长篇小说。它形象地描绘了农民起义从发生、发展直至失败的全过程，深刻揭示了起义的社会根源，满腔热情地歌颂了起义英雄的反抗斗争和他们的社会理想，也具体揭示了起义失败的内在历史原因。"],
            "bigImgUrl":"http://p.ananas.chaoxing.com/star3/733_434c/55fb811c498ed981287e5d67.jpg",
            "videoUrl":"http://s1.ananas.chaoxing.com/video/93/55377074e4b0199d2704968d/sd.mp4",
            "courseChapter":[
                {
                    "《水浒传》的主题思想":[
                        {"chapterNum":"1.1", "chapterName":"小说的主题分析"},
                        {"chapterNum":"1.2", "chapterName":"如何看待“忠义”主题"},
                        {"chapterNum":"1.3", "chapterName":"《水浒传》是一部“愤书”与“快书”"},
                        {"chapterNum":"1.4", "chapterName":"《水浒传》的思想局限"}
                    ],
                    "《水浒传》的作者":[
                        {"chapterNum":"2.1", "chapterName":"《水浒传》的作者"}
                    ],
                    "《水浒传》的版本":[
                        {"chapterNum":"3.1", "chapterName":"《水浒传》的版本"}
                    ],
                    "《水浒传》人物之一——宋江":[
                        {"chapterNum":"4.1", "chapterName":"形象分析"},
                        {"chapterNum":"4.2", "chapterName":"矛盾性格的成因"}
                    ],
                    "《水浒传》人物之二——林冲":[{"chapterNum":"5.1", "chapterName":"隐忍与爆发"}],
                    "《水浒传》人物之三——杨志":[
                        {"chapterNum":"6.1", "chapterName":"末路英雄"}
                    ],
                    "《水浒传》人物之四——鲁智深":[{"chapterNum":"7.1", "chapterName":"豁达大度与广阔辽远"}],
                    "《水浒传》人物之五——武松":[{"chapterNum":"8.1", "chapterName":"仿若天神"}],
                    "《水浒传》的艺术成就":[
                        {"chapterNum":"9.1", "chapterName":"人物塑造"},
                        {"chapterNum":"9.2", "chapterName":"叙事艺术"},
                        {"chapterNum":"9.3", "chapterName":"语言特色"},
                        {"chapterNum":"9.4", "chapterName":"写作技巧"}
                    ],
                    "《水浒传》与小说群书的关系":[
                        {"chapterNum":"10.1", "chapterName":"《水浒传》与三国故事"},
                        {"chapterNum":"10.2", "chapterName":"《水浒传》与五代故事"},
                        {"chapterNum":"10.3", "chapterName":"《水浒传》与说岳故事"},
                        {"chapterNum":"10.4", "chapterName":"《水浒传》与其他话本故事"}
                    ],
                    "《水浒传》中的晚起情节":[
                        {"chapterNum":"11.1", "chapterName":"晚起情节的论证"},
                        {"chapterNum":"11.2", "chapterName":"关于公孙胜的谜团"}
                    ],
                    "《水浒传》的宗教色彩与文体类型":[
                        {"chapterNum":"12.1", "chapterName":"《水浒传》的宗教色彩"},
                        {"chapterNum":"12.2", "chapterName":"《水浒传》的文体类型"}
                    ]
                }
            ]
        },
        {
            "courseid":"81784483",
            "courseName":"《论语》导读之学而、为政篇",
            "typeOne":"学科素养",
            "typeTwo":"文学与经典",
            "keySpeakName":"刘强",
            "keySpeakUnivercity":"同济大学",
            "keySpeakPosition":"副教授",
            "keySpeakIntroduce":"刘强，笔名留白，1970年10月生于河南正阳，同济大学副教授、人文学院中文系副主任、中国古代文学专业硕士生、博士生导师、人文学者，曾任台湾东华大学中文系客座教授（2011）。上海师范大学文学硕士（2001）（师从曹旭教授），复旦大学文学博士（2004）（师从骆玉明教授），主要从事中国古代文学教学及研究，兼杂文、散文创作。在《学术月刊》、《复旦学报》、《文史知识》、《古籍研究》、《中华艺术论丛》、《上海师大学报》、《阴山学刊》、《同济大学学报》发表学术论文20余篇。已出版《世说新语会评》、《古诗今读》、《世说新语今读》、《有刺的书囊》、《竹林七贤》、《惊艳台湾》、《世说学引论》、《有竹居新评世说新语》等。2010年10月曾在CCTV10的“百家讲坛”节目中主讲《竹林七贤》。",
            "courseIntroduce":["《论语》是一部意蕴丰富的书，是儒家至高无上的典籍。本门课程从礼到仁，从君子之德到忠恕之道，从入世到出世，刘强教授深入浅出，将先贤智慧展现的淋漓尽致，旨在用现代视角解读传世经典，帮助学生扫除理解障碍，从而引起文化共鸣与思考。"],
            "bigImgUrl":"http://p.ananas.chaoxing.com/star3/733_434c/55fd4794498ed981287e826c.jpg",
            "videoUrl":"",
            "courseChapter":[
                {
                    "绪论":[
                        {"chapterNum":"1.1", "chapterName":"绪论（一）：钱学森之问"},
                        {"chapterNum":"1.2", "chapterName":"绪论（二）：孔子其人"},
                        {"chapterNum":"1.3", "chapterName":"绪论（三）：孔子“自传”"},
                        {"chapterNum":"1.4", "chapterName":"绪论（四）：孔子周游列国及《论语》的诞生"}
                    ],
                    "学而篇":[
                        {"chapterNum":"2.1", "chapterName":"学而篇（一）：孔子的学习观"},
                        {"chapterNum":"2.2", "chapterName":"学而篇（二）：君子之道"},
                        {"chapterNum":"2.3", "chapterName":"学而篇（三）：治国之道"},
                        {"chapterNum":"2.4", "chapterName":"学而篇（四）：厚德载道"},
                        {"chapterNum":"2.5", "chapterName":"学而篇（五）：子禽问子贡"},
                        {"chapterNum":"2.6", "chapterName":"学而篇（六）：孔子的教育观"}
                    ],
                    "为政篇":[
                        {"chapterNum":"3.1", "chapterName":"为政篇（一）：德治与诗教"},
                        {"chapterNum":"3.2", "chapterName":"为政篇（二）：孔子的孝道观之孟懿子问孝"},
                        {"chapterNum":"3.3", "chapterName":"为政篇（三）：孔子的孝道观之孟武伯、子游问孝"},
                        {"chapterNum":"3.4", "chapterName":"为政篇（四）：孔子的孝道观之子夏问孝"},
                        {"chapterNum":"3.5", "chapterName":"为政篇（五）：孔子眼中的君子形象"},
                        {"chapterNum":"3.6", "chapterName":"为政篇（六）：为己之学"},
                        {"chapterNum":"3.7", "chapterName":"为政篇（七）：为官之道"},
                        {"chapterNum":"3.8", "chapterName":"为政篇（八）：儒家学说"}
                    ]
                }
            ]
        },
        {
            "courseid":"81796065",
            "courseName":"《红楼梦》鉴赏",
            "typeOne":"学科素养",
            "typeTwo":"文学与经典",
            "keySpeakName":"蔡义江",
            "keySpeakUnivercity":"中国红楼梦学会",
            "keySpeakPosition":"教师",
            "keySpeakIntroduce":"在中国古典文学特别是唐宋诗词、红学研究方面成绩显著。出版主要著作有:《红楼梦诗词曲赋评注》、《论红楼梦佚稿》、《红楼梦》校注、《蔡义江论红楼梦》等,其专著和论文曾多次获国家、省、市社科优秀成果奖。",
            "courseIntroduce":["《红楼梦》，中国古典四大名著之首，清代作家曹雪芹创作的章回体长篇小说。早期仅有前八十回抄本流传，八十回后部分未完成且原稿佚失。《红楼梦》是一部具有世界影响力的人情小说作品，举世公认的中国古典小说巅峰之作，中国封建社会的百科全书，传统文化的集大成者。小说以贾、史、王、薛四大家族的兴衰为背景，以贾府的家庭琐事、闺阁闲情为中心，以贾宝玉、林黛玉、薛宝钗的爱情婚姻故事为主线，描写了以贾宝玉和金陵十二钗为中心的正邪两赋有情人的人性美和悲剧美，歌颂追求光明的叛逆人物，通过叛逆者的悲剧命运预见封建社会必然走向灭亡，揭示出封建末世的危机。"],
            "bigImgUrl":"http://p.ananas.chaoxing.com/star3/733_434c/55fb81ae498ed981287e5d7a.jpg",
            "videoUrl":"http://s1.ananas.chaoxing.com/video/93/55377074e4b0199d2704968d/sd.mp4",
            "courseChapter":[
                {
                    "《红楼梦》的文学特殊性":[
                        {"chapterNum":"1.1", "chapterName":"手法的突破"},
                        {"chapterNum":"1.2", "chapterName":"结构的完整"}
                    ],
                    "脂评、脂本与脂砚斋批书人":[
                        {"chapterNum":"2.1", "chapterName":"《红楼梦》的版本"},
                        {"chapterNum":"2.2", "chapterName":"《红楼梦》的批书人"}
                    ],
                    "索隐派与自传说的谬误":[
                        {"chapterNum":"3.1", "chapterName":"索引派的谬误"},
                        {"chapterNum":"3.2", "chapterName":"自传说的谬误"}
                    ],
                    "石头撰书与甄贾宝玉":[
                        {"chapterNum":"4.1", "chapterName":"石头撰书的含义"},
                        {"chapterNum":"4.2", "chapterName":"甄贾宝玉的寓意"}
                    ],
                    "眼泪还债与黛玉之死":[
                        {"chapterNum":"5.1", "chapterName":"眼泪还债的含义"},
                        {"chapterNum":"5.2", "chapterName":"黛玉之死"}
                    ],
                    "褒贬纷争的薛宝钗":[
                        {"chapterNum":"6.1", "chapterName":"贬宝钗的议论出现及其原因"},
                        {"chapterNum":"6.2", "chapterName":"解析对宝钗的误读"}
                    ],
                    "对史湘云由来已久的误解":[
                        {"chapterNum":"7.1", "chapterName":"史湘云的身世与性格"},
                        {"chapterNum":"7.2", "chapterName":"分析对史湘云的误解"}
                    ],
                    "王熙凤、巧姐、刘姥姥":[
                        {"chapterNum":"8.1", "chapterName":"王熙凤的是非褒贬"},
                        {"chapterNum":"8.2", "chapterName":"刘姥姥与巧姐的关系"}
                    ],
                    "幸运的晴雯和不幸的袭人":[
                        {"chapterNum":"9.1", "chapterName":"完整的晴雯形象"},
                        {"chapterNum":"9.2", "chapterName":"被续作扭曲的袭人"}
                    ],
                    "小说中的诗词曲赋":[
                        {"chapterNum":"10.1", "chapterName":"曹雪芹的诗才"},
                        {"chapterNum":"10.2", "chapterName":"诗词曲赋与小说创作的关系"}
                    ],
                    "续作与原著的落差":[
                        {"chapterNum":"11.1", "chapterName":"续作与原著的关系"},
                        {"chapterNum":"11.2", "chapterName":"续作与原著的落差"}
                    ],
                    "红楼梦还是良缘梦及改编等问题":[
                        {"chapterNum":"12.1", "chapterName":"《红楼梦》非良缘梦"},
                        {"chapterNum":"12.2", "chapterName":"《红楼梦》的各种版本演绎"}
                    ]
                }
            ]
        },
        {
            "courseid":"81785624",
            "courseName":"《三国演义》鉴赏",
            "typeOne":"学科素养",
            "typeTwo":"文学与经典",
            "keySpeakName":"段启明",
            "keySpeakUnivercity":"首都师范大学",
            "keySpeakPosition":"教授",
            "keySpeakIntroduce":"段启明，首都师范大学教授，博导。研究方向为元明清戏曲小说；著有《红楼梦艺术论》、《西厢论稿》、《罗贯中与三国演义》等。",
            "courseIntroduce":["《三国演义》是中国第一部长篇章回体历史演义小说，以描写东汉末年的战争为主，反映了魏、蜀、吴三个政治集团之间的政治和军事斗争。《三国演义》是中国古典四大名著之一，全名为《三国志通俗演义》。作者是元末明初小说家罗贯中，是中国第一部长篇章回体历史演义小说。描写了从东汉末年到西晋初年之间近105年的历史风云。全书反映了三国时代的政治军事斗争，反映了三国时代各类社会矛盾的转化，并概括了这一时代的历史巨变，塑造了一批批叱咤风云的三国英雄人物，让现代的人民，感受到三国英雄的人物的特点。"],
            "bigImgUrl":"http://p.ananas.chaoxing.com/star3/733_434c/55fb801de4b040cfea183035.jpg",
            "videoUrl":"http://s1.ananas.chaoxing.com/video/93/55377074e4b0199d2704968d/sd.mp4",
            "courseChapter":[
                {
                    "《三国演义》 引言":[
                        {"chapterNum":"1.1", "chapterName":"《三国演义》的渊源及语言特色"},
                        {"chapterNum":"1.2", "chapterName":"《三国演义》产生的背景与影响"}
                    ],
                    "《三国演义》的成书过程":[
                        {"chapterNum":"2.1", "chapterName":"三国的历史概述及史料渊源"},
                        {"chapterNum":"2.2", "chapterName":"裴松之注《三国志》"},
                        {"chapterNum":"2.3", "chapterName":"三国故事流传对《三国演义》成书的影响"}
                    ],
                    "《三国演义》的作者、版本及全书概况":[
                        {"chapterNum":"3.1", "chapterName":"作者考证"},
                        {"chapterNum":"3.2", "chapterName":"版本及全书概况"}
                    ],
                    "《三国演义》的思想":[
                        {"chapterNum":"4.1", "chapterName":"对主题的不同理解"},
                        {"chapterNum":"4.2", "chapterName":"对“正统观念”的解释"},
                        {"chapterNum":"4.3", "chapterName":"“正统观念”与作者政治理想的关系"},
                        {"chapterNum":"4.4", "chapterName":"人物形象与作者政治理想的关系"},
                        {"chapterNum":"4.5", "chapterName":"君臣关系与作者政治理想的关系"}
                    ],
                    "说曹操":[
                        {"chapterNum":"5.1", "chapterName":"历史形象与文学形象"},
                        {"chapterNum":"5.2", "chapterName":"形象总体特点"},
                        {"chapterNum":"5.3", "chapterName":"对待人才的特点"},
                        {"chapterNum":"5.4", "chapterName":"为曹操“翻案”"}
                    ],
                    "论诸葛":[
                        {"chapterNum":"6.1", "chapterName":"论及诸葛亮的三种指向"},
                        {"chapterNum":"6.2", "chapterName":"三顾茅庐"},
                        {"chapterNum":"6.3", "chapterName":"舌战群儒"},
                        {"chapterNum":"6.4", "chapterName":"六出祁山"}
                    ],
                    "话关羽":[
                        {"chapterNum":"7.1", "chapterName":"关羽的“义”"},
                        {"chapterNum":"7.2", "chapterName":"关羽的英雄形象"},
                        {"chapterNum":"7.3", "chapterName":"关羽的性格悲剧"},
                        {"chapterNum":"7.4", "chapterName":"关羽形象的价值与意义"}
                    ],
                    "东吴才俊":[
                        {"chapterNum":"8.1", "chapterName":"人才济济江东才俊"},
                        {"chapterNum":"8.2", "chapterName":"罗贯中对历史人物贬抑的原因"}
                    ],
                    "三国演义的艺术":[
                        {"chapterNum":"9.1", "chapterName":"历史小说的典范"},
                        {"chapterNum":"9.2", "chapterName":"战争描写"},
                        {"chapterNum":"9.3", "chapterName":"语言艺术"},
                        {"chapterNum":"9.4", "chapterName":"悲剧情怀"}
                    ]
                }
            ]
        },
        {
            "courseid":"81785617",
            "courseName":"《西游记》鉴赏",
            "typeOne":"学科素养",
            "typeTwo":"文学与经典",
            "keySpeakName":"杨俊",
            "keySpeakUnivercity":"南京特殊教育师范学院",
            "keySpeakPosition":"教授",
            "keySpeakIntroduce":"杨俊，南京特殊教育师范学院，教授，本科，学士，主讲公共关系学、演讲与口才、中国文学和西游记鉴赏等课程，在《学术月刊》、《明清小说研究》、《光明日报》等核心报刊发表论文20余篇，论著有《西游新论》、《心解论经》等，主编国家职业教育十二五规划教材《新型实用公共关系教程》等多部，获得省级教学成果一等奖、二等奖和三等奖等多项。",
            "courseIntroduce":["《西游记》是中国古代第一部浪漫主义的长篇神魔小说。本门课程内容丰富，包括从故事诞生的前世今生到古今流传的影响演变，从降妖伏魔的英明神武到取经之路的坎坷艰辛。这本巨著在杨俊教授的讲述中显得生动而详实，全方位解读名著，引导学生走近艺术丰碑，思考人生之路。"],
            "bigImgUrl":"http://p.ananas.chaoxing.com/star3/733_434c/55fb8267498ed981287e5d83.jpg",
            "videoUrl":"",
            "courseChapter":[
                {
                    "《西游记》的诞生":[{"chapterNum":"1.1", "chapterName":"《西游记》的诞生"}],
                    "《西游记》的主题":[
                        {"chapterNum":"2.1", "chapterName":"《西游记》的主题之争"},
                        {"chapterNum":"2.2", "chapterName":"《西游记》的主题思想内涵"}
                    ],
                    "《西游记》的人物":[
                        {"chapterNum":"3.1", "chapterName":"《西游记》的人物：孙悟空"},
                        {"chapterNum":"3.2", "chapterName":"《西游记》的人物：猪八戒（上）"},
                        {"chapterNum":"3.3", "chapterName":"《西游记》的人物：猪八戒（下）"},
                        {"chapterNum":"3.4", "chapterName":"《西游记》的人物：唐僧"},
                        {"chapterNum":"3.5", "chapterName":"《西游记》的人物：沙悟净"},
                        {"chapterNum":"3.6", "chapterName":"《西游记》的人物：如来佛祖、观世音菩萨"},
                        {"chapterNum":"3.7", "chapterName":"《西游记》的人物：太白金星"},
                        {"chapterNum":"3.8", "chapterName":"《西游记》的人物：白龙马、太上老君"},
                        {"chapterNum":"3.9", "chapterName":"《西游记》的人物：四个家庭类型"},
                        {"chapterNum":"3.10", "chapterName":"《西游记》的人物：牛魔王"},
                        {"chapterNum":"3.11", "chapterName":"《西游记》的人物：牛魔王的法宝"},
                        {"chapterNum":"3.12", "chapterName":"《西游记》的人物：女性形象（上）"},
                        {"chapterNum":"3.13", "chapterName":"《西游记》的人物：女性形象（下）"}
                    ],
                    "《西游记》的艺术":[{"chapterNum":"4.1", "chapterName":"《西游记》的艺术"}],
                    "《西游记》的影响":[{"chapterNum":"5.1", "chapterName":"《西游记》的影响"}]
                }
            ]
        },
        {
            "courseid":"81782683",
            "courseName":"《论语》导读之八佾、里仁、公冶长篇",
            "typeOne":"学科素养",
            "typeTwo":"文学与经典",
            "keySpeakName":"刘强",
            "keySpeakUnivercity":"同济大学",
            "keySpeakPosition":"副教授",
            "keySpeakIntroduce":"刘强，笔名留白，1970年10月生于河南正阳，同济大学副教授、人文学院中文系副主任、中国古代文学专业硕士生、博士生导师、人文学者，曾任台湾东华大学中文系客座教授（2011）。上海师范大学文学硕士（2001）（师从曹旭教授），复旦大学文学博士（2004）（师从骆玉明教授），主要从事中国古代文学教学及研究，兼杂文、散文创作。在《学术月刊》、《复旦学报》、《文史知识》、《古籍研究》、《中华艺术论丛》、《上海师大学报》、《阴山学刊》、《同济大学学报》发表学术论文20余篇。已出版《世说新语会评》、《古诗今读》、《世说新语今读》、《有刺的书囊》、《竹林七贤》、《惊艳台湾》、《世说学引论》、《有竹居新评世说新语》等。2010年10月曾在CCTV10的“百家讲坛”节目中主讲《竹林七贤》。",
            "courseIntroduce":["《论语》是一部意蕴丰富的书，是儒家至高无上的典籍。本门课程从礼到仁，从君子之德到忠恕之道，从入世到出世，刘强教授深入浅出，将先贤智慧展现的淋漓尽致，旨在用现代视角解读传世经典，帮助学生扫除理解障碍，从而引起文化共鸣与思考。"],
            "bigImgUrl":"http://p.ananas.chaoxing.com/star3/733_434c/55fd47c6e4b040cfea1867d4.jpg",
            "videoUrl":"",
            "courseChapter":[
                {
                    "八佾里仁篇":[
                        {"chapterNum":"1.1", "chapterName":"八佾里仁篇（一）：孔子论“礼之本”"},
                        {"chapterNum":"1.2", "chapterName":"八佾里仁篇（二）：孔子论君子之道"},
                        {"chapterNum":"1.3", "chapterName":"八佾里仁篇（三）：仁、礼之关系"},
                        {"chapterNum":"1.4", "chapterName":"八佾里仁篇（四）：孔子论祭礼（上）"},
                        {"chapterNum":"1.5", "chapterName":"八佾里仁篇（五）：孔子论祭礼（下）"},
                        {"chapterNum":"1.6", "chapterName":"八佾里仁篇（六）：孔子论君臣之道"},
                        {"chapterNum":"1.7", "chapterName":"八佾里仁篇（七）：孔子论为君之道"},
                        {"chapterNum":"1.8", "chapterName":"八佾里仁篇（八）：孔子论为臣之道"},
                        {"chapterNum":"1.9", "chapterName":"八佾里仁篇（九）：孔子论仁德（上）"},
                        {"chapterNum":"1.10", "chapterName":"八佾里仁篇（十）：孔子论仁德（下）"},
                        {"chapterNum":"1.11", "chapterName":"八佾里仁篇（十一）：义礼之辨"},
                        {"chapterNum":"1.12", "chapterName":"八佾里仁篇（十二）：义利之辨"},
                        {"chapterNum":"1.13", "chapterName":"八佾里仁篇（十三）：名实之辩"},
                        {"chapterNum":"1.14", "chapterName":"八佾里仁篇（十四）：夫子之道"},
                        {"chapterNum":"1.15", "chapterName":"八佾里仁篇（十五）：言行之辨"}
                    ],
                    "公冶长篇":[
                        {"chapterNum":"2.1", "chapterName":"公冶长篇（一）：君子之德（上）"},
                        {"chapterNum":"2.2", "chapterName":"公冶长篇（二）：君子之德（下）"},
                        {"chapterNum":"2.3", "chapterName":"公冶长篇（三）：孔子对学生的评价（上）"},
                        {"chapterNum":"2.4", "chapterName":"公冶长篇（四）：孔子对学生的评价（下）"},
                        {"chapterNum":"2.5", "chapterName":"公冶长篇（五）：知行合一"},
                        {"chapterNum":"2.6", "chapterName":"公冶长篇（六）：孔子对各国名臣的评价"},
                        {"chapterNum":"2.7", "chapterName":"公冶长篇（七）：孔子论直"},
                        {"chapterNum":"2.8", "chapterName":"公冶长篇（八）：孔子论理想志向"}
                    ]
                }
            ]
        },
        {
            "courseid":"81785636",
            "courseName":"《论语》导读之雍也、述而、泰伯篇",
            "typeOne":"学科素养",
            "typeTwo":"文学与经典",
            "keySpeakName":"刘强",
            "keySpeakUnivercity":"同济大学",
            "keySpeakPosition":"副教授",
            "keySpeakIntroduce":"刘强，笔名留白，1970年10月生于河南正阳，同济大学副教授、人文学院中文系副主任、中国古代文学专业硕士生、博士生导师、人文学者，曾任台湾东华大学中文系客座教授（2011）。上海师范大学文学硕士（2001）（师从曹旭教授），复旦大学文学博士（2004）（师从骆玉明教授），主要从事中国古代文学教学及研究，兼杂文、散文创作。在《学术月刊》、《复旦学报》、《文史知识》、《古籍研究》、《中华艺术论丛》、《上海师大学报》、《阴山学刊》、《同济大学学报》发表学术论文20余篇。已出版《世说新语会评》、《古诗今读》、《世说新语今读》、《有刺的书囊》、《竹林七贤》、《惊艳台湾》、《世说学引论》、《有竹居新评世说新语》等。2010年10月曾在CCTV10的“百家讲坛”节目中主讲《竹林七贤》。",
            "courseIntroduce":["《论语》是一部意蕴丰富的书，是儒家至高无上的典籍。本门课程从礼到仁，从君子之德到忠恕之道，从入世到出世，刘强教授深入浅出，将先贤智慧展现的淋漓尽致，旨在用现代视角解读传世经典，帮助学生扫除理解障碍，从而引起文化共鸣与思考。"],
            "bigImgUrl":"http://p.ananas.chaoxing.com/star3/733_434c/55fd4828498ed981287e8274.jpg",
            "videoUrl":"",
            "courseChapter":[
                {
                    "雍也篇":[
                        {"chapterNum":"1.1", "chapterName":"雍也篇（一）：孔门弟子"},
                        {"chapterNum":"1.2", "chapterName":"雍也篇（二）：论从政"},
                        {"chapterNum":"1.3", "chapterName":"雍也篇（三）：孔颜乐处"},
                        {"chapterNum":"1.4", "chapterName":"雍也篇（四）：君子儒与小人儒"},
                        {"chapterNum":"1.5", "chapterName":"雍也篇（五）：文质之辨"},
                        {"chapterNum":"1.6", "chapterName":"雍也篇（六）：孔子论知"},
                        {"chapterNum":"1.7", "chapterName":"雍也篇（七）：孔子答樊迟、宰我之问"},
                        {"chapterNum":"1.8", "chapterName":"雍也篇 （八）：中庸之道"}
                    ],
                    "述而篇":[
                        {"chapterNum":"2.1", "chapterName":"述而篇（一）：孔子的教育观"},
                        {"chapterNum":"2.2", "chapterName":"述而篇（二）：孔子的教学方法"},
                        {"chapterNum":"2.3", "chapterName":"述而篇（三）：子之三慎"},
                        {"chapterNum":"2.4", "chapterName":"述而篇（四）：孔子的自我追求"},
                        {"chapterNum":"2.5", "chapterName":"述而篇（五）：孔子的人生观"},
                        {"chapterNum":"2.6", "chapterName":"述而篇（六）：子之四教"},
                        {"chapterNum":"2.7", "chapterName":"述而篇（七）：知行合一"},
                        {"chapterNum":"2.8", "chapterName":"述而篇（八）：生活中的孔子"},
                        {"chapterNum":"2.9", "chapterName":"述而篇（九）：致中和之道"}
                    ],
                    "泰伯篇":[
                        {"chapterNum":"3.1", "chapterName":"泰伯篇（一）：泰伯之贤"},
                        {"chapterNum":"3.2", "chapterName":"泰伯篇（二）：曾子之学"},
                        {"chapterNum":"3.3", "chapterName":"泰伯篇（三）：孔子的为政思想"},
                        {"chapterNum":"3.4", "chapterName":"泰伯篇（四）：孔子的出世思想"},
                        {"chapterNum":"3.5", "chapterName":"泰伯篇（五）：孔子的入世思想"}
                    ]
                }
            ]
        },
        {
            "courseid":"81806818",
            "courseName":"《道德经》导读",
            "typeOne":"学科素养",
            "typeTwo":"文学与经典",
            "keySpeakName":"陈怡",
            "keySpeakUnivercity":"东南大学",
            "keySpeakPosition":"教授",
            "keySpeakIntroduce":"研究领域，电力系统的安全稳定分析和高等教育学。论文与著作：出版教材的教材有《电力系统》（东南大学出版社出版）、十五规划教材《电力系统分析》（电力工业出版社）、《老子》《论语》今读（高等教育出版社）。在《中国高等教育》、《中国大学教学》、《江苏高教》、《高等工程教育研究》等刊物上发表论文数十篇。荣誉与奖励：1997年国家级优秀教学成果二等奖1项（排名第1），2001年国家级优秀教学成果二等奖2项（一项排名第1，一项排名第2），2005年国家级优秀教学成果二等奖1项（排名第1），2007年江苏省优秀教学成果特等奖（排名第2）。江苏省高等教育学会高等教育科研优秀成果二等奖1项、三等奖2项、东南大学校级优秀工作者2次、宝钢教学优秀奖1次。",
            "courseIntroduce":["《道德经》，又称《老子》、《老子五千文》，是中国古代重要的哲学著作之一，它文约义丰，涵盖哲学、伦理学、政治学、军事学等诸多学科，其内容博大精深、玄奥无极、涵盖百家、包容万象，被后人尊奉为治国、齐家、修身、为学的宝典。这部被誉为“万经之王”的神奇宝典，对中国古老的哲学、科学、政治、宗教等产生了深远的影响，全面地体现了古代中国人的一种世界观和人生观，无论对中华民族性格的铸成，还是对政治的统一与稳定，都起了不可估量的作用。本课力图用现代的观点加以诠释，所解读的精典篇章，都是关于如何做人的至理名言，对于我们如何提高自身修养意义重大，同时激起我们对中华文化的深厚兴趣。"],
            "bigImgUrl":"http://p.ananas.chaoxing.com/star3/733_434c/55f90871498ed981287e296f.jpg",
            "videoUrl":"",
            "courseChapter":[
                {
                    "道经":[
                        {"chapterNum":"1.1", "chapterName":"道经（一）"},
                        {"chapterNum":"1.2", "chapterName":"道经（二）"},
                        {"chapterNum":"1.3", "chapterName":"道经（三）"},
                        {"chapterNum":"1.4", "chapterName":"道经（四）"},
                        {"chapterNum":"1.5", "chapterName":"道经（五）"},
                        {"chapterNum":"1.6", "chapterName":"道经（六）"},
                        {"chapterNum":"1.7", "chapterName":"道经（七）"},
                        {"chapterNum":"1.8", "chapterName":"道经（八）"},
                        {"chapterNum":"1.9", "chapterName":"道经（九）"},
                        {"chapterNum":"1.10", "chapterName":"道经（十）"},
                        {"chapterNum":"1.11", "chapterName":"道经（十一）"},
                        {"chapterNum":"1.12", "chapterName":"道经（十二）"},
                        {"chapterNum":"1.13", "chapterName":"道经（十三）"},
                        {"chapterNum":"1.14", "chapterName":"道经（十四）"}
                    ],
                    "道经及德经":[
                        {"chapterNum":"2.1", "chapterName":"道经及德经（一）"},
                        {"chapterNum":"2.2", "chapterName":"道经及德经（二）"}
                    ],
                    "德经":[
                        {"chapterNum":"3.1", "chapterName":"德经（一）"},
                        {"chapterNum":"3.2", "chapterName":"德经（二）"},
                        {"chapterNum":"3.3", "chapterName":"德经（三）"},
                        {"chapterNum":"3.4", "chapterName":"德经（四）"},
                        {"chapterNum":"3.5", "chapterName":"德经（五）"},
                        {"chapterNum":"3.6", "chapterName":"德经（六）"},
                        {"chapterNum":"3.7", "chapterName":"德经（七）"}
                    ]
                }
            ]
        },
        {
            "courseid":"87086562",
            "courseName":"中国现代文学名家名作",
            "typeOne":"学科素养",
            "typeTwo":"文学与经典",
            "keySpeakName":"温儒敏",
            "keySpeakUnivercity":"北京大学",
            "keySpeakPosition":"教授",
            "keySpeakIntroduce":"温儒敏，北京大学中文系主任，教授，博士生导师，北大语文教育研究所所长。兼任中国现代文学研究会会长，国务院学位委员会学科评议组成员，国家哲学社会科学规划评审委员，《中国现代文学研究丛刊》主编。",
            "courseIntroduce":["中国现代文学在中国社会内部发生历史性变化的条件下，广泛接受外国文学影响而形成的新的文学。中国现代作家用现代语言表达现代思想，在艺术形式与表现手法上对传统文学进行了革新，构成中国文化长廊上灿烂的一笔。这门课程能够引导学生走近名家名作，在阅读经典的过程中理解社会的发展与变革，自觉肩负起传承中国先进思想文化的使命。"],
            "bigImgUrl":"http://p.ananas.chaoxing.com/star3/733_434c/569c880fe4b0e85354b951cc.jpg",
            "videoUrl":"http://s1.ananas.chaoxing.com/video/4c/56af1724498e69718a42cc77/sd.mp4",
            "courseChapter":[
                {
                    "鲁迅的《呐喊》《彷徨》":[
                        {"chapterNum":"1.1", "chapterName":"鲁迅的《呐喊》《彷徨》（一）：《呐喊》《彷徨》的底色和基调"},
                        {"chapterNum":"1.2", "chapterName":"鲁迅的《呐喊》《彷徨》（二）：《呐喊》《彷徨》的取材与写作意象"},
                        {"chapterNum":"1.3", "chapterName":"鲁迅的《呐喊》《彷徨》（三）：鲁迅小说的艺术格局和语言创新"},
                        {"chapterNum":"1.4", "chapterName":"鲁迅的《呐喊》《彷徨》（四）：鲁迅小说的风格构成"},
                        {"chapterNum":"1.5", "chapterName":"鲁迅的《呐喊》《彷徨》（五）：爱情题材的小说"}
                    ],
                    "五四时期的小说":[
                        {"chapterNum":"2.1", "chapterName":"五四时期的小说（一）：冰心与“冰心体”"},
                        {"chapterNum":"2.2", "chapterName":"五四时期的小说（二）：庐隐、许地山、叶圣陶"},
                        {"chapterNum":"2.3", "chapterName":"五四时期的小说（一）：五四时期的小说（三）：乡土小说流派"},
                        {"chapterNum":"2.4", "chapterName":"五四时期的小说（四）：郁达夫与“自叙传”小说"}
                    ],
                    "茅盾的《蚀》与《子夜》":[
                        {"chapterNum":"3.1", "chapterName":"茅盾的《蚀》与《子夜》（一）：特色与成就"},
                        {"chapterNum":"3.2", "chapterName":"茅盾的《蚀》与《子夜》（二）：人物系列"},
                        {"chapterNum":"3.3", "chapterName":"茅盾的《蚀》与《子夜》（三）：《子夜》细读"},
                        {"chapterNum":"3.4", "chapterName":"茅盾的《蚀》与《子夜》（四）：吴荪甫形象"},
                        {"chapterNum":"3.5", "chapterName":"茅盾的《蚀》与《子夜》（五）：《子夜》的艺术"}
                    ],
                    "巴金的《家》与《寒夜》":[
                        {"chapterNum":"4.1", "chapterName":"巴金的《家》与《寒夜》（一）：巴金与无政府主义"},
                        {"chapterNum":"4.2", "chapterName":"巴金的《家》与《寒夜》（二）：巴金的前期作品"},
                        {"chapterNum":"4.3", "chapterName":"巴金的《家》与《寒夜》（三）：《家》的人物形象"},
                        {"chapterNum":"4.4", "chapterName":"巴金的《家》与《寒夜》（四）：巴金的写作风格"},
                        {"chapterNum":"4.5", "chapterName":"巴金的《家》与《寒夜》（五）：《寒夜》细读"}
                    ],
                    "老舍《骆驼祥子》与《四世同堂》":[
                        {"chapterNum":"5.1", "chapterName":"老舍《骆驼祥子》与《四世同堂》（一）：老舍的特色与贡献"},
                        {"chapterNum":"5.2", "chapterName":"老舍《骆驼祥子》与《四世同堂》（二）：底层市民生活"},
                        {"chapterNum":"5.3", "chapterName":"老舍《骆驼祥子》与《四世同堂》（三）：城市文明病与人性关系"},
                        {"chapterNum":"5.4", "chapterName":"老舍《骆驼祥子》与《四世同堂》（四）：虎妞形象"}
                    ],
                    "沈从文的《边城》等小说":[
                        {"chapterNum":"6.1", "chapterName":"沈从文的《边城》等小说（一）：湘西题材"},
                        {"chapterNum":"6.2", "chapterName":"沈从文的《边城》等小说（二）：沈从文的写作意图"},
                        {"chapterNum":"6.3", "chapterName":"沈从文的《边城》等小说（三）：《边城》"},
                        {"chapterNum":"6.4", "chapterName":"沈从文的《边城》等小说（四）：沈从文的美学观"},
                        {"chapterNum":"6.5", "chapterName":"沈从文的《边城》等小说（五）：牧歌理想"}
                    ],
                    "三十年代小说":[
                        {"chapterNum":"7.1", "chapterName":"三十年代小说（一）：三十年代文学概述"},
                        {"chapterNum":"7.2", "chapterName":"三十年代小说（二）：《莎菲女士的日记》"},
                        {"chapterNum":"7.3", "chapterName":"三十年代小说（三）：萧红的创作"},
                        {"chapterNum":"7.4", "chapterName":"三十年代小说（四）：张恨水的创作"}
                    ],
                    "鲁迅的杂文":[
                        {"chapterNum":"8.1", "chapterName":"鲁迅的杂文（一）：鲁迅杂文概述"},
                        {"chapterNum":"8.2", "chapterName":"鲁迅的杂文（二）：鲁迅杂文的价值"},
                        {"chapterNum":"8.3", "chapterName":"鲁迅的杂文（三）：鲁迅杂文的鉴赏分析"},
                        {"chapterNum":"8.4", "chapterName":"鲁迅的杂文（四）：议论中的联想与形象化表达"},
                        {"chapterNum":"8.5", "chapterName":"鲁迅的杂文（五）：讽刺、幽默与曲笔"}
                    ],
                    "三四十年代散文":[
                        {"chapterNum":"9.1", "chapterName":"三四十年代散文（一）：三四十年代的散文概述"},
                        {"chapterNum":"9.2", "chapterName":"三四十年代散文（二）：林语堂与闲适散文"},
                        {"chapterNum":"9.3", "chapterName":"三四十年代散文（三）：独语与闲话"},
                        {"chapterNum":"9.4", "chapterName":"三四十年代散文（四）：三四十年代的散文作家"}
                    ],
                    "曹禺的《雷雨》":[
                        {"chapterNum":"10.1", "chapterName":"曹禺的《雷雨》（一）：话剧在中国的发展"},
                        {"chapterNum":"10.2", "chapterName":"曹禺的《雷雨》（二）：《雷雨》的特色"},
                        {"chapterNum":"10.3", "chapterName":"曹禺的《雷雨》（三）：周朴园形象"},
                        {"chapterNum":"10.4", "chapterName":"曹禺的《雷雨》（四）：繁漪形象"}
                    ],
                    "张爱玲与钱钟书":[
                        {"chapterNum":"11.1", "chapterName":"张爱玲与钱钟书（一）：张爱玲的创作"},
                        {"chapterNum":"11.2", "chapterName":"张爱玲与钱钟书（二）：《金锁记》"},
                        {"chapterNum":"11.3", "chapterName":"张爱玲与钱钟书（三）：钱钟书与《围城》"},
                        {"chapterNum":"11.4", "chapterName":"张爱玲与钱钟书（四）：《围城》的内涵和艺术成就"}
                    ],
                    "赵树理与解放区小说":[
                        {"chapterNum":"12.1", "chapterName":"赵树理与解放区小说（一）：孙犁的创作艺术"},
                        {"chapterNum":"12.2", "chapterName":"赵树理与解放区小说（二）：《太阳照在桑干河上》与《暴风骤雨》"},
                        {"chapterNum":"12.3", "chapterName":"赵树理与解放区小说（三）：赵树理的小说创作"},
                        {"chapterNum":"12.4", "chapterName":"赵树理与解放区小说（四）：问题小说"},
                        {"chapterNum":"12.4", "chapterName":"赵树理与解放区小说（五）：《白毛女》"}
                    ]

                }
            ]
        },
        {
            "courseid":"87727366",
            "courseName":"老舍文学作品导读",
            "typeOne":"学科素养",
            "typeTwo":"文学与经典",
            "keySpeakName":"温儒敏",
            "keySpeakUnivercity":"北京大学",
            "keySpeakPosition":"教授",
            "keySpeakIntroduce":"温儒敏，北京大学中文系主任，教授，博士生导师，北大语文教育研究所所长。兼任中国现代文学研究会会长，国务院学位委员会学科评议组成员，国家哲学社会科学规划评审委员，《中国现代文学研究丛刊》主编。",
            "courseIntroduce":["老舍是中国现代著名文学家、新中国第一个获得“人民艺术家”称号的作家。老舍的作品大多取材于市民生活，他善于描绘城市贫民的生活和命运，尤其擅长刻画浸透了封建宗法观念的保守落后的中下层市民。老舍的语言俗白精致，雅俗共赏，同样老舍的作品也追求幽默，一方面来自狄更斯等英国文学家的影响，另一方面也深深地打上了“北京市民文化”的烙印，形成了更内蕴的“京味”。", "本课程由三部分组成：北京大学温儒敏教授的《老舍骆驼祥子与四世同堂》，山东大学黄万华教授的《老舍研究》，中国社科院关纪新教授的《老舍与满族历史文化》。 本课程涉及到的老舍作品有小说《骆驼祥子》《四世同堂》《离婚》《月牙儿》《断魂枪》《二马》，散文《想北平》等。"],
            "bigImgUrl":"http://p.ananas.chaoxing.com/star3/733_434c/5705ccd1e4b0578413d07d4d.jpg",
            "videoUrl":"http://s1.ananas.chaoxing.com/video/4c/56af1724498e69718a42cc77/sd.mp4",
            "courseChapter":[
                {
                    "老舍《骆驼祥子》与《四世同堂》（主讲人：温儒敏）":[
                        {"chapterNum":"1.1", "chapterName":"学习指导"},
                        {"chapterNum":"1.2", "chapterName":"老舍作品的特色及贡献"},
                        {"chapterNum":"1.3", "chapterName":"老舍笔下的三类人物形象"},
                        {"chapterNum":"1.4", "chapterName":"《骆驼祥子》：城市文明病与人性关系"},
                        {"chapterNum":"1.5", "chapterName":"《骆驼祥子》：虎妞形象"},
                        {"chapterNum":"1.6", "chapterName":"走近作家"},
                        {"chapterNum":"1.7", "chapterName":"扩展阅读"}
                    ],
                    "京派文化影响下的文学—老舍（主讲人：黄万华）":[
                        {"chapterNum":"2.1", "chapterName":"老舍小说的世界性"},
                        {"chapterNum":"2.2", "chapterName":"老舍小说的乡土性"},
                        {"chapterNum":"2.3", "chapterName":"老舍创作的文化世界"},
                        {"chapterNum":"2.4", "chapterName":"老舍笔下的老派市民"},
                        {"chapterNum":"2.5", "chapterName":"老舍笔下的贫民与新派市民"},
                        {"chapterNum":"2.6", "chapterName":"京味幽默与口语化文学"},
                        {"chapterNum":"2.7", "chapterName":"配套教材"}
                    ],
                    "老舍与满族历史文化（主讲人：关纪新）":[
                        {"chapterNum":"3.1", "chapterName":"满族的家庭出身对老舍的人文模塑（一）"},
                        {"chapterNum":"3.2", "chapterName":"满族的家庭出身对老舍的人文模塑（二）"},
                        {"chapterNum":"3.3", "chapterName":"满族的家庭出身对老舍的人文模塑（三）"},
                        {"chapterNum":"3.4", "chapterName":"20世纪满族社会变迁对老舍民族心理的制约（一）"},
                        {"chapterNum":"3.5", "chapterName":"20世纪满族社会变迁对老舍民族心理的制约（二）"},
                        {"chapterNum":"3.6", "chapterName":"20世纪满族社会变迁对老舍民族心理的制约（三）"},
                        {"chapterNum":"3.7", "chapterName":"20世纪满族社会变迁对老舍民族心理的制约（四）"},
                        {"chapterNum":"3.8", "chapterName":"20世纪满族社会变迁对老舍民族心理的制约（五）"}
                    ]
                }
            ]
        },
        {
            "courseid":"87585529",
            "courseName":"鲁迅文学作品导读",
            "typeOne":"学科素养",
            "typeTwo":"文学与经典",
            "keySpeakName":"温儒敏",
            "keySpeakUnivercity":"北京大学",
            "keySpeakPosition":"教授",
            "keySpeakIntroduce":"温儒敏，北京大学中文系主任，教授，博士生导师，北大语文教育研究所所长。兼任中国现代文学研究会会长，国务院学位委员会学科评议组成员，国家哲学社会科学规划评审委员，《中国现代文学研究丛刊》主编。",
            "courseIntroduce":["鲁迅被誉为“二十世纪东亚文化地图上占最大领土的作家”，对于五四运动以后的中国社会思想文化发展产生了一定的的影响，蜚声世界文坛。", "鲁迅对文化的论说，并不是仅停留在知识的层面，而是从自己的生命体验中总结出来的。我们读“鲁迅”能够知人论世，了解国情，了解国民性，了解人情世故。鲁迅是重要的遗产，是近百年来新传统重要的一部分，实际上已经弥漫在我们的现实生活中。特别是鲁迅批判式的思考方式，对我们思想力的培养是有很大益处的。在学习写作方面，鲁迅文字的灵活、深刻、幽默，都为我们提供了很好的范本。","本课程内容淡化文学史概念，突出作家作品分析。课程目标是培养学习者观察文学现象的能力、审美分析的能力、评论写作的能力。","本课程由三位相关研究领域的专家教授共同授课，并配有一位专家教授的相关讲座视频资料。","“第一讲 鲁迅的《呐喊》《彷徨》”（5集）；“第二讲 鲁迅的杂文”（5集），由北京大学温儒敏教授主讲；“第三讲 《狂人日记》创作之谜解析”（6集）；“第四讲 《药》不是‘双线结构’” （6集）；“第五讲 《阿Q正传》：无魂国民的传神写照” （4集）；“第六讲 《故事新编》解读” （11集），由北京师范大学的钱振纲教授主讲；" +
            "“第七讲 鲁迅《野草》”（5集）由山东大学的黄万华教授主讲；“第八讲 对鲁迅的再认识及其在当代的意义” （4集），由北京大学钱理群教授主讲；“第九讲 鲁迅：在流言伤害中挺立不屈” （4集）、“第十讲 鲁迅与左联”（4集），由南开大学刘家鸣教授主讲。"],
            "bigImgUrl":"http://p.ananas.chaoxing.com/star3/733_434c/5705c3c5e4b0578413d07727.jpg",
            "videoUrl":"http://s1.ananas.chaoxing.com/video/4c/56af1724498e69718a42cc77/sd.mp4",
            "courseChapter":[
                {
                    "鲁迅的《呐喊》《彷徨》（主讲人：温儒敏）":[
                        {"chapterNum":"1.1", "chapterName":"学习指导"},
                        {"chapterNum":"1.2", "chapterName":"鲁迅及《呐喊》《彷徨》的底色和基调"},
                        {"chapterNum":"1.3", "chapterName":"《呐喊》《彷徨》的取材与写作意向"},
                        {"chapterNum":"1.4", "chapterName":"《呐喊》《彷徨》对传统小说艺术的突破与创新"},
                        {"chapterNum":"1.5", "chapterName":"《狂人日记》鉴赏"},
                        {"chapterNum":"1.6", "chapterName":"《伤逝》《阿Q正传》鉴赏"},
                        {"chapterNum":"1.7", "chapterName":"走近作家"},
                        {"chapterNum":"1.8", "chapterName":"扩展阅读"}
                    ],
                    "鲁迅的杂文（主讲人：温儒敏）":[
                        {"chapterNum":"2.1", "chapterName":"学习指导"},
                        {"chapterNum":"2.2", "chapterName":"鲁迅杂文概述"},
                        {"chapterNum":"2.3", "chapterName":"鲁迅杂文的价值及阅读"},
                        {"chapterNum":"2.4", "chapterName":"鲁迅杂文：勾勒社会相类型形象"},
                        {"chapterNum":"2.5", "chapterName":"鲁迅杂文：议论中的联想与形象化表达"},
                        {"chapterNum":"2.6", "chapterName":"鲁迅杂文：讽刺、幽默与曲笔及《故事新编》"},
                        {"chapterNum":"2.7", "chapterName":"扩展阅读"}
                    ],
                    "《狂人日记》创作之谜解析（主讲人：钱振纲）":[
                        {"chapterNum":"3.1", "chapterName":"鲁迅关于《狂人日记》的评论"},
                        {"chapterNum":"3.2", "chapterName":"寄寓说与象征说：寄寓说"},
                        {"chapterNum":"3.3", "chapterName":"寄寓说与象征说：象征说"},
                        {"chapterNum":"3.4", "chapterName":"借人抒怀：三类话语"},
                        {"chapterNum":"3.5", "chapterName":"借人抒怀：暴露家族制度和礼教的弊害"},
                        {"chapterNum":"3.6", "chapterName":"狂人构思的两种艺术功能"},
                        {"chapterNum":"3.7", "chapterName":"配套教材"},
                        {"chapterNum":"3.8", "chapterName":"数字图书"}
                    ],
                    "《药》不是“双线结构”（主讲人：钱振纲）":[
                        {"chapterNum":"4.1", "chapterName":"关于“双线结构”"},
                        {"chapterNum":"4.2", "chapterName":"关于情节线索与叙事线索：情节线索"},
                        {"chapterNum":"4.3", "chapterName":"关于情节线索与叙事线索：叙事线索"},
                        {"chapterNum":"4.4", "chapterName":"关于情节线索与叙事线索：二者的关系"},
                        {"chapterNum":"4.5", "chapterName":"《药》是“一写二”结构"},
                        {"chapterNum":"4.6", "chapterName":"“双线结构”说不能成立"},
                        {"chapterNum":"4.7", "chapterName":"配套教材"},
                        {"chapterNum":"4.8", "chapterName":"数字图书"}
                    ],
                    "《阿Q正传》：无魂国民的传神写照（主讲人：钱振纲）":[
                        {"chapterNum":"5.1", "chapterName":"阿Q性格的本质特征：三种观点"},
                        {"chapterNum":"5.2", "chapterName":"阿Q缺乏理性自我"},
                        {"chapterNum":"5.3", "chapterName":"性格体现：盲目地服膺异己的封建伦理文化"},
                        {"chapterNum":"5.4", "chapterName":"性格体现：本能地适应吃人的社会现实"},
                        {"chapterNum":"5.5", "chapterName":"配套教材"},
                        {"chapterNum":"5.6", "chapterName":"数字图书"}
                    ],
                    "《故事新编》解读（主讲人：钱振纲）":[
                        {"chapterNum":"6.1", "chapterName":"英雄的赞歌与悲歌：《补天》（一）"},
                        {"chapterNum":"6.2", "chapterName":"英雄的赞歌与悲歌：《补天》（二）"},
                        {"chapterNum":"6.3", "chapterName":"英雄的赞歌与悲歌：《奔月》"},
                        {"chapterNum":"6.4", "chapterName":"英雄的赞歌与悲歌：《铸剑》"},
                        {"chapterNum":"6.5", "chapterName":"以反传统的态度重估传统文化：《采薇》"},
                        {"chapterNum":"6.6", "chapterName":"以反传统的态度重估传统文化：《出关》"},
                        {"chapterNum":"6.7", "chapterName":"以反传统的态度重估传统文化：《起死》"},
                        {"chapterNum":"6.8", "chapterName":"以反传统的态度重估传统文化：《非攻》"},
                        {"chapterNum":"6.9", "chapterName":"以反传统的态度重估传统文化：《理水》"},
                        {"chapterNum":"6.10", "chapterName":"以反传统的态度重估传统文化：小结"},
                        {"chapterNum":"6.11", "chapterName":"关于“古今杂糅”的艺术手法"},
                        {"chapterNum":"6.12", "chapterName":"配套教材"},
                        {"chapterNum":"6.13", "chapterName":"数字图书"}
                    ],
                    "鲁迅《野草》（主讲人：黄万华）":[
                        {"chapterNum":"7.1", "chapterName":"《野草》的基本结构和鲁迅哲学：《秋夜》"},
                        {"chapterNum":"7.2", "chapterName":"《野草》的基本结构和鲁迅哲学：《死火》"},
                        {"chapterNum":"7.3", "chapterName":"“独语”中的灵魂逼视：“独语体”"},
                        {"chapterNum":"7.4", "chapterName":"“独语”中的灵魂逼视：《墓碣文》"},
                        {"chapterNum":"7.5", "chapterName":"散文诗的成熟体式"},
                        {"chapterNum":"7.6", "chapterName":"配套教材"},
                        {"chapterNum":"7.7", "chapterName":"数字图书"}
                    ],
                    "对鲁迅的再认识及其在当代的意义（主讲人：钱理群）":[
                        {"chapterNum":"8.1", "chapterName":"学习指导"},
                        {"chapterNum":"8.2", "chapterName":"对鲁迅的再认识及其在当代的意义（一）"},
                        {"chapterNum":"8.3", "chapterName":"对鲁迅的再认识及其在当代的意义（二）"},
                        {"chapterNum":"8.4", "chapterName":"对鲁迅的再认识及其在当代的意义（三）"},
                        {"chapterNum":"8.5", "chapterName":"对鲁迅的再认识及其在当代的意义（四）"},
                        {"chapterNum":"8.6", "chapterName":"钱理群教授讲座文档资料"}
                    ],
                    "鲁迅：在流言伤害中挺立不屈（主讲人：刘家鸣）":[
                    {"chapterNum":"9.1", "chapterName":"学习指导"},
                    {"chapterNum":"9.2", "chapterName":"在流言伤害中挺立不屈（一）"},
                    {"chapterNum":"9.3", "chapterName":"在流言伤害中挺立不屈（二）"},
                    {"chapterNum":"9.4", "chapterName":"在流言伤害中挺立不屈（三）"},
                    {"chapterNum":"9.5", "chapterName":"在流言伤害中挺立不屈（四）"}
                ],
                    "鲁迅与左联（主讲人：刘家鸣）":[
                        {"chapterNum":"10.1", "chapterName":"鲁迅与左联（一）"},
                        {"chapterNum":"10.2", "chapterName":"鲁迅与左联（二）"},
                        {"chapterNum":"10.3", "chapterName":"鲁迅与左联（三）"},
                        {"chapterNum":"10.4", "chapterName":"鲁迅与左联（四）"}
                    ]
                }
            ]
        },
        {
            "courseid":"87867755",
            "courseName":"沈从文与《边城》",
            "typeOne":"学科素养",
            "typeTwo":"文学与经典",
            "keySpeakName":"温儒敏",
            "keySpeakUnivercity":"北京大学",
            "keySpeakPosition":"教授",
            "keySpeakIntroduce":"温儒敏，北京大学中文系主任，教授，博士生导师，北大语文教育研究所所长。兼任中国现代文学研究会会长，国务院学位委员会学科评议组成员，国家哲学社会科学规划评审委员，《中国现代文学研究丛刊》主编。",
            "courseIntroduce":["沈从文的一生是坎坷的一生，是奉献的一生，又两度被提名为诺贝尔文学奖评选候选人。", "沈从文以乡村为题材的小说是典型的乡村文化小说，它不仅在整体上与都市“现代文明”相对照，而且始终注目于湘西世界朝现代转型过程中，不同的文化碰撞所规定的乡下人的生存方式、人生足迹及历史命运。也正由于这种对以金钱为核心的“现代文学”的批判，以及对理想浪漫主义的追求，使得沈从文写出了《边城》这样的理想生命之歌。整个作品充满了对人生的隐忧和对生命的哲学思考，一如他那实在而又顽强的生命，给人教益和启示。","本课程由两位相关研究领域的专家教授主讲：" +
            "“第一讲 沈从文与《边城》”，由北京大学温儒敏教授主讲；“第二讲 沈从文的小说”，由中国人民大学杨联芬教授主讲。"],
            "bigImgUrl":"http://p.ananas.chaoxing.com/star3/733_434c/5705c560e4b0578413d07833.jpg",
            "videoUrl":"http://s1.ananas.chaoxing.com/video/4c/56af1724498e69718a42cc77/sd.mp4",
            "courseChapter":[
                {
                    "沈从文与《边城》（主讲人：温儒敏）":[
                        {"chapterNum":"1.1", "chapterName":"学习指导"},
                        {"chapterNum":"1.2", "chapterName":"沈从文的生平及创作"},
                        {"chapterNum":"1.3", "chapterName":"沈从文的写作意图"},
                        {"chapterNum":"1.4", "chapterName":"《边城》鉴赏"},
                        {"chapterNum":"1.5", "chapterName":"《边城》中的美学"},
                        {"chapterNum":"1.6", "chapterName":"《边城》中的牧歌理想"},
                        {"chapterNum":"1.7", "chapterName":"走近作家"},
                        {"chapterNum":"1.8", "chapterName":"扩展阅读"}
                    ],
                    "沈从文的小说（主讲人：杨联芬）":[
                        {"chapterNum":"2.1", "chapterName":"沈从文生平及创作"},
                        {"chapterNum":"2.2", "chapterName":"返璞归真：沈从文的文化理想"},
                        {"chapterNum":"2.3", "chapterName":"自然：沈从文的宗教情感"},
                        {"chapterNum":"2.4", "chapterName":"牧歌：沈从文的美学至境"},
                        {"chapterNum":"2.5", "chapterName":"配套教材"}
                    ]
                }
            ]
        },
        {
            "courseid":"86576353",
            "courseName":"American way of life",
            "typeOne":"学科素养",
            "typeTwo":"历史与文明",
            "keySpeakName":"Alex Olah",
            "keySpeakUnivercity":"China University of Petroleum",
            "keySpeakPosition":"教师",
            "keySpeakIntroduce":"亚历克斯•欧拉是一位退休官员，曾在澳大利亚贸易委员会任职30余年，历任澳大利亚驻印度尼西亚、泰国、加拿大、巴西、中国和新加坡等国大使馆外交官员。亚历克斯•欧拉于1969年获得澳大利亚国立大学经济学学士学位。2009年获得对外英语教学资格证，并于当年携夫人薇拉•欧拉（Vera Olah）来中国石油大学从事英语教学工作。亚历克斯•欧拉将他与夫人在中国石油大学工作期间的教学、生活经历整理成书《洋眼看石大》，该书已由中国石油大学出版社出版。",
            "courseIntroduce":["中西文化的差异表现在生活中的方方面面，美国为西方国家的代表，生活方式亦可作为西方的典型。美国人的生活方式丰富多彩，从美国人的各大爱好，到美国人生活中的实际方面，包括运动、教育、婚姻、饮食习惯、礼仪态度等，阐释了美国人社会生活的各个方面，成为了解西方文化的一个窗口。课程以全英文教学，旨在通过指导学生学习相关的文化背景知识，进一步提高学生的英语水平和跨文化交际的能力。"],
            "bigImgUrl":"http://p.ananas.chaoxing.com/star3/733_434c/5680aa8b498e69718a39278c.jpg",
            "videoUrl":"http://s1.ananas.chaoxing.com/video/91/56986c82e4b0e85354b839e2/sd.mp4",
            "courseChapter":[
                {
                    "Americans＇Love":[
                        {"chapterNum":"1.1", "chapterName":"Chapter introduction"},
                        {"chapterNum":"1.2", "chapterName":"Americans love sports 1"},
                        {"chapterNum":"1.3", "chapterName":"Americans love sports 2"},
                        {"chapterNum":"1.4", "chapterName":"Keeping Pets"},
                        {"chapterNum":"1.5", "chapterName":"Fans of Cars"},
                        {"chapterNum":"1.6", "chapterName":"Americans Love Guns"},
                        {"chapterNum":"1.7", "chapterName":"Crime in America"}
                    ],
                    "Aspects of Social Life":[
                        {"chapterNum":"2.1", "chapterName":"Chapter introduction"},
                        {"chapterNum":"2.2", "chapterName":"Chapter introduction"},
                        {"chapterNum":"2.3", "chapterName":"Nobel Prize"},
                        {"chapterNum":"2.4", "chapterName":"Rights and Economy"},
                        {"chapterNum":"2.5", "chapterName":"Education in American"},
                        {"chapterNum":"2.6", "chapterName":"Handedness and Festivals"},
                        {"chapterNum":"2.7", "chapterName":"Forbes"}
                    ],
                    "Daily Life":[
                        {"chapterNum":"3.1", "chapterName":"Chapter introduction"},
                        {"chapterNum":"3.2", "chapterName":"Local Speech"},
                        {"chapterNum":"3.3", "chapterName":"Manners & Attitudes"},
                        {"chapterNum":"3.4", "chapterName":"Way of Life"},
                        {"chapterNum":"3.5", "chapterName":"Eating Habits"},
                        {"chapterNum":"3.6", "chapterName":"Marriage & Houses"},
                        {"chapterNum":"3.7", "chapterName":"Gap Year"}
                    ]
                }
            ]
        },
        {
            "courseid":"86623860",
            "courseName":"Geography and History of the Uni…",
            "typeOne":"学科素养",
            "typeTwo":"历史与文明",
            "keySpeakName":"亚历克斯•欧拉",
            "keySpeakUnivercity":"China University of Petroleum",
            "keySpeakPosition":"教师",
            "keySpeakIntroduce":"亚历克斯•欧拉是一位退休官员，曾在澳大利亚贸易委员会任职30余年，历任澳大利亚驻印度尼西亚、泰国、加拿大、巴西、中国和新加坡等国大使馆外交官员。亚历克斯•欧拉于1969年获得澳大利亚国立大学经济学学士学位。2009年获得对外英语教学资格证，并于当年携夫人薇拉•欧拉（Vera Olah）来中国石油大学从事英语教学工作。亚历克斯•欧拉将他与夫人在中国石油大学工作期间的教学、生活经历整理成书《洋眼看石大》，该书已由中国石油大学出版社出版。",
            "courseIntroduce":["如今的美国国力强盛，你了解它多少呢？欧拉先生带领大家考察美国的地理环境，讲述哥伦布发现新大陆之后，这片土地上发生的故事。美国如何从殖民走向独立，又经历了什么，国土扩张，不断强盛？学习课程便会知晓。全英文课堂教学，旨在通过指导学生学习相关的文化背景知识，进一步提高学生的英语水平和跨文化交际的能力。"],
            "bigImgUrl":"http://p.ananas.chaoxing.com/star3/733_434c/56b003f7e4b0e85354bf646f.png",
            "videoUrl":"http://s1.ananas.chaoxing.com/video/70/56afff9fe4b0e85354bf63ed/sd.mp4",
            "courseChapter":[
                {
                    "Geography of the USA":[
                        {"chapterNum":"1.1", "chapterName":"Chapter Introduction"},
                        {"chapterNum":"1.2", "chapterName":"Topography of the USA"},
                        {"chapterNum":"1.3", "chapterName":"Three Icons of America"},
                        {"chapterNum":"1.4", "chapterName":"Comparison of the USA and China (1)"},
                        {"chapterNum":"1.5", "chapterName":"Comparison of the USA and China (2)"}
                    ],
                    "Early American History":[
                        {"chapterNum":"2.1", "chapterName":"Chapter Introduction"},
                        {"chapterNum":"2.2", "chapterName":"Discovery of the 'New World'"},
                        {"chapterNum":"2.3", "chapterName":"British Colonies"},
                        {"chapterNum":"2.4", "chapterName":"The War of Independence"},
                        {"chapterNum":"2.5", "chapterName":"Building the New Nation"},
                        {"chapterNum":"2.6", "chapterName":"A Hero, Traitor and Genius"}
                    ],
                    "Mid-term American History":[
                        {"chapterNum":"3.1", "chapterName":"Chapter Introduction"},
                        {"chapterNum":"3.2", "chapterName":"Timeline of Major Events (1800-1899)"},
                        {"chapterNum":"3.3", "chapterName":"Territorial Expansion（1）"},
                        {"chapterNum":"3.4", "chapterName":"Territorial Expansion（2）"},
                        {"chapterNum":"3.5", "chapterName":"The American Civil War（1）"},
                        {"chapterNum":"3.6", "chapterName":"The American Civil War（2）"},
                        {"chapterNum":"3.7", "chapterName":"America's Economic Development"}
                    ],
                    "Modern American History":[
                        {"chapterNum":"3.1", "chapterName":"Chapter Introduction"},
                        {"chapterNum":"3.2", "chapterName":"Timeline of Major Events (1900-2014)"},
                        {"chapterNum":"3.3", "chapterName":"The Panama Canal"},
                        {"chapterNum":"3.4", "chapterName":"The Great Depression"},
                        {"chapterNum":"3.5", "chapterName":"The Cold War"},
                        {"chapterNum":"3.6", "chapterName":"911 & War on Terror"}
                    ]
                }
            ]
        },
        {
            "courseid":"81778599",
            "courseName":"走进周代文明",
            "typeOne":"学科素养",
            "typeTwo":"历史与文明",
            "keySpeakName":"李山",
            "keySpeakUnivercity":"北京师范大学",
            "keySpeakPosition":"教授",
            "keySpeakIntroduce":"李山，1963年出生，河北新城人。1995年获北京师范大学中文系文学博士，现为北京师范大学教授，博士生导师。主要研究方向为中国古代文学史、中国文化史，在中国古代文学史、中国文化史，在《诗经》研究、先秦两汉文学研究领域卓有成就。曾在《文学遗产》等核心期刊上发表过学术论文数十篇，其中《经典文献的诗学读法》和《诗大雅若干诗篇图赞说及由此发现的雅、颂间部分对应》在学术界有较大影响。先后出版过《诗经的文化精神》、《诗经析读》、《诗经新注》等诗经研究专著，及《中国文化概论》（湖南师范大学出版社）。",
            "courseIntroduce":["周代文明的研究范围是一个非常宽泛的课题。广义上，应该包括中国有史以来创造的物质生产文化、制度行为文化、精神心理文化的总和。本书侧重周代文明中的精神心理、观念形态的形成、演变、沿革及其规律性的探讨。在研究周代文明时，既注意到其历时性，又注意到其共同性，更关注其当代性；既阐述文化基本结构的有机组成，又侧重文化主体内容的基本精神与规律的探讨。本系列主要介绍西周分封建国与统一化文明进程和民众的历史品格。"],
            "bigImgUrl":"http://p.ananas.chaoxing.com/star3/733_434c/5550592ee4b017d277eb6ceb.jpg",
            "videoUrl":"http://s1.ananas.chaoxing.com/video/17/55a340a9498e4b57cd471fce/sd.mp4",
            "courseChapter":[
                {
                    "西周分封建国与统一化文明进程的开始":[
                        {"chapterNum":"1.1", "chapterName":"统一的汉文化的起源"},
                        {"chapterNum":"1.2", "chapterName":"历法的形成"},
                        {"chapterNum":"1.3", "chapterName":"统一族群的凝聚"},
                        {"chapterNum":"1.4", "chapterName":"主体族群的演变"},
                        {"chapterNum":"1.5", "chapterName":"不同族群的代兴"},
                        {"chapterNum":"1.6", "chapterName":"西周的建立与分封制的产生"},
                        {"chapterNum":"1.7", "chapterName":"民族的拆立与分封制的确立"},
                        {"chapterNum":"1.8", "chapterName":"民族文化的融合"},
                        {"chapterNum":"1.9", "chapterName":"血缘连结与民族融合"},
                        {"chapterNum":"1.10", "chapterName":"华夏意识的形成"},
                        {"chapterNum":"1.11", "chapterName":"礼乐文明的兴起"},
                        {"chapterNum":"1.12", "chapterName":"礼乐文明的内容"},
                        {"chapterNum":"1.13", "chapterName":"礼乐文明的内涵"},
                        {"chapterNum":"1.14", "chapterName":"礼乐的类别之军礼"},
                        {"chapterNum":"1.15", "chapterName":"礼乐的类别之大蒐礼"},
                        {"chapterNum":"1.16", "chapterName":"礼乐文明的传承与影响"}
                    ],
                    "民众的历史品格":[
                        {"chapterNum":"2.1", "chapterName":"国人的范畴与作用"},
                        {"chapterNum":"2.2", "chapterName":"国人地位的变迁"},
                        {"chapterNum":"2.3", "chapterName":"国人经济基础的变化"},
                        {"chapterNum":"2.4", "chapterName":"诸子百家思潮的冲击"},
                        {"chapterNum":"2.5", "chapterName":"大同思想对社会的影响"},
                        {"chapterNum":"2.6", "chapterName":"天下观念和天人合一"},
                        {"chapterNum":"2.7", "chapterName":"天人合一的追求"},
                        {"chapterNum":"2.8", "chapterName":"儒家思想与社会变革"},
                        {"chapterNum":"2.9", "chapterName":"孔子思想中的“仁”"},
                        {"chapterNum":"2.10", "chapterName":"“仁”的内在要求"},
                        {"chapterNum":"2.11", "chapterName":"儒家的教化论"},
                        {"chapterNum":"2.12", "chapterName":"儒家的性善论"}
                    ]
                }
            ]
        },
        {
            "courseid":"81778658",
            "courseName":"“二十四史”导读之《史记》篇",
            "typeOne":"学科素养",
            "typeTwo":"历史与文明",
            "keySpeakName":"韩昇",
            "keySpeakUnivercity":"复旦大学",
            "keySpeakPosition":"教授",
            "keySpeakIntroduce":"韩昇：男，1957年生，江苏海安人。复旦大学历史系教授，博士生导师，中央电视台《百家讲坛》主讲人。日本关西大学东西学术研究所外国研究员，中国社会科学院佛教研究中心特邀研究员，厦门大学宗教学研究所兼职教授。中国魏晋南北朝史学会常务理事兼副会长，中国唐史学会理事，中国日本史学会常务理事，福建省历史学会理事，日本唐代史学会会员，国务院特殊津贴获得者。在国内外出版《渡来人の先祖传承および渡来形态について》、《日本古代的大陆移民研究》、《隋文帝传》、《海东集——古代东亚史实考论》、《东亚世界形成史论》、《正仓院》、《史家说史：苍茫隋唐路》、《遣唐使和学问僧》等专著，发表中国古代史、东亚世界史、佛教史和历史·遗传学研究的论文150多篇。",
            "courseIntroduce":["“二十四史”是我国古代二十四部正史的总称，它的内容非常广泛，涵盖了历代政治、经济、文化、艺术以及科技等方方面面，可以说是清代以前中华文明的百科全书。《史记》是西汉著名史学家司马迁撰写的一部纪传体史书，是中国历史上第一部纪传体通史，被列为“二十四史”之首。"],
            "bigImgUrl":"http://p.ananas.chaoxing.com/star3/733_434c/55dd668ae4b01a8c031ddd47.jpg",
            "videoUrl":"http://s1.ananas.chaoxing.com/video/ca/55e155c6498ead65175a0021/sd.mp4",
            "courseChapter":[
                {
                    "《史记·太史公自传》导读":[
                        {"chapterNum":"1.1", "chapterName":"中国历史记载的体例"},
                        {"chapterNum":"1.2", "chapterName":"司马迁的身世与家学"},
                        {"chapterNum":"1.3", "chapterName":"撰著《史记》的动因"},
                        {"chapterNum":"1.4", "chapterName":"汉朝文化治国与《史记》"}
                    ],
                    "《史记》的撰著":[
                        {"chapterNum":"2.1", "chapterName":"司马迁忍辱发愤写《史记》"},
                        {"chapterNum":"2.2", "chapterName":"《报任安书》（上）"},
                        {"chapterNum":"2.3", "chapterName":"《报任安书》（下）"}
                    ],
                    "《史记·项羽本纪》导读":[
                        {"chapterNum":"3.1", "chapterName":"项羽出生的社会背景"},
                        {"chapterNum":"3.2", "chapterName":"项羽其人"},
                        {"chapterNum":"3.3", "chapterName":"项梁起义"},
                        {"chapterNum":"3.4", "chapterName":"江南义军的壮大"},
                        {"chapterNum":"3.5", "chapterName":"项羽崭露头角"},
                        {"chapterNum":"3.6", "chapterName":"巨鹿大破秦军"},
                        {"chapterNum":"3.7", "chapterName":"争夺关中"},
                        {"chapterNum":"3.8", "chapterName":"鸿门宴"},
                        {"chapterNum":"3.9", "chapterName":"西楚霸王"},
                        {"chapterNum":"3.10", "chapterName":"楚汉之争（一）"},
                        {"chapterNum":"3.11", "chapterName":"楚汉之争（二）"},
                        {"chapterNum":"3.12", "chapterName":"楚汉之争（三）"},
                        {"chapterNum":"3.13", "chapterName":"四面楚歌"},
                        {"chapterNum":"3.14", "chapterName":"对项羽的反思"},
                        {"chapterNum":"3.15", "chapterName":"刘邦与项羽的比较"}
                    ],
                    "《史记·高祖本纪》导读":[
                        {"chapterNum":"4.1", "chapterName":"平民豪杰刘邦"},
                        {"chapterNum":"4.2", "chapterName":"刘邦起义"},
                        {"chapterNum":"4.3", "chapterName":"分兵灭秦"},
                        {"chapterNum":"4.4", "chapterName":"直捣关中"},
                        {"chapterNum":"4.5", "chapterName":"忍辱负重"},
                        {"chapterNum":"4.6", "chapterName":"东山再起"},
                        {"chapterNum":"4.7", "chapterName":"持久作战"},
                        {"chapterNum":"4.8", "chapterName":"建立汉朝"}
                    ],
                    "《史记·留侯世家》导读":[
                        {"chapterNum":"5.1", "chapterName":"《史记·留侯世家》导读"},
                        {"chapterNum":"5.2", "chapterName":"战略家张良"},
                        {"chapterNum":"5.3", "chapterName":"运筹帷幄"},
                        {"chapterNum":"5.4", "chapterName":"决胜千里"}
                    ],
                    "《史记·淮阴侯列传》导读":[
                        {"chapterNum":"6.1", "chapterName":"千古名将韩信"},
                        {"chapterNum":"6.2", "chapterName":"韩信对形势的分析"},
                        {"chapterNum":"6.3", "chapterName":"挺进敌后"},
                        {"chapterNum":"6.4", "chapterName":"战略大包抄"},
                        {"chapterNum":"6.5", "chapterName":"来自敌人的诱惑"},
                        {"chapterNum":"6.6", "chapterName":"坚持国家统一"},
                        {"chapterNum":"6.7", "chapterName":"英雄末路"}
                    ]
                }
            ]
        },
        {
            "courseid":"81778631",
            "courseName":"“二十四史”导读之《汉书》《后汉书》《三国志》篇",
            "typeOne":"学科素养",
            "typeTwo":"历史与文明",
            "keySpeakName":"韩昇",
            "keySpeakUnivercity":"复旦大学",
            "keySpeakPosition":"教授",
            "keySpeakIntroduce":"韩昇：男，1957年生，江苏海安人。复旦大学历史系教授，博士生导师，中央电视台《百家讲坛》主讲人。日本关西大学东西学术研究所外国研究员，中国社会科学院佛教研究中心特邀研究员，厦门大学宗教学研究所兼职教授。中国魏晋南北朝史学会常务理事兼副会长，中国唐史学会理事，中国日本史学会常务理事，福建省历史学会理事，日本唐代史学会会员，国务院特殊津贴获得者。在国内外出版《渡来人の先祖传承および渡来形态について》、《日本古代的大陆移民研究》、《隋文帝传》、《海东集——古代东亚史实考论》、《东亚世界形成史论》、《正仓院》、《史家说史：苍茫隋唐路》、《遣唐使和学问僧》等专著，发表中国古代史、东亚世界史、佛教史和历史·遗传学研究的论文150多篇。",
            "courseIntroduce":["“二十四史”是我国古代二十四部正史的总称，它的内容非常广泛，涵盖了历代政治、经济、文化、艺术以及科技等方方面面，可以说是清代以前中华文明的百科全书。《史记》是西汉著名史学家司马迁撰写的一部纪传体史书，是中国历史上第一部纪传体通史，被列为“二十四史”之首。"],
            "bigImgUrl":"http://p.ananas.chaoxing.com/star3/733_434c/55fd4075498ed981287e81d3.jpg",
            "videoUrl":"",
            "courseChapter":[
                {
                    "《汉书》名篇导读":[
                        {"chapterNum":"1.1", "chapterName":"班固与《汉书》"},
                        {"chapterNum":"1.2", "chapterName":"苏武出使"},
                        {"chapterNum":"1.3", "chapterName":"不辱使命"}
                    ],
                    "《后汉书》名篇导读":[
                        {"chapterNum":"2.1", "chapterName":"东汉后期的混乱政局"},
                        {"chapterNum":"2.2", "chapterName":"党锢之祸"},
                        {"chapterNum":"2.3", "chapterName":"镇压清流与东汉瓦解"}
                    ],
                    "《三国志·荀彧传》导读":[
                        {"chapterNum":"3.1", "chapterName":"三国谋士荀彧"},
                        {"chapterNum":"3.2", "chapterName":"奇谋安华北"},
                        {"chapterNum":"3.3", "chapterName":"官渡之战"}
                    ],
                    "《三国志·诸葛亮传》导读":[
                        {"chapterNum":"4.1", "chapterName":"卧龙诸葛亮"},
                        {"chapterNum":"4.2", "chapterName":"隆中擘画天下"},
                        {"chapterNum":"4.3", "chapterName":"联吴抗曹"}
                    ],
                    "《三国志·周瑜传》导读":[
                        {"chapterNum":"5.1", "chapterName":"风流儒将周瑜"},
                        {"chapterNum":"5.2", "chapterName":"赤壁之战"}
                    ]
                }
            ]
        },
        {
            "courseid":"86668332",
            "courseName":"中国传统文化入门",
            "typeOne":"学科素养",
            "typeTwo":"历史与文明",
            "keySpeakName":"李庚其",
            "keySpeakUnivercity":"北京大学",
            "keySpeakPosition":"客座教授",
            "keySpeakIntroduce":"李庚其，中国著名历史学家；《清史》《清史考异》光绪、宣统两朝撰稿人；中国传媒大学附属学校名誉校长；西安外事学院北京七方培训中心校长；蒙代尔国际企业家大学教授、人文及社会学科首席教授；中国民主促进会、中央委员会、社会部部长，北京民进企业家联谊会顾问；中国和平统一促进会理事。北京大学客座教授。代表著作《赢在中国——传统文化与现代经营管理》、《东方大智慧——国学·人性·管理》",
            "courseIntroduce":["《中国传统文化入门》是由史学家李庚其先生主讲，其潜心研究中国传统文化数十载，从博大精深的传统典籍和浩瀚的历史中，总结出一整套值得当代社会借鉴的历史规律、为人处世经验。本课程以中国传统文化中的史实为例，分别介绍了传统文化、儒、道、法、兵几大家及传统文学。内容丰富，深入浅出，是了解中国传统文化的一扇窗口。本课程普遍适用于各年龄层次的对中国传统文化热爱的学习者，学习之后让人受益匪浅。"],
            "bigImgUrl":"http://p.ananas.chaoxing.com/star3/733_434c/56ca98a0e4b0e85354ccdbbc.jpg",
            "videoUrl":"http://s1.ananas.chaoxing.com/video/38/56cba89de4b0e85354ccfb60/sd.mp4",
            "courseChapter":[
                {
                    "传统文化概述":[
                        {"chapterNum":"1.1", "chapterName":"学习指导"},
                        {"chapterNum":"1.2", "chapterName":"传统文化概述"},
                        {"chapterNum":"1.3", "chapterName":"扩展阅读"}
                    ],
                    "儒家学派":[
                        {"chapterNum":"2.1", "chapterName":"学习指导"},
                        {"chapterNum":"2.2", "chapterName":"儒家学派（一）"},
                        {"chapterNum":"2.3", "chapterName":"儒家学派（二）"},
                        {"chapterNum":"2.4", "chapterName":"扩展阅读"}
                    ],
                    "道家学派":[
                        {"chapterNum":"3.1", "chapterName":"学习指导"},
                        {"chapterNum":"3.2", "chapterName":"道家学派（一）"},
                        {"chapterNum":"3.3", "chapterName":"道家学派（二）"},
                        {"chapterNum":"3.3", "chapterName":"扩展阅读"}
                    ],
                    "法家学派":[
                        {"chapterNum":"4.1", "chapterName":"学习指导"},
                        {"chapterNum":"4.2", "chapterName":"法家学派"},
                        {"chapterNum":"4.3", "chapterName":"扩展阅读"}
                    ],
                    "兵家":[
                        {"chapterNum":"5.1", "chapterName":"学习指导"},
                        {"chapterNum":"5.2", "chapterName":"兵家"},
                        {"chapterNum":"5.2", "chapterName":"扩展阅读"}
                    ],
                    "史学":[
                        {"chapterNum":"6.1", "chapterName":"学习指导"},
                        {"chapterNum":"6.2", "chapterName":"史学"},
                        {"chapterNum":"6.2", "chapterName":"扩展阅读"}
                    ],
                    "传统文学":[
                        {"chapterNum":"7.1", "chapterName":"学习指导"},
                        {"chapterNum":"7.2", "chapterName":"传统文学（一）"},
                        {"chapterNum":"7.3", "chapterName":"传统文学（二）"},
                        {"chapterNum":"7.4", "chapterName":"扩展阅读"}
                    ]
                }
            ]
        },
        {
            "courseid":"81784434",
            "courseName":"中华文明的起源",
            "typeOne":"学科素养",
            "typeTwo":"历史与文明",
            "keySpeakName":"李鸿宾",
            "keySpeakUnivercity":"中央民族大学",
            "keySpeakPosition":"教授",
            "keySpeakIntroduce":"李鸿宾，男，汉族，1960年生于吉林省长春市。1979年9月至1986年7月在北京大学历史系读本科和研究生，分别于1983年和1986年获历史学学士学位、硕士学位。1998年至2001年在中央民族大学历史系攻读博士学位研究生（在职），获历史学博士学位。1986年7月开始在中央民族大学历史系从事教学和科研工作，先后任助教、讲师、副教授、教授，2003年晋升为历史学专门史博士生指导教师，2004年3月受聘任历史系主任。学校内外学术兼职有：中央民族大学科研处《民族研究信息》副主编、中央民族大学中国少数民族研究中心兼职教授、中国长城学会常务理事、学术部主任、中国长城博物馆学术委员会委员。",
            "courseIntroduce":["中国，古埃及，古巴比伦和古印度并称为四大文明古国，但是除了中国，其他三个文明都曾中断过甚至消失，只有中国文明一直延续到现在。其实，在中华民族5000年的历史文明中，出现了许多王朝的更替，每次的变动都是地震般剧变，但中国的历史发展从没有被这些剧变动摇过，尽管整个国家曾多次遭到入侵，并两度为外来王朝所统治，但这些入侵只是扰乱而并非改变中国。中国有史以来所经历到的，仅仅是局限于传统王朝的兴替，而不是大规模的碎裂和新的开始。而中国历史如此的绵延久远，原因也是多方面的。  一、地理位臵。  二、人口优势。三、文化统一。 四、思想统一。"],
            "bigImgUrl":"http://p.ananas.chaoxing.com/star3/733_434c/55f9145b498ed981287e2b78.jpg",
            "videoUrl":"",
            "courseChapter":[
                {
                    "中国文明的连续性":[
                        {"chapterNum":"1.1", "chapterName":"中国历史的特点：连续性"},
                        {"chapterNum":"1.2", "chapterName":"连续性的体现与原因"},
                        {"chapterNum":"1.3", "chapterName":"新时期史学界关注的五大问题"}
                    ],
                    "中国文明的起源":[
                        {"chapterNum":"2.1", "chapterName":"早期中国人的起源"},
                        {"chapterNum":"2.2", "chapterName":"旧石器时代的人类与社会"},
                        {"chapterNum":"2.3", "chapterName":"北京猿人、山顶洞人"},
                        {"chapterNum":"2.4", "chapterName":"旧石器时代晚期的人类化石及其特点"},
                        {"chapterNum":"2.5", "chapterName":"旧石器晚期的文化特点"},
                        {"chapterNum":"2.6", "chapterName":"新石器时代的人类与社会"},
                        {"chapterNum":"2.7", "chapterName":"新石器时代的人类文明——黄河流域中部"},
                        {"chapterNum":"2.8", "chapterName":"新石器时代的人类文明——黄河流域的代表性文化"},
                        {"chapterNum":"2.9", "chapterName":"龙山文化与长江流域的文化"},
                        {"chapterNum":"2.10", "chapterName":"红山文化的特征"},
                        {"chapterNum":"2.11", "chapterName":"新时期时代中国文明特点"},
                        {"chapterNum":"2.12", "chapterName":"人类早期生活：从母系到父系"},
                        {"chapterNum":"2.13", "chapterName":"历史文献学与历史传说"}
                    ]
                }
            ]
        },
        {
            "courseid":"81863019",
            "courseName":"夏商周史",
            "typeOne":"学科素养",
            "typeTwo":"历史与文明",
            "keySpeakName":"李鸿宾",
            "keySpeakUnivercity":"中央民族大学",
            "keySpeakPosition":"教授",
            "keySpeakIntroduce":"李鸿宾，男，汉族，1960年生于吉林省长春市。1979年9月至1986年7月在北京大学历史系读本科和研究生，分别于1983年和1986年获历史学学士学位、硕士学位。1998年至2001年在中央民族大学历史系攻读博士学位研究生（在职），获历史学博士学位。1986年7月开始在中央民族大学历史系从事教学和科研工作，先后任助教、讲师、副教授、教授，2003年晋升为历史学专门史博士生指导教师，2004年3月受聘任历史系主任。学校内外学术兼职有：中央民族大学科研处《民族研究信息》副主编、中央民族大学中国少数民族研究中心兼职教授、中国长城学会常务理事、学术部主任、中国长城博物馆学术委员会委员。",
            "courseIntroduce":["中国又是一个有着辉煌文明的古老国度。从步入文明的门槛之日起，中国先后经历了夏朝、商朝、西周、东周、春秋、战国、秦朝、西汉、东汉、三国、西晋、东晋十六国、南北朝、隋朝、唐朝、五代、十国、宋辽夏金、元朝、明朝和清朝等等历史时期。 历代统治者，以其各自的政绩在历史舞台上演出了内容不同的剧目，或名垂青史，或遗臭万年。其中从战国开始，封建社会孕育形成，秦朝则建立了中国历史上第一个中央集权的大一统封建帝国。此后，两汉王朝是封建社会迅速成长的阶段，唐、宋时期经历了封建社会最辉煌的时代，至明、清两代，封建社会盛极而衰，并最终开始步入了多灾多难的近代社会。",
                "在数千年的古代历史上，中华民族以不屈不挠的顽强意志和勇于探索的聪明才智，谱写了波澜壮阔的历史画卷，创造了同期世界历史上极其灿烂的物质文明与精神文明。",
                "秦汉时期是中国秦汉两朝大一统时期的合称。公元前221年秦灭六国，首次完成了真正意义上的中国统一，秦王政改号称皇帝，建立起中国历史上第一个中央集权制的秦朝。秦始皇废封建，立郡县，开始实行全面的统一。然而由于缺乏历史经验，秦朝二世而亡。在经过短暂的分裂之后，汉朝继之而起，并基本延续秦的制度，史称“汉承秦制”。秦汉时期是中国历史上第一个大统一时期。也是统一多民族国家的奠基时期。"],
            "bigImgUrl":"http://p.ananas.chaoxing.com/star3/733_434c/55fd4c2be4b040cfea18687c.jpg",
            "videoUrl":"",
            "courseChapter":[
                {
                    "夏商周历史":[
                        {"chapterNum":"1.1", "chapterName":"夏朝历史概述"},
                        {"chapterNum":"1.2", "chapterName":"夏朝国家政权组成形式"},
                        {"chapterNum":"1.3", "chapterName":"商朝的建立"},
                        {"chapterNum":"1.4", "chapterName":"母系氏族的遗风"},
                        {"chapterNum":"1.5", "chapterName":"商朝的建立及早期生活状态"},
                        {"chapterNum":"1.6", "chapterName":"商朝国家的发展"},
                        {"chapterNum":"1.7", "chapterName":"西周的建立与早期生活形态"},
                        {"chapterNum":"1.8", "chapterName":"对古代专制社会的探讨"}
                    ],
                    "夏商西周历史：周朝":[
                        {"chapterNum":"2.1", "chapterName":"西周的建立与灭亡"},
                        {"chapterNum":"2.2", "chapterName":"西周的经济、文化制度"},
                        {"chapterNum":"2.3", "chapterName":"西周的经济与文化形态"}
                    ],
                    "春秋":[
                        {"chapterNum":"3.1", "chapterName":"春秋时期历史发展的基本变迁、重要性"},
                        {"chapterNum":"3.2", "chapterName":"春秋历史发展的基本过程"},
                        {"chapterNum":"3.3", "chapterName":"春秋时期的思想文化、民族关系"}
                    ],
                    "战国历史":[
                        {"chapterNum":"4.1", "chapterName":"战国七雄"},
                        {"chapterNum":"4.2", "chapterName":"从春秋到战国：中央集权化道路"},
                        {"chapterNum":"4.3", "chapterName":"战国时期的经济基础变化与变法图强"},
                        {"chapterNum":"4.4", "chapterName":"战国时期的制度建设、民族问题与时代思想"}
                    ]
                }
            ]
        },
        {
            "courseid":"81782529",
            "courseName":"秦汉史",
            "typeOne":"学科素养",
            "typeTwo":"历史与文明",
            "keySpeakName":"李鸿宾",
            "keySpeakUnivercity":"中央民族大学",
            "keySpeakPosition":"教授",
            "keySpeakIntroduce":"李鸿宾，男，汉族，1960年生于吉林省长春市。1979年9月至1986年7月在北京大学历史系读本科和研究生，分别于1983年和1986年获历史学学士学位、硕士学位。1998年至2001年在中央民族大学历史系攻读博士学位研究生（在职），获历史学博士学位。1986年7月开始在中央民族大学历史系从事教学和科研工作，先后任助教、讲师、副教授、教授，2003年晋升为历史学专门史博士生指导教师，2004年3月受聘任历史系主任。学校内外学术兼职有：中央民族大学科研处《民族研究信息》副主编、中央民族大学中国少数民族研究中心兼职教授、中国长城学会常务理事、学术部主任、中国长城博物馆学术委员会委员。",
            "courseIntroduce":["中国又是一个有着辉煌文明的古老国度。从步入文明的门槛之日起，中国先后经历了夏朝、商朝、西周、东周、春秋、战国、秦朝、西汉、东汉、三国、西晋、东晋十六国、南北朝、隋朝、唐朝、五代、十国、宋辽夏金、元朝、明朝和清朝等等历史时期。 历代统治者，以其各自的政绩在历史舞台上演出了内容不同的剧目，或名垂青史，或遗臭万年。其中从战国开始，封建社会孕育形成，秦朝则建立了中国历史上第一个中央集权的大一统封建帝国。此后，两汉王朝是封建社会迅速成长的阶段，唐、宋时期经历了封建社会最辉煌的时代，至明、清两代，封建社会盛极而衰，并最终开始步入了多灾多难的近代社会。",
                "在数千年的古代历史上，中华民族以不屈不挠的顽强意志和勇于探索的聪明才智，谱写了波澜壮阔的历史画卷，创造了同期世界历史上极其灿烂的物质文明与精神文明。",
                "秦汉时期是中国秦汉两朝大一统时期的合称。公元前221年秦灭六国，首次完成了真正意义上的中国统一，秦王政改号称皇帝，建立起中国历史上第一个中央集权制的秦朝。秦始皇废封建，立郡县，开始实行全面的统一。然而由于缺乏历史经验，秦朝二世而亡。在经过短暂的分裂之后，汉朝继之而起，并基本延续秦的制度，史称“汉承秦制”。秦汉时期是中国历史上第一个大统一时期。也是统一多民族国家的奠基时期。"],
            "bigImgUrl":"http://p.ananas.chaoxing.com/star3/733_434c/55f9229ae4b040cfea17e202.jpg",
            "videoUrl":"",
            "courseChapter":[
                {
                    "秦朝历史":[
                        {"chapterNum":"1.1", "chapterName":"秦朝的制度性建设"},
                        {"chapterNum":"1.2", "chapterName":"秦王朝的刚性统治"},
                        {"chapterNum":"1.3", "chapterName":"秦王朝的灭亡原因"},
                        {"chapterNum":"1.4", "chapterName":"秦王朝灭亡的启示"}
                    ],
                    "西汉历史":[
                        {"chapterNum":"2.1", "chapterName":"楚汉相争"},
                        {"chapterNum":"2.2", "chapterName":"西汉的建立"},
                        {"chapterNum":"2.3", "chapterName":"西汉统治背后的思想"},
                        {"chapterNum":"2.4", "chapterName":"西汉历史变迁的基本状态"},
                        {"chapterNum":"2.5", "chapterName":"汉武帝的统治及评价"},
                        {"chapterNum":"2.6", "chapterName":"汉武帝对君相关系改革与确立"},
                        {"chapterNum":"2.7", "chapterName":"汉武帝的官制与人才选拔制度"},
                        {"chapterNum":"2.8", "chapterName":"汉武帝设立刺史"},
                        {"chapterNum":"2.9", "chapterName":"汉朝军队建设与酷吏政治"},
                        {"chapterNum":"2.10", "chapterName":"汉朝的经济制度"},
                        {"chapterNum":"2.11", "chapterName":"汉朝的民族问题"},
                        {"chapterNum":"2.12", "chapterName":"西汉末年王莽改制"}
                    ],
                    "东汉历史":[
                        {"chapterNum":"3.1", "chapterName":"东汉基本的政治特点"},
                        {"chapterNum":"3.2", "chapterName":"东汉王朝经济发展的特点"},
                        {"chapterNum":"3.3", "chapterName":"东汉王朝的民族关系"}
                    ]
                }
            ]
        },
        {
            "courseid":"81785435",
            "courseName":"魏晋南北朝史",
            "typeOne":"学科素养",
            "typeTwo":"历史与文明",
            "keySpeakName":"李鸿宾",
            "keySpeakUnivercity":"中央民族大学",
            "keySpeakPosition":"教授",
            "keySpeakIntroduce":"李鸿宾，男，汉族，1960年生于吉林省长春市。1979年9月至1986年7月在北京大学历史系读本科和研究生，分别于1983年和1986年获历史学学士学位、硕士学位。1998年至2001年在中央民族大学历史系攻读博士学位研究生（在职），获历史学博士学位。1986年7月开始在中央民族大学历史系从事教学和科研工作，先后任助教、讲师、副教授、教授，2003年晋升为历史学专门史博士生指导教师，2004年3月受聘任历史系主任。学校内外学术兼职有：中央民族大学科研处《民族研究信息》副主编、中央民族大学中国少数民族研究中心兼职教授、中国长城学会常务理事、学术部主任、中国长城博物馆学术委员会委员。",
            "courseIntroduce":["魏晋南北朝是指我国历史发展的一个特殊时段，始于东汉的灭亡，终于隋朝的建立，主要包括三国、西晋、东晋、五胡十六国、南朝与北朝。",
                "魏晋南北朝（220年—589年），又称三国两晋南北朝，是中国历史上的一段只有37年大一统，而余下朝代替换很快并有多国并存的时代。这个时期从220年曹丕称帝到589年隋朝灭南朝陈而统一中国，共369年。可分为三国时期（以曹魏正统，蜀汉与孙吴并立）、西晋时期（与东晋合称晋朝）、东晋与十六国时期、南北朝时期（南朝与北朝对立时期，共150年）。另外位于江南，全部建都在建康（孙吴时为建业，即今天的南京）的孙吴、东晋、南朝的宋、齐、梁、陈等六个国家又统称为六朝。",
                "魏晋南北朝是中国历史上政权更迭最频繁的时期。由于长期的封建割据和连绵不断的战争，使这一时期中国文化的发展受到特别严重的影响。其突出表现则是玄学的兴起、道教的勃兴及波斯、希腊文化的羼入。在从魏至隋的三百余年间，以及在三十余个大小王朝交替兴灭过程中，上述诸多新的文化因素互相影响，交相渗透的结果，使这一时期儒学的发展及孔子的形象和历史地位等问题也趋于复杂化。"],
            "bigImgUrl":"http://p.ananas.chaoxing.com/star3/733_434c/55f91a5a498ed981287e2c5f.jpg",
            "videoUrl":"",
            "courseChapter":[
                {
                    "魏晋南北朝":[
                        {"chapterNum":"1.1", "chapterName":"魏晋南北朝时期的基本特点"},
                        {"chapterNum":"1.2", "chapterName":"从三国到西晋王朝"},
                        {"chapterNum":"1.3", "chapterName":"东晋王朝的建立与门阀政治"},
                        {"chapterNum":"1.4", "chapterName":"东晋王朝人口迁徙与经济特征"},
                        {"chapterNum":"1.5", "chapterName":"东晋王朝的政治、文化特征"},
                        {"chapterNum":"1.6", "chapterName":"五胡十六国的定义"},
                        {"chapterNum":"1.7", "chapterName":"五胡十六国的民族问题"},
                        {"chapterNum":"1.8", "chapterName":"历史的分裂与统一"},
                        {"chapterNum":"1.9", "chapterName":"北魏建国早期历史疑点与汉化倾向"},
                        {"chapterNum":"1.10", "chapterName":"北魏的分裂与演变"},
                        {"chapterNum":"1.11", "chapterName":"西魏政权特征"},
                        {"chapterNum":"1.12", "chapterName":"南朝社会的政治特征"},
                        {"chapterNum":"1.13", "chapterName":"南朝的社会经济、民族问题"},
                        {"chapterNum":"1.14", "chapterName":"南朝的文化特征与南北合流"}
                    ]
                }
            ]
        },
        {
            "courseid":"81782638",
            "courseName":"隋唐史（上）",
            "typeOne":"学科素养",
            "typeTwo":"历史与文明",
            "keySpeakName":"韩昇",
            "keySpeakUnivercity":"复旦大学",
            "keySpeakPosition":"教授",
            "keySpeakIntroduce":"复旦大学历史系教授，博士研究生导师；父亲是魏晋南北朝隋唐历史学家韩国磐；中国日本史学会常务理事，中国唐史学会理事，日本唐代史学会会员。长期从事东亚国际关系史和魏隋唐史的研究，2012年，韩昇老师在《百家讲坛》讲述《盛唐的背影》。",
            "courseIntroduce":["公元581年到907年的隋唐两朝在政治、军事、文化、经济、科技上都达到中华文明史前所未有的发展。本课以两朝重大历史事件为切入点，从隋朝建立、改革创制、唐太宗与贞观之治、武则天到唐玄宗、唐朝的土地制度、安史之乱、藩镇割据、财政改革、文明发展等方面进行深入分析，打破了传统的历史课框架讲解模式，引导学生主动去考证历史的真实性，对历史史实形成自身的独特思考。"],
            "bigImgUrl":"http://p.ananas.chaoxing.com/star3/733_434c/55fd3cf8498ed981287e818c.jpg",
            "videoUrl":"",
            "courseChapter":[
                {
                    "隋朝的建立":[
                        {"chapterNum":"1.1", "chapterName":"隋朝的疆域与杨坚"},
                        {"chapterNum":"1.2", "chapterName":"北周府兵制建立的背景"}
                    ],
                    "改革与创制":[
                        {"chapterNum":"2.1", "chapterName":"书籍推荐与中国史研究"},
                        {"chapterNum":"2.2", "chapterName":"三省六部制介绍"},
                        {"chapterNum":"2.3", "chapterName":"户籍制度产生的原因"},
                        {"chapterNum":"2.4", "chapterName":"均田制、租庸调制、三长制"},
                        {"chapterNum":"2.5", "chapterName":"坞壁、科举制"},
                        {"chapterNum":"2.6", "chapterName":"地方制度改革、“十恶”“八议”"}
                    ],
                    "隋史概况":[
                        {"chapterNum":"3.1", "chapterName":"隋史概况"}
                    ],
                    "唐太宗与贞观之治":[
                        {"chapterNum":"4.1", "chapterName":"李渊起兵与唐朝建立"},
                        {"chapterNum":"4.2", "chapterName":"玄武门之变"},
                        {"chapterNum":"4.3", "chapterName":"李世民用人与唐朝兴盛"},
                        {"chapterNum":"4.4", "chapterName":"唐朝的教育与治国方略"}
                    ],
                    "大唐及东亚文明":[
                        {"chapterNum":"5.1", "chapterName":"大唐及东亚文明"}
                    ],
                    "从武则天到唐玄宗":[
                        {"chapterNum":"6.1", "chapterName":"帝王继承制度、太子位之争、武则天"},
                        {"chapterNum":"6.2", "chapterName":"唐太宗的传位安排"},
                        {"chapterNum":"6.3", "chapterName":"武则天到唐玄宗的政治过渡"},
                        {"chapterNum":"6.4", "chapterName":"姚崇对玄宗的要求、中国文化与禅宗"},
                        {"chapterNum":"6.5", "chapterName":"唐玄宗对人事制度的改革与政策"},
                        {"chapterNum":"6.6", "chapterName":"唐朝的教育与经济"}
                    ]
                }
            ]
        },
        {
            "courseid":"81778759",
            "courseName":"隋唐史（下）",
            "typeOne":"学科素养",
            "typeTwo":"历史与文明",
            "keySpeakName":"韩昇",
            "keySpeakUnivercity":"复旦大学",
            "keySpeakPosition":"教授",
            "keySpeakIntroduce":"复旦大学历史系教授，博士研究生导师；父亲是魏晋南北朝隋唐历史学家韩国磐；中国日本史学会常务理事，中国唐史学会理事，日本唐代史学会会员。长期从事东亚国际关系史和魏隋唐史的研究，2012年，韩昇老师在《百家讲坛》讲述《盛唐的背影》。",
            "courseIntroduce":["公元581年到907年的隋唐两朝在政治、军事、文化、经济、科技上都达到中华文明史前所未有的发展。本课以两朝重大历史事件为切入点，从隋朝建立、改革创制、唐太宗与贞观之治、武则天到唐玄宗、唐朝的土地制度、安史之乱、藩镇割据、财政改革、文明发展等方面进行深入分析，打破了传统的历史课框架讲解模式，引导学生主动去考证历史的真实性，对历史史实形成自身的独特思考。"],
            "bigImgUrl":"http://p.ananas.chaoxing.com/star3/733_434c/55fd3c93498ed981287e8185.jpg",
            "videoUrl":"",
            "courseChapter":[
                {
                    "唐朝的土地制度":[
                        {"chapterNum":"1.1", "chapterName":"均田制及社会阶层"},
                        {"chapterNum":"1.2", "chapterName":"唐朝对官员的授田"}
                    ],
                    "唐朝的租庸调制":[{"chapterNum":"2.1", "chapterName":"唐朝的租庸调制"}],
                    "唐朝的由盛转衰":[
                        {"chapterNum":"3.1", "chapterName":"均田制瓦解及唐玄宗时期政治转折"},
                        {"chapterNum":"3.2", "chapterName":"玄宗时期制度和社会转型"},
                        {"chapterNum":"3.3", "chapterName":"李林甫政策及安禄山身世"}
                    ],
                    "安史之乱":[
                        {"chapterNum":"4.1", "chapterName":"安禄山的政治经历"},
                        {"chapterNum":"4.2", "chapterName":"安禄山讨好唐玄宗"},
                        {"chapterNum":"4.3", "chapterName":"杨国忠与杨贵妃姐妹"},
                        {"chapterNum":"4.4", "chapterName":"唐玄宗时期的使职现象"},
                        {"chapterNum":"4.5", "chapterName":"杨国忠和李林甫、安禄山的政治斗争"},
                        {"chapterNum":"4.6", "chapterName":"安史之乱的平定及唐肃宗的继位"}
                    ],
                    "唐史的相关思考":[
                        {"chapterNum":"5.1", "chapterName":"安史之乱的影响及中国对技术的态度"},
                        {"chapterNum":"5.2", "chapterName":"唐朝的多元文化及转变"},
                        {"chapterNum":"5.3", "chapterName":"天宝十年的战争及中亚地区的重要性"}
                    ],
                    "藩镇割据、宦官与党争":[
                        {"chapterNum":"6.1", "chapterName":"藩镇割据、宦官与党争（一）"},
                        {"chapterNum":"6.2", "chapterName":"藩镇割据、宦官与党争（二）"}
                    ],
                    "刘晏、杨炎的财政改革":[
                        {"chapterNum":"7.1", "chapterName":"刘晏、杨炎的财政改革（一）"},
                        {"chapterNum":"7.2", "chapterName":"刘晏、杨炎的财政改革（二）"}
                    ],
                    "唐朝的文化":[
                        {"chapterNum":"8.1", "chapterName":"唐朝文化特点及文化盛世的原因"},
                        {"chapterNum":"8.2", "chapterName":"佛教的兴盛"},
                        {"chapterNum":"8.3", "chapterName":"中国城市建筑特点及佛教的影响"},
                        {"chapterNum":"8.4", "chapterName":"中国佛教对日本的影响及文化交流"}
                    ]
                }
            ]
        },
        {
            "courseid":"81785520",
            "courseName":"明史十讲",
            "typeOne":"学科素养",
            "typeTwo":"历史与文明",
            "keySpeakName":"樊树志",
            "keySpeakUnivercity":"复旦大学",
            "keySpeakPosition":"教授",
            "keySpeakIntroduce":"樊树志，复旦大学教授，博导。研究方向为明清史、中国土地关系史、江南地区史；著有《中国封建土地关系发展史》、《明清江南市镇探微》、《万历传》、《崇祯传》等。",
            "courseIntroduce":["明朝的历史长达277年，对这样一个夹在两个少数民族统治王朝（元朝和清朝）中间的汉族王朝的历史，究竟应该如何表述和评价，历来褒贬不一。《明史十讲》主要涉及了明朝的历史分期及其成就以及扭曲和贬抑明史的几种观点，是樊树志教授从自己的读史心得中提炼出来，力图对中华文明史上的重要问题，进行具有深度和新意的解读，不再纠缠于历史的线索和细枝末节。虽然该课程没有做到面面俱到，但是它选择重点，深入透彻的讲解，讲深讲透，讲出个所以然。给不同专业的学生一个历史深邃感的启示，激发他们重新思考中华文明史的兴趣。"],
            "bigImgUrl":"http://p.ananas.chaoxing.com/star2/2014-06/733_434/1403185251700ybxoj.png",
            "videoUrl":"",
            "courseChapter":[
                {
                    "朱元璋与胡蓝党案":[
                        {"chapterNum":"1.1", "chapterName":"朱元璋与胡蓝党案（上）"},
                        {"chapterNum":"1.2", "chapterName":"朱元璋与胡蓝党案（下）"}
                    ],
                    "阳明心学与异端思想":[
                        {"chapterNum":"2.1", "chapterName":"阳明心学与异端思想（上）"},
                        {"chapterNum":"2.2", "chapterName":"阳明心学与异端思想（下）"}
                    ],
                    "嘉靖与严嵩":[
                        {"chapterNum":"3.1", "chapterName":"嘉靖与严嵩（上）"},
                        {"chapterNum":"3.2", "chapterName":"嘉靖与严嵩（下）"}
                    ],
                    "张居正与万历":[
                        {"chapterNum":"4.1", "chapterName":"张居正与万历（上）"},
                        {"chapterNum":"4.2", "chapterName":"张居正与万历（下）"}
                    ],
                    "“海禁”与“倭寇”":[
                        {"chapterNum":"5.1", "chapterName":"“海禁”与“倭寇”（上）"},
                        {"chapterNum":"5.2", "chapterName":"“海禁”与“倭寇”（下）"}
                    ],
                    "东林书院与东林党":[
                        {"chapterNum":"6.1", "chapterName":"东林书院与东林党（一）"},
                        {"chapterNum":"6.2", "chapterName":"东林书院与东林党（二）"},
                        {"chapterNum":"6.3", "chapterName":"东林书院与东林党（三）"}
                    ],
                    "魏忠贤与“阉党”专政":[
                        {"chapterNum":"7.1", "chapterName":"魏忠贤与“阉党”专政（上）"},
                        {"chapterNum":"7.2", "chapterName":"魏忠贤与“阉党”专政（下）"}
                    ],
                    "耶稣会士与西学东渐":[
                        {"chapterNum":"8.1", "chapterName":"耶稣会士与西学东渐（上）"},
                        {"chapterNum":"8.2", "chapterName":"耶稣会士与西学东渐（下）"}
                    ],
                    "“全球化”贸易与白银资本":[
                        {"chapterNum":"9.1", "chapterName":"“全球化”贸易与白银资本（上）"},
                        {"chapterNum":"9.2", "chapterName":"“全球化”贸易与白银资本（下）"}
                    ],
                    "王朝的末路——崇祯十七年":[
                        {"chapterNum":"10.1", "chapterName":"“王朝的末路——崇祯十七年（一）"},
                        {"chapterNum":"10.2", "chapterName":"王朝的末路——崇祯十七年（二）"},
                        {"chapterNum":"10.3", "chapterName":"王朝的末路——崇祯十七年（三）"}
                    ]
                }
            ]
        },
        {
            "courseid":"81778690",
            "courseName":"20世纪世界史（上）",
            "typeOne":"学科素养",
            "typeTwo":"历史与文明",
            "keySpeakName":"冯玮",
            "keySpeakUnivercity":"复旦大学",
            "keySpeakPosition":"教授",
            "keySpeakIntroduce":"冯玮，历史学系教授、博士生导师，日本研究中心兼职研究员。曾赴日本京都大学留学，师从日本著名学者山室信一教授并获文部省奖学金。1993年获历史学博士学位。1995年至1997年赴日本神奈川大学从事教学和科研工作两年。 2000年至2001年赴韩国高丽大学从事研究工作一年。2007年1月至2008年1月赴日本东京庆应大学任客座教授一年。研究方向：日本史。",
            "courseIntroduce":["世界历史根据不同的时间段，可以分为古代史、近代史、现代史等；根据不同的地区，可分为不同地区的历史；根据不同的代表事物，可以分为不同事物的历史。本系列主要是介绍了20世纪世界主要地区和国家发生的重大历史事件。老师主要是讲解了地缘政治与朝鲜半岛、阿以冲突、巴尔干火药桶、印巴冲突、美国在“三对矛盾”中的发展壮大、苏联在“三次革命”和“三次改革”中的兴衰等方面的内容。通过老师的讲解使我们能够更加的了解20世纪的世界历史。"],
            "bigImgUrl":"http://p.ananas.chaoxing.com/star/733_434c/1384146005413fdfti.jpg",
            "videoUrl":"",
            "courseChapter":[
                {
                    "20世纪世界史导言":[
                        {"chapterNum":"1.1", "chapterName":"20世纪世界史导言（一）"},
                        {"chapterNum":"1.2", "chapterName":"20世纪世界史导言（二）"},
                        {"chapterNum":"1.3", "chapterName":"20世纪世界史导言（三）"},
                        {"chapterNum":"1.4", "chapterName":"20世纪世界史导言（四）"}
                    ],
                    "地缘政治与朝鲜半岛":[
                        {"chapterNum":"2.1", "chapterName":"地缘政治与朝鲜半岛（上）"},
                        {"chapterNum":"2.2", "chapterName":"地缘政治与朝鲜半岛（中）"},
                        {"chapterNum":"2.3", "chapterName":"地缘政治与朝鲜半岛（下）"}
                    ],
                    "阿以冲突":[
                        {"chapterNum":"3.1", "chapterName":"阿以冲突（上）"},
                        {"chapterNum":"3.2", "chapterName":"阿以冲突（下）"}
                    ],
                    "巴尔干火药桶":[
                        {"chapterNum":"4.1", "chapterName":"巴尔干火药桶（上）"},
                        {"chapterNum":"4.2", "chapterName":"巴尔干火药桶（下）"}
                    ],
                    "印巴冲突":[{"chapterNum":"5.1", "chapterName":"印巴冲突"}],
                    "美国在“三对矛盾”中发展壮大":[
                        {"chapterNum":"6.1", "chapterName":"美国在“三对矛盾”中发展壮大（一）"},
                        {"chapterNum":"6.2", "chapterName":"美国在“三对矛盾”中发展壮大（二）"},
                        {"chapterNum":"6.3", "chapterName":"美国在“三对矛盾”中发展壮大（三）"},
                        {"chapterNum":"6.4", "chapterName":"美国在“三对矛盾”中发展壮大（四）"}

                    ],
                    "苏联在“三次革命”和“三次改革”中兴衰":[
                        {"chapterNum":"7.1", "chapterName":"苏联在“三次革命”和“三次改革”中兴衰（一）"},
                        {"chapterNum":"7.2", "chapterName":"苏联在“三次革命”和“三次改革”中兴衰（二）"},
                        {"chapterNum":"7.3", "chapterName":"苏联在“三次革命”和“三次改革”中兴衰（三）"},
                        {"chapterNum":"7.4", "chapterName":"苏联在“三次革命”和“三次改革”中兴衰（四）"}
                    ]
                }
            ]
        },
        {
            "courseid":"81785657",
            "courseName":"20世纪世界史（下）",
            "typeOne":"学科素养",
            "typeTwo":"历史与文明",
            "keySpeakName":"冯玮",
            "keySpeakUnivercity":"复旦大学",
            "keySpeakPosition":"教授",
            "keySpeakIntroduce":"冯玮，历史学系教授、博士生导师，日本研究中心兼职研究员。曾赴日本京都大学留学，师从日本著名学者山室信一教授并获文部省奖学金。1993年获历史学博士学位。1995年至1997年赴日本神奈川大学从事教学和科研工作两年。 2000年至2001年赴韩国高丽大学从事研究工作一年。2007年1月至2008年1月赴日本东京庆应大学任客座教授一年。研究方向：日本史。",
            "courseIntroduce":["世界历史根据不同的时间段，可以分为古代史、近代史、现代史等；根据不同的地区，可分为不同地区的历史；根据不同的代表事物，可以分为不同事物的历史。本系列主要是介绍了20世纪世界主要地区和国家发生的重大历史事件。老师主要是讲解了地缘政治与朝鲜半岛、阿以冲突、巴尔干火药桶、印巴冲突、美国在“三对矛盾”中的发展壮大、苏联在“三次革命”和“三次改革”中的兴衰等方面的内容。通过老师的讲解使我们能够更加的了解20世纪的世界历史。"],
            "bigImgUrl":"http://p.ananas.chaoxing.com/star3/733_434c/55fd3923498ed981287e8142.jpg",
            "videoUrl":"",
            "courseChapter":[
                {
                    "英国走向“第三条道路”的历程":[{"chapterNum":"1.1", "chapterName":"英国走向“第三条道路”的历程"}],
                    "告别第三共和国的法兰西":[
                        {"chapterNum":"2.1", "chapterName":"告别第三共和国的法兰西（上）"},
                        {"chapterNum":"2.2", "chapterName":"告别第三共和国的法兰西（下）"}
                    ],
                    "德意志“第三帝国”的兴亡":[
                        {"chapterNum":"3.1", "chapterName":"德意志“第三帝国”的兴亡（一）"},
                        {"chapterNum":"3.2", "chapterName":"德意志“第三帝国”的兴亡（二）"}
                    ],
                    "日本的三次远航":[
                        {"chapterNum":"4.1", "chapterName":"日本的三次远航（一）"},
                        {"chapterNum":"4.2", "chapterName":"日本的三次远航（二）"},
                        {"chapterNum":"4.3", "chapterName":"日本的三次远航（三）"},
                        {"chapterNum":"4.4", "chapterName":"日本的三次远航（四）"},
                        {"chapterNum":"4.5", "chapterName":"日本的三次远航（五）"},
                        {"chapterNum":"4.6", "chapterName":"日本的三次远航（六）"},
                        {"chapterNum":"4.7", "chapterName":"日本的三次远航（七）"},
                        {"chapterNum":"4.8", "chapterName":"日本的三次远航（八）"},
                        {"chapterNum":"4.9", "chapterName":"日本的三次远航（九）"}
                    ],
                    "“一战”、“二战”、“冷战”":[
                        {"chapterNum":"5.1", "chapterName":"“一战”、“二战”、“冷战”（上）"},
                        {"chapterNum":"5.2", "chapterName":"“一战”、“二战”、“冷战”（下）"}
                    ]
                }
            ]
        },
        {
            "courseid":"81785553",
            "courseName":"清史（一）",
            "typeOne":"学科素养",
            "typeTwo":"历史与文明",
            "keySpeakName":"李治亭",
            "keySpeakUnivercity":"吉林社会科学院",
            "keySpeakPosition":"教授",
            "keySpeakIntroduce":"研究领域,主要研究方向为：清史兼及明史;论文与著作:《清太宗全传》（合著）、《明清战争史》（合著）、《 吴三桂大传》、《中国漕运史》、《清康乾盛世》、《关东文化》（合著）、《关东文化大辞典》（主编）、《爱新觉罗家族全书》（主编）、《二十六史精华》（主编）、《吉林省百科全书》（总编）。 主要论文有：《论清太宗在清史中的地位》、《中国近代化的曙光》在《光明日报》上发表；《清史研究中的几个争议问题》、《再议历史人物评价》、《文化精神的科学总结》在《人民日报》上发表；《关东文化论》、《清朝逊国九十年祭》被《新华文摘》全文转载。 ",
            "courseIntroduce":["李治亭教授从清朝历史及编纂清史两方面进行解读，阐释了他对清朝的基本看法并介绍了有关史书编纂方面的内容。他指出，清朝以其丰富厚重的内容、深远持久的影响，成为极具研究价值的王朝之一，并从统治时间长久、时代性及民族性等方面介绍了清朝的特点，指出清王朝鲜明的体现了兴盛衰亡的历史进程。"],
            "bigImgUrl":"http://p.ananas.chaoxing.com/star3/733_434c/55fd544f498ed981287e83d9.jpg",
            "videoUrl":"",
            "courseChapter":[
                {
                    "清朝勃兴建国":[
                        {"chapterNum":"1.1", "chapterName":"清朝勃兴建国（上）"},
                        {"chapterNum":"1.1", "chapterName":"清朝勃兴建国（下）"}
                    ],
                    "明清战争":[
                        {"chapterNum":"2.1", "chapterName":"明清战争（上）"},
                        {"chapterNum":"2.2", "chapterName":"明清战争（下）"}
                    ],
                    "努尔哈赤征战辽西":[
                        {"chapterNum":"3.1", "chapterName":"努尔哈赤征战辽西（上）"},
                        {"chapterNum":"3.2", "chapterName":"努尔哈赤征战辽西（中）"},
                        {"chapterNum":"3.3", "chapterName":"努尔哈赤征战辽西（下）"}
                    ],
                    "皇太极即位与新政":[
                        {"chapterNum":"4.1", "chapterName":"皇太极即位与新政（上）"},
                        {"chapterNum":"4.2", "chapterName":"皇太极即位与新政（下）"}
                    ],
                    "皇太极时期对明战争":[
                        {"chapterNum":"5.1", "chapterName":"皇太极时期对明战争（上）"},
                        {"chapterNum":"5.2", "chapterName":"皇太极时期对明战争（下）"}
                    ],
                    "扩建八旗与更改族名及国号":[
                        {"chapterNum":"6.1", "chapterName":"扩建八旗与更改族名及国号（上）"},
                        {"chapterNum":"6.2", "chapterName":"扩建八旗与更改族名及国号（下）"}
                    ],
                    "松锦决战与统一东北":[
                        {"chapterNum":"7.1", "chapterName":"松锦决战与统一东北（上）"},
                        {"chapterNum":"7.2", "chapterName":"松锦决战与统一东北（下）"}
                    ],
                    "明清变局":[
                        {"chapterNum":"8.1", "chapterName":"明清变局（上）"},
                        {"chapterNum":"8.2", "chapterName":"明清变局（下）"}
                    ]
                }
            ]
        },
        {
            "courseid":"81785548",
            "courseName":"清史（二）",
            "typeOne":"学科素养",
            "typeTwo":"历史与文明",
            "keySpeakName":"李治亭",
            "keySpeakUnivercity":"吉林社会科学院",
            "keySpeakPosition":"教授",
            "keySpeakIntroduce":"研究领域,主要研究方向为：清史兼及明史;论文与著作:《清太宗全传》（合著）、《明清战争史》（合著）、《 吴三桂大传》、《中国漕运史》、《清康乾盛世》、《关东文化》（合著）、《关东文化大辞典》（主编）、《爱新觉罗家族全书》（主编）、《二十六史精华》（主编）、《吉林省百科全书》（总编）。 主要论文有：《论清太宗在清史中的地位》、《中国近代化的曙光》在《光明日报》上发表；《清史研究中的几个争议问题》、《再议历史人物评价》、《文化精神的科学总结》在《人民日报》上发表；《关东文化论》、《清朝逊国九十年祭》被《新华文摘》全文转载。 ",
            "courseIntroduce":["李治亭教授从清朝历史及编纂清史两方面进行解读，阐释了他对清朝的基本看法并介绍了有关史书编纂方面的内容。他指出，清朝以其丰富厚重的内容、深远持久的影响，成为极具研究价值的王朝之一，并从统治时间长久、时代性及民族性等方面介绍了清朝的特点，指出清王朝鲜明的体现了兴盛衰亡的历史进程。"],
            "bigImgUrl":"http://p.ananas.chaoxing.com/star3/733_434c/55fd5480498ed981287e83de.jpg",
            "videoUrl":"",
            "courseChapter":[
                {
                    "清军入关":[
                        {"chapterNum":"1.1", "chapterName":"清军入关（上）"},
                        {"chapterNum":"1.1", "chapterName":"清军入关（下）"}
                    ],
                    "重新统一全国":[
                        {"chapterNum":"2.1", "chapterName":"重新统一全国（上）"},
                        {"chapterNum":"2.2", "chapterName":"重新统一全国（下）"}
                    ],
                    "巩固与扩大国家统一":[
                        {"chapterNum":"3.1", "chapterName":"巩固与扩大国家统一（上）"},
                        {"chapterNum":"3.2", "chapterName":"巩固与扩大国家统一（下）"}
                    ],
                    "维护边疆的统一":[
                        {"chapterNum":"4.1", "chapterName":"维护边疆的统一（上）"},
                        {"chapterNum":"4.2", "chapterName":"维护边疆的统一（下）"}
                    ],
                    "开创盛世的新局面":[
                        {"chapterNum":"5.1", "chapterName":"皇太极时期对明战争（上）"},
                        {"chapterNum":"5.2", "chapterName":"皇太极时期对明战争（下）"}
                    ],
                    "雍正帝即位论辨":[
                        {"chapterNum":"6.1", "chapterName":"雍正帝即位论辨（上）"},
                        {"chapterNum":"6.2", "chapterName":"雍正帝即位论辨（下）"}
                    ],
                    "雍正帝推进盛世继续发展及其评价":[
                        {"chapterNum":"7.1", "chapterName":"雍正帝推进盛世继续发展及其评价（上）"},
                        {"chapterNum":"7.2", "chapterName":"雍正帝推进盛世继续发展及其评价（下）"}
                    ],
                    "乾隆将盛世推向全盛":[
                        {"chapterNum":"8.1", "chapterName":"乾隆将盛世推向全盛（上）"},
                        {"chapterNum":"8.2", "chapterName":"乾隆将盛世推向全盛（下）"}
                    ]
                }
            ]
        },
        {
            "courseid":"81778702",
            "courseName":"今天的日本（上）",
            "typeOne":"学科素养",
            "typeTwo":"历史与文明",
            "keySpeakName":"贾成厂",
            "keySpeakUnivercity":"北京科技大学",
            "keySpeakPosition":"教授",
            "keySpeakIntroduce":"贾成厂：北京科技大学材料科学与工程学院教授、博士生导师，现任粉末材料研究所党支部书记。曾长期留学、工作于日本，从事材料学领域的科学研究。中国复合材料学会理事，中国金属学会粉末冶金分会副理事长兼秘书长，《复合材料学报》编委，《粉末冶金技术》编委，《材料科技与设备》编委，《粉末冶金材料科学与工程》编委，《中国钼业》编委等。",
            "courseIntroduce":["日本是与我国一衣带水的邻邦，两国的交流源远流长，中日邦交正常化后又有了新的发展。该课程主要从日本的地理，历史，政府与外交政策，经济，科技，社会，文化等方面对该领域有兴趣的同学提供一些了解。课堂上， 贾老师会穿插一些自己的经历，结合在日本的所见所闻与一些趣事，让堂课变得更真实，具体，贴近生活，同时也更易于激发学生对日本的兴趣，在该课堂中收获的不止是日本的文化知识，更是收获了其风土人情，从另一个角度更深入地靠近日本、了解日本。旨在让更多的同学深入了解到日本文化、日本的风土人情与生活习惯，无论是对以后的生活交际，或是留学生涯，或是涉及外交领域，这都会成为一个帮助。"],
            "bigImgUrl":"http://p.ananas.chaoxing.com/star3/733_434c/545b314aa31042cfbcf85f38.png",
            "videoUrl":"",
            "courseChapter":[
                {
                    "日本的地理——位置及气候":[{"chapterNum":"1.1", "chapterName":"日本的地理——位置及气候"}],
                    "日本的地理——四季及地形":[{"chapterNum":"2.1", "chapterName":"日本的地理——四季及地形"}],
                    "日本的地理——地形及人口":[{"chapterNum":"3.1", "chapterName":"日本的地理——地形及人口"}],
                    "日本的地理——日本的山河":[{"chapterNum":"4.1", "chapterName":"日本的地理——日本的山河"}],
                    "日本的地理——地理的概况":[{"chapterNum":"5.1", "chapterName":"日本的地理——地理的概况"}],
                    "日本的地理——日本的名胜古迹":[{"chapterNum":"6.1", "chapterName":"日本的地理——日本的名胜古迹"}],
                    "日本的地理——植物和动物":[{"chapterNum":"7.1", "chapterName":"日本的地理——植物和动物"}],
                    "日本的历史——古代日本":[{"chapterNum":"8.1", "chapterName":"日本的历史——古代日本"}],
                    "日本的历史——明治维新及日本的起源":[{"chapterNum":"9.1", "chapterName":"日本的历史——明治维新及日本的起源"}],
                    "日本的历史——二战前的日本":[{"chapterNum":"10.1", "chapterName":"日本的历史——二战前的日本"}],
                    "日本的历史——二战中的日本":[{"chapterNum":"11.1", "chapterName":"日本的历史——二战中的日本"}],
                    "日本的历史——二战后的日本":[{"chapterNum":"12.1", "chapterName":"日本的历史——二战后的日本"}],
                    "日本的历史——当代日本":[{"chapterNum":"13.1", "chapterName":"日本的历史——当代日本"}],
                    "日本的政治——日本的天皇":[{"chapterNum":"14.1", "chapterName":"日本的政治——日本的天皇"}],
                    "日本的政治——日本的皇室":[{"chapterNum":"15.1", "chapterName":"日本的政治——日本的皇室"}],
                    "日本的政治——日本的法律":[{"chapterNum":"16.1", "chapterName":"日本的政治——日本的法律"}],
                    "日本的政治——日本的统治机构":[{"chapterNum":"17.1", "chapterName":"日本的政治——日本的统治机构"}],
                    "日本的政治——日本的内政与外交":[{"chapterNum":"18.1", "chapterName":"日本的政治——日本的内政与外交"}],
                    "日本的政治——日本的象征":[{"chapterNum":"19.1", "chapterName":"日本的政治——日本的象征"}],
                    "日本的文化——日本的文字":[{"chapterNum":"20.1", "chapterName":"日本的文化——日本的文字(上)"},{"chapterNum":"20.2", "chapterName":"日本的文化——日本的文字(下)"}],
                    "日本的文化——日本的语言":[{"chapterNum":"21.1", "chapterName":"日本的文化——日本的语言(上)"},{"chapterNum":"21.2", "chapterName":"日本的文化——日本的语言(下)"}],
                    "日本的文化——日本的文学":[{"chapterNum":"22.1", "chapterName":"日本的文化——日本的文学"}]
                }
            ]
        },
        {
            "courseid":"81784617",
            "courseName":"今天的日本（下）",
            "typeOne":"学科素养",
            "typeTwo":"历史与文明",
            "keySpeakName":"贾成厂",
            "keySpeakUnivercity":"北京科技大学",
            "keySpeakPosition":"教授",
            "keySpeakIntroduce":"贾成厂：北京科技大学材料科学与工程学院教授、博士生导师，现任粉末材料研究所党支部书记。曾长期留学、工作于日本，从事材料学领域的科学研究。中国复合材料学会理事，中国金属学会粉末冶金分会副理事长兼秘书长，《复合材料学报》编委，《粉末冶金技术》编委，《材料科技与设备》编委，《粉末冶金材料科学与工程》编委，《中国钼业》编委等。",
            "courseIntroduce":["日本是与我国一衣带水的邻邦，两国的交流源远流长，中日邦交正常化后又有了新的发展。该课程主要从日本的地理，历史，政府与外交政策，经济，科技，社会，文化等方面对该领域有兴趣的同学提供一些了解。课堂上， 贾老师会穿插一些自己的经历，结合在日本的所见所闻与一些趣事，让堂课变得更真实，具体，贴近生活，同时也更易于激发学生对日本的兴趣，在该课堂中收获的不止是日本的文化知识，更是收获了其风土人情，从另一个角度更深入地靠近日本、了解日本。旨在让更多的同学深入了解到日本文化、日本的风土人情与生活习惯，无论是对以后的生活交际，或是留学生涯，或是涉及外交领域，这都会成为一个帮助。"],
            "bigImgUrl":"http://p.ananas.chaoxing.com/star3/733_434c/55fd3a1f498ed981287e815b.jpg",
            "videoUrl":"",
            "courseChapter":[
                {
                    "日本的文化——日本的宗教与风俗":[{"chapterNum":"1.1", "chapterName":"日本的文化——日本的宗教与风俗"}],
                    "日本的文化——日本的艺术":[{"chapterNum":"2.1", "chapterName":"日本的文化——日本的艺术"}],
                    "日本的文化——日本的建筑":[{"chapterNum":"3.1", "chapterName":"日本的文化——日本的建筑"}],
                    "日本的文化——日本的体育":[{"chapterNum":"4.1", "chapterName":"日本的文化——日本的体育"}],
                    "日本的文化——日本的饮食习惯":[{"chapterNum":"5.1", "chapterName":"日本的文化——日本的饮食习惯"}],
                    "日本的文化——日本的社会习惯":[{"chapterNum":"6.1", "chapterName":"日本的文化——日本的社会习惯"}],
                    "日本的文化——日本的旅游风光":[{"chapterNum":"7.1", "chapterName":"日本的文化——日本的旅游风光"}],
                    "日本的社会——阶级与身份差":[{"chapterNum":"8.1", "chapterName":"日本的社会——阶级与身份差"}],
                    "日本的社会——社会保障和宣传工具":[{"chapterNum":"9.1", "chapterName":"日本的社会——社会保障和宣传工具"}],
                    "日本的社会——寿命与人口增长":[{"chapterNum":"10.1", "chapterName":"日本的社会——寿命与人口增长"}],
                    "日本的社会——日本的教育":[{"chapterNum":"11.1", "chapterName":"日本的社会——日本的教育"}],
                    "日本的社会——家庭环境和交通":[{"chapterNum":"12.1", "chapterName":"日本的社会——家庭环境和交通"}],
                    "日本的经济——日本经济发展概况":[{"chapterNum":"13.1", "chapterName":"日本的经济——日本经济发展概况"}],
                    "日本的经济——全年负增长":[{"chapterNum":"14.1", "chapterName":"日本的经济——全年负增长"}],
                    "日本的经济——日本面临危机":[{"chapterNum":"15.1", "chapterName":"日本的经济——日本面临危机"}],
                    "日本的经济——日本的金融":[{"chapterNum":"16.1", "chapterName":"日本的经济——日本的金融"}],
                    "日本的经济——日本的农业":[{"chapterNum":"17.1", "chapterName":"日本的经济——日本的农业"}],
                    "日本的经济——日本GDP、贸易和农业":[{"chapterNum":"18.1", "chapterName":"日本的经济——日本GDP、贸易和农业"}],
                    "日本的企业经营——终生雇用制":[{"chapterNum":"19.1", "chapterName":"日本的企业经营——终生雇用制"}],
                    "日本的企业经营——日本企业的三个支柱":[{"chapterNum":"20.1", "chapterName":"日本的企业经营——日本企业的三个支柱"}],
                    "日本的企业经营——工作时间和工资水平":[{"chapterNum":"21.1", "chapterName":"日本的企业经营——工作时间和工资水平"}],
                    "日本的企业经营——企业文化和员工":[{"chapterNum":"22.1", "chapterName":"日本的企业经营——企业文化和员工"}]
                }
            ]
        },
        {
            "courseid":"86359656",
            "courseName":"清末风云人物之危机篇",
            "typeOne":"学科素养",
            "typeTwo":"历史与文明",
            "keySpeakName":"杨东梁",
            "keySpeakUnivercity":"中国人民大学",
            "keySpeakPosition":"教授",
            "keySpeakIntroduce":"主讲人简介：中国人民大学清史研究所教授，博士生导师。曾任校图书馆馆长及北京高等学校图书情报工作委员会副主任、秘书长等社会职务和校学术委员会委员、北京市学位委员会第一届学科评议组成员等学术职务。主要从事中国近代史方向的教学和研究，并兼及图书馆学研究，中国近代政治史、晚清历史人物、晚清军事史为其重点研究领域。其代表作《左宗棠评传》一书在写作过程中曾受到王震将军的关注。 ",
            "courseIntroduce":["历史是由人创造的，历史人物研究便自然成为历史研究的主题之一。而中国近代史是影响中国发展的最重要的转折阶段，因此研究中国近代人物变成为了解中国那段最重要的历史的最佳途径。本系列课程分为《清末风云人物之危机篇》（中国人民大学杨东梁教授主讲）《清末风云人物之革新篇》（首都师范大学迟云飞教授主讲）两部分，向学生揭示了这些英雄、或者枭雄的不为人知的方方面面，留给后人来细细品味，评判功过是非。《清末风云人物之危机篇》介绍了中国近代睁眼看世界的第一人林则徐、“反清第一英雄”洪秀全、统治中国半个世纪的慈禧太后、“旧教育之特产人物” 曾国藩、晚清“独一无二之代表人物”李鸿章。晚清一脉，上承秦汉以降王朝政治的余绪，下开数千年未有之大变局，可谓国史之关键转折。杨东梁教授研究清史数十年，从诸多庞杂的史料中还原历史真相，揭示历史规律，点评人物得失。"],
            "bigImgUrl":"http://p.ananas.chaoxing.com/star3/733_434c/568a330ce4b0e85354b34426.jpg",
            "videoUrl":"http://s1.ananas.chaoxing.com/video/8d/56a58d19e4b0e85354bc7211/sd.mp4",
            "courseChapter":[
                {
                    "中国近代睁眼看世界的第一人——林则徐":[
                        {"chapterNum":"1.1", "chapterName":"学习指导"},
                        {"chapterNum":"1.2", "chapterName":"关于林则徐的评价"},
                        {"chapterNum":"1.3", "chapterName":"林则徐生活的时代"},
                        {"chapterNum":"1.4", "chapterName":"封建时代的贤吏（一）"},
                        {"chapterNum":"1.5", "chapterName":"封建时代的贤吏（二）"},
                        {"chapterNum":"1.6", "chapterName":"杰出的民族英雄（一）"},
                        {"chapterNum":"1.7", "chapterName":"杰出的民族英雄（二）"},
                        {"chapterNum":"1.8", "chapterName":"走近人物"},
                        {"chapterNum":"1.9", "chapterName":"扩展阅读"}
                    ],
                    "“反清第一英雄”——洪秀全":[
                        {"chapterNum":"2.1", "chapterName":"学习指导"},
                        {"chapterNum":"2.2", "chapterName":"一位探索新道的年轻人（一）"},
                        {"chapterNum":"2.3", "chapterName":"一位探索新道的年轻人（二）"},
                        {"chapterNum":"2.4", "chapterName":"金田起义和战略决策"},
                        {"chapterNum":"2.5", "chapterName":"洪秀全的理想与追求"},
                        {"chapterNum":"2.6", "chapterName":"洪秀全在“天京事变”中的责任和教训"},
                        {"chapterNum":"2.7", "chapterName":"太平天国后期的洪秀全"},
                        {"chapterNum":"2.8", "chapterName":"走近人物"},
                        {"chapterNum":"2.9", "chapterName":"扩展阅读"}
                    ],
                    "统治中国半个世纪的慈禧太后":[
                        {"chapterNum":"3.1", "chapterName":"学习指导"},
                        {"chapterNum":"3.2", "chapterName":"慈禧的身世与入宫"},
                        {"chapterNum":"3.3", "chapterName":"政变和垂帘（一）"},
                        {"chapterNum":"3.4", "chapterName":"政变和垂帘（二）"},
                        {"chapterNum":"3.5", "chapterName":"善于学习、积累统治经验"},
                        {"chapterNum":"3.6", "chapterName":"慈禧与奕之间的明争暗斗"},
                        {"chapterNum":"3.7", "chapterName":"撤帘归政与二次“垂帘”"},
                        {"chapterNum":"3.8", "chapterName":"主战与主和"},
                        {"chapterNum":"3.9", "chapterName":"革新与守旧"},
                        {"chapterNum":"3.10", "chapterName":"走近人物"},
                        {"chapterNum":"3.11", "chapterName":"扩展阅读"}
                    ],
                    "曾国藩——“旧教育之特产人物”":[
                        {"chapterNum":"4.1", "chapterName":"学习指导"},
                        {"chapterNum":"4.2", "chapterName":"早年经历一帆风顺"},
                        {"chapterNum":"4.3", "chapterName":"曾国藩与太平天国"},
                        {"chapterNum":"4.4", "chapterName":"晚清近代化的发轫者"},
                        {"chapterNum":"4.5", "chapterName":"中国传统文化的典型代表"},
                        {"chapterNum":"4.6", "chapterName":"看人、用人和容人"},
                        {"chapterNum":"4.7", "chapterName":"内政内行、外交外行及“称帝”问题"},
                        {"chapterNum":"4.8", "chapterName":"走近人物"},
                        {"chapterNum":"4.9", "chapterName":"扩展阅读"}
                    ],
                    "李鸿章——晚清“独一无二之代表人物”":[
                        {"chapterNum":"5.1", "chapterName":"学习指导"},
                        {"chapterNum":"5.2", "chapterName":"从“独一无二”说起"},
                        {"chapterNum":"5.3", "chapterName":"少年科第和起家军旅"},
                        {"chapterNum":"5.4", "chapterName":"“征吴”和“平捻”"},
                        {"chapterNum":"5.5", "chapterName":"洋务自强、回天无术"},
                        {"chapterNum":"5.6", "chapterName":"晚清对外交涉的总代表"},
                        {"chapterNum":"5.7", "chapterName":"“秋风宝剑孤臣泪”——李鸿章的结局"},
                        {"chapterNum":"5.8", "chapterName":"走近人物"},
                        {"chapterNum":"5.9", "chapterName":"扩展阅读"}
                    ]
                }
            ]
        },
        {
            "courseid":"87130398",
            "courseName":"清末风云人物之革新篇",
            "typeOne":"学科素养",
            "typeTwo":"历史与文明",
            "keySpeakName":"迟云飞",
            "keySpeakUnivercity":"首都师范大学",
            "keySpeakPosition":"教授",
            "keySpeakIntroduce":"迟云飞：首都师范大学历史系教授，博士生导师，历史学专家。主要研究方向为中国近现代史，20世纪中国的政治发展，尤其是清末民国初的政治史。已出版专著两部，编著三部。 ",
            "courseIntroduce":["历史是由人创造的，历史人物研究便自然成为历史研究的主题之一。而中国近代史是影响中国发展的最重要的转折阶段，因此研究中国近代人物变成为了解中国那段最重要的历史的最佳途径。",
                "本系列课程分为《清末风云人物之危机篇》（中国人民大学杨东梁教授）、《清末风云人物之革新篇》（首都师范大学迟云飞教授）两部分。《清末风云人物之革新篇》这一课程所剖析的人物包括复辟帝制的袁世凯，民族实业家张謇，改变中国历史、" +
                "推翻千年封建王朝的孙中山，苦苦追求民主宪政、政党政治的宋教仁等四位清末风云人物。这些在中国的历史长河中留下自己深深印记的大人物，无论是英雄还是枭雄，他们那些不为人知的诸多历史细节，都留给后人来细细品味，评判功过是非。",
                "　　迟云飞教授将带领我们从诸多庞杂的史料中还原历史真相，揭示历史规律，点评人物得失。"],
            "bigImgUrl":"http://p.ananas.chaoxing.com/star3/733_434c/56e0c3fbe4b0b07fe6c78f66.png",
            "videoUrl":"http://s1.ananas.chaoxing.com/video/f1/56f9e704e4b0dfadae7cfcbe/sd.mp4",
            "courseChapter":[
                {
                    "军政权术家——袁世凯":[
                        {"chapterNum":"1.1", "chapterName":"学习指导"},
                        {"chapterNum":"1.2", "chapterName":"创建北洋军（一）"},
                        {"chapterNum":"1.3", "chapterName":"创建北洋军（二）"},
                        {"chapterNum":"1.4", "chapterName":"大力推动新政改革（一）"},
                        {"chapterNum":"1.5", "chapterName":"大力推动新政改革（二）"},
                        {"chapterNum":"1.6", "chapterName":"袁世凯军事政治集团（一）"},
                        {"chapterNum":"1.7", "chapterName":"袁世凯军事政治集团（二）"},
                        {"chapterNum":"1.8", "chapterName":"袁式政治及其失败（一）"},
                        {"chapterNum":"1.9", "chapterName":"袁式政治及其失败（二）"},
                        {"chapterNum":"1.10", "chapterName":"走近人物"},
                        {"chapterNum":"1.11", "chapterName":"扩展阅读"}
                    ],
                    "状元实业家——张謇":[
                        {"chapterNum":"2.1", "chapterName":"学习指导"},
                        {"chapterNum":"2.2", "chapterName":"状元、清流、帝党"},
                        {"chapterNum":"2.3", "chapterName":"状元张謇办实业"},
                        {"chapterNum":"2.4", "chapterName":"初期参加的政治活动"},
                        {"chapterNum":"2.5", "chapterName":"公开参加政治活动的士绅领袖（一）"},
                        {"chapterNum":"2.6", "chapterName":"公开参加政治活动的士绅领袖（二）"},
                        {"chapterNum":"2.7", "chapterName":"公开参加政治活动的士绅领袖（三）"},
                        {"chapterNum":"2.8", "chapterName":"恩恩怨怨袁世凯（一）"},
                        {"chapterNum":"2.9", "chapterName":"恩恩怨怨袁世凯（二）"},
                        {"chapterNum":"2.10", "chapterName":"走近人物"},
                        {"chapterNum":"2.11", "chapterName":"扩展阅读"}
                    ],
                    "革命先行者——孙中山":[
                        {"chapterNum":"3.1", "chapterName":"学习指导"},
                        {"chapterNum":"3.2", "chapterName":"独特的出身和早年经历"},
                        {"chapterNum":"3.3", "chapterName":"革命初期“边缘人”的革命"},
                        {"chapterNum":"3.4", "chapterName":"辛亥革命时期的三民主义（一）"},
                        {"chapterNum":"3.5", "chapterName":"辛亥革命时期的三民主义（二）"},
                        {"chapterNum":"3.6", "chapterName":"二十年代的政治思想（一）"},
                        {"chapterNum":"3.7", "chapterName":"二十年代的政治思想（二）"},
                        {"chapterNum":"3.8", "chapterName":"孙中山的特质和历史地位（一）"},
                        {"chapterNum":"3.9", "chapterName":"孙中山的特质和历史地位（二）"},
                        {"chapterNum":"3.10", "chapterName":"走近人物"},
                        {"chapterNum":"3.11", "chapterName":"扩展阅读"}
                    ],
                    "流星政治家——宋教仁":[
                        {"chapterNum":"4.1", "chapterName":"学习指导"},
                        {"chapterNum":"4.2", "chapterName":"书生革命"},
                        {"chapterNum":"4.3", "chapterName":"民族主义新知识人（一）"},
                        {"chapterNum":"4.4", "chapterName":"民族主义新知识人（二）"},
                        {"chapterNum":"4.5", "chapterName":"革命活动和革命方略"},
                        {"chapterNum":"4.6", "chapterName":"宋教仁的民主宪政思想（一）"},
                        {"chapterNum":"4.7", "chapterName":"宋教仁的民主宪政思想（二）"},
                        {"chapterNum":"4.8", "chapterName":"宋教仁的民主宪政思想（三）"},
                        {"chapterNum":"4.9", "chapterName":"宋教仁的民主宪政思想（四）"},
                        {"chapterNum":"4.10", "chapterName":"为宪法流血"},
                        {"chapterNum":"4.11", "chapterName":"扩展阅读"},
                        {"chapterNum":"4.12", "chapterName":"走近人物"}
                    ]
                }
            ]
        },
        {
            "courseid":"82714317",
            "courseName":"黑客来了——移动互联网攻防战",
            "typeOne":"学科素养",
            "typeTwo":"科学与技术",
            "keySpeakName":"陈波",
            "keySpeakUnivercity":"南京师范大学",
            "keySpeakPosition":"教授",
            "keySpeakIntroduce":"1994年南京师范大学计算机专业本科毕业，获得理学学士学位，留校任教。先后获得南京师范大学硕士学位，解放军理工大学博士学位。2013年澳大利亚Macquarie University访问学者。现为南京师范大学计算机科学与技术学院网络与信息安全系主任、软件工程专业负责人，中国计算机学会高级会员，江苏省计算机学会计算机安全专业委员会常务委员，中国密码学会会员。" +
            "参加工作以来，一直从事计算机专业的教学和科研工作，主要研究方向是网络信息安全、社会计算等。主持江苏省产学研联合创新资金项目、省教育科学规划十二五重点资助项目、江苏省高校自然科学基金等项目，主持完成多项网络安全科技开发项目，参与国家自然科学基金、省自然科学基金项目多项。在一级学报等重要期刊和国际会议发表科研论文五十多篇，获得软件著作权4项。" +
            "作为课程主持人，2010年“《信息安全》课程教学的改革创新与大学生信息安全素质的培养”获南京师范大学优秀教学成果二等奖。主编出版教材7部，被列为省级精品建设教材1部，获得南京师范大学精品教材奖励1部，被列为重点建设教材2部。2013年微课视频“数字证书的概念及在网络身份鉴别中的应用”获省级微课大赛二等奖。 ",
            "courseIntroduce":["网络安全问题已经成为全民热点问题，神秘的黑客究竟能造成多大的灾难？！",
                "你的电脑、你的U盘等设备安全吗？移动互联网时代的信息安全应如何防护？",
                "课程从著名的网络黑客攻击事件入手，阐述了信息安全威胁、设备和环境安全、身份和访问安全等几个方面。涵盖从硬件到软件，从主机到网络，从数据到内容等不同层次的安全问题及解决手段。",
            "本课程共分为3章16小节，共计8个课时 ，满分100分，学生成绩达60分及以上，视为通过，可得到2学分。"],
            "bigImgUrl":"http://p.ananas.chaoxing.com/star3/733_434c/5617aa08498e9c25ac53adb6.jpg",
            "videoUrl":"http://s1.ananas.chaoxing.com/video/7c/569c8b9de4b0e85354b9526b/sd.mp4",
            "courseChapter":[
                {
                    "信息安全威胁":[
                        {"chapterNum":"1.1", "chapterName":"斯诺登事件"},
                        {"chapterNum":"1.2", "chapterName":"网络空间威胁"},
                        {"chapterNum":"1.3", "chapterName":"你的电脑安全吗？"},
                        {"chapterNum":"1.4", "chapterName":"伊朗核设施瘫痪事件"}
                    ],
                    "计算机设备与环境安全":[
                        {"chapterNum":"2.1", "chapterName":"迪拜哈利法塔的机房"},
                        {"chapterNum":"2.2", "chapterName":"设备面临什么安全问题"},
                        {"chapterNum":"2.3", "chapterName":"设备防盗技术"},
                        {"chapterNum":"2.4", "chapterName":"u盘使用中有什么安全隐患"},
                        {"chapterNum":"2.5", "chapterName":"移动存储设备安全问题解决"}
                    ],
                    "身份与访问安全":[
                        {"chapterNum":"3.1", "chapterName":"网站用户密码泄露事件"},
                        {"chapterNum":"3.2", "chapterName":"什么是身份认证"},
                        {"chapterNum":"3.3", "chapterName":"身份认证安全吗"},
                        {"chapterNum":"3.4", "chapterName":"身份认证技术的提高"},
                        {"chapterNum":"3.5", "chapterName":"网站真假如何辨别"},
                        {"chapterNum":"3.6", "chapterName":"什么是数字证书"},
                        {"chapterNum":"3.7", "chapterName":"12306网站的问题"}
                    ]
                }
            ]
        },
        {
            "courseid":"85964197",
            "courseName":"转基因食品，你吃吗？",
            "typeOne":"学科素养",
            "typeTwo":"科学与技术",
            "keySpeakName":"黄耀江",
            "keySpeakUnivercity":"中央民族大学",
            "keySpeakPosition":"教授",
            "keySpeakIntroduce":" 黄耀江博士,北京食品环境与健康工程技术研究中心主任,中国少数民族健康产业技术创新战略联盟执行理事he秘书长，中国民族健康产业创新协会（筹）执行理事秘书长，新世纪优秀人才，耶鲁大学（美）客座教授，黄耀江先后在吉大、大连理工、军事医学科学院、中科院学习或工作，2004年调入中央民族大学。" +
            "曾参与863、973、总后重点和国家杰青等课题。先后主持省级重点等5项课题，承担211、985、111等计划子项目及教改项目各1项。发表论文30余篇；省部级奖4项；国家发明3项；省部级成果3项；著作2部；知识产权评估报告1项。主要承担《生物化学》、《医学生物化学》、《生物信息学》及研究生《高级生物化学》的教学工作。校公选课有《人类基因组与人类健康》及《探索发现－生命的奥秘、人类基因组与人类健康》。",
            "courseIntroduce":["随着生物技术的发展，食物呈现多样化，圣女果、彩椒、小南瓜、小黄瓜等新品种越来越多，转基因木瓜、土豆、大米、玉米、大豆等食物所占的比例也在不断增大，方舟子和崔永元在微薄上就转基因食品的安全性展开了口水大战，那么国家正式批准生产或进口的转基因作物有哪些？网上流传的“转基因食品名单”靠不靠谱？一些所谓“鉴别转基因作物的方法”正确吗？如何正确对待转基因食品？黄教授将带领大家正确认识转基因。"],
            "bigImgUrl":"http://p.ananas.chaoxing.com/star3/733_434c/5678e98be4b0e85354a8eb77.jpg",
            "videoUrl":"http://s1.ananas.chaoxing.com/video/55/56d3d080e4b0dfadae77c721/sd.mp4",
            "courseChapter":[
                {
                    "我们的食品安全吗":[{"chapterNum":"1.1", "chapterName":"虎视眈眈"}],
                    "半截老玉米引发的血案":[
                        {"chapterNum":"2.1", "chapterName":"方舟子遇到崔永元"},
                        {"chapterNum":"2.2", "chapterName":"再议“崔方大战”"}
                    ],
                    "转基因食品现状":[
                        {"chapterNum":"3.1", "chapterName":"你身边的转基因食品"},
                        {"chapterNum":"3.2", "chapterName":"非传统食品即转基因？"},
                        {"chapterNum":"3.3", "chapterName":"转基因网络谣言"},
                        {"chapterNum":"3.4", "chapterName":"转基因木瓜、棉花"},
                        {"chapterNum":"3.5", "chapterName":"转基因大豆、玉米"}
                    ],
                    "转基因育种与传统育种, 孰是孰非？":[
                        {"chapterNum":"4.1", "chapterName":"当代神农氏"},
                        {"chapterNum":"4.2", "chapterName":"喜看稻菽千重浪 最是风流袁隆平？"},
                        {"chapterNum":"4.3", "chapterName":"杂交说"},
                        {"chapterNum":"4.4", "chapterName":"袁隆平看转基因"},
                        {"chapterNum":"4.5", "chapterName":"科学家看转基因"}
                    ],
                    "如何对待转基因食品":[
                        {"chapterNum":"5.1", "chapterName":"转基因食品可怕吗"},
                        {"chapterNum":"5.2", "chapterName":"转基因之我见"}
                    ]
                }
            ]
        },
        {
            "courseid":"86560999",
            "courseName":"指纹与DNA的秘密",
            "typeOne":"学科素养",
            "typeTwo":"科学与技术",
            "keySpeakName":"黄耀江",
            "keySpeakUnivercity":"中央民族大学",
            "keySpeakPosition":"教授",
            "keySpeakIntroduce":" 黄耀江博士,北京食品环境与健康工程技术研究中心主任,中国少数民族健康产业技术创新战略联盟执行理事he秘书长，中国民族健康产业创新协会（筹）执行理事秘书长，新世纪优秀人才，耶鲁大学（美）客座教授，黄耀江先后在吉大、大连理工、军事医学科学院、中科院学习或工作，2004年调入中央民族大学。" +
            "曾参与863、973、总后重点和国家杰青等课题。先后主持省级重点等5项课题，承担211、985、111等计划子项目及教改项目各1项。发表论文30余篇；省部级奖4项；国家发明3项；省部级成果3项；著作2部；知识产权评估报告1项。主要承担《生物化学》、《医学生物化学》、《生物信息学》及研究生《高级生物化学》的教学工作。校公选课有《人类基因组与人类健康》及《探索发现－生命的奥秘、人类基因组与人类健康》。",
            "courseIntroduce":["说到指纹，你可能会想到指纹考勤，想到路边的手相占卜，想到刑侦案件里的指纹采集，想到影视里的指纹识别。谈到DNA，你可能会想到亲子鉴定、想到灾难里的遗体识别、想到刑侦里的DNA提取。指纹与DNA到底有何奥秘呢？让我们一探究竟。"],
            "bigImgUrl":"http://p.ananas.chaoxing.com/star3/733_434c/569f1bc4e4b0e85354ba5f9a.png",
            "videoUrl":"http://s1.ananas.chaoxing.com/video/79/56cd78c2712e9c921a652d0b/sd.mp4",
            "courseChapter":[
                {
                    "异常的指纹":[
                        {"chapterNum":"1.1", "chapterName":"银行里的枪声"},
                        {"chapterNum":"1.2", "chapterName":"皮纹学是迷信吗？"},
                        {"chapterNum":"1.3", "chapterName":"指纹的分类"},
                        {"chapterNum":"1.4", "chapterName":"指纹与性格命运"},
                        {"chapterNum":"1.5", "chapterName":"指纹组合"},
                        {"chapterNum":"1.6", "chapterName":"先天愚型的指纹特征"},
                        {"chapterNum":"1.7", "chapterName":"纹线证据"},
                        {"chapterNum":"1.8", "chapterName":"指纹与神经系统的关联"},
                        {"chapterNum":"1.9", "chapterName":"枪击案后的真凶"}
                    ],
                    "DNA指纹——现代的福尔摩斯":[
                        {"chapterNum":"2.1", "chapterName":"DNA指纹鉴别技术"},
                        {"chapterNum":"2.2", "chapterName":"遗传学基础"},
                        {"chapterNum":"2.3", "chapterName":"用于司法调查"},
                        {"chapterNum":"2.4", "chapterName":"用于身份鉴定"},
                        {"chapterNum":"2.5", "chapterName":"DNA指纹鉴别技术"},
                        {"chapterNum":"2.6", "chapterName":"法医昆虫学——确定死亡时间"},
                        {"chapterNum":"2.7", "chapterName":"美国总统历代绯闻"}
                    ]
                }
            ]
        },
        {
            "courseid":"86389910",
            "courseName":"从经典物理学到相对论",
            "typeOne":"学科素养",
            "typeTwo":"科学与技术",
            "keySpeakName":"赵峥",
            "keySpeakUnivercity":"北京师范大学",
            "keySpeakPosition":"教授",
            "keySpeakIntroduce":"研究领域: 赵峥教授长期从事理论物理的教学与研究，为本科生和研究生讲授过统计物理、量子力学、近代物理学进展、物理学史、广义相对论、黑洞物理学和弯曲时空量子场论等课程；赵峥教授长期从事理论物理的教学与研究，为本科生和研究生讲授过统计物理、量子力学、近代物理学进展、物理学史、广义相对论、黑洞物理学和弯曲时空量子场论等课程。近年来同时在清华大学和北京师范大学讲授广义相对论。" +
            "论文与著作：参加和承担过多项国家自然科学基金项目，在相对论、黑洞物理等领域发表论文100余篇，在黑洞热性质、时空奇点、时间测量理论、钟速同步和热力学的关系等方面有创新性的工作。1986年、1996年两次获国家教委科技进步二等奖。主要著作有《黑洞的热性质与时空奇异性》、《黑洞与弯曲的时空》、《相对论问答录》，科普著作有《探求上帝的秘密-从哥白尼到爱因斯坦》、《物理学与人类文明》，其中《黑洞的热性质与时空奇异性》和《探求上帝的秘密》分获第11届和第12届中国图书奖。《黑洞与弯曲的时空》和《物理学与人类文明》2005年被中国物理学会选为世界物理年推荐书籍。" +
            "荣誉与奖励：近年来同时在清华大学和北京师范大学讲授广义相对论。参加和承担过多项国家自然科学基金项目，在相对论、黑洞物理等领域发表论文100余篇，在黑洞热性质、时空奇点、时间测量理论、钟速同步和热力学的关系等方面有创新性的工作。1986年、1996年两次获国家教委科技进步二等奖。",
            "courseIntroduce":["由伽利略(1564—1642)和牛顿(1642—1727)等人于17世纪创立的经典物理学，经过18世纪在各个基础部门的拓展，到19世纪得到了全面、系统和迅速的发展，达到了它辉煌的顶峰。然而，此刻在物理学的万里晴空中却飘来了两朵乌云，物理学上出现了一系列新的发现。这些无法用经典物理学解释的新发现，使经典物理学陷入了危机。第一朵与迈克尔逊实验有关，第二朵与黑体辐射有关。正是这两朵乌云的飘动，引来了20世纪物理学革命的暴风骤雨，使整个自然科学进入了一个崭新的阶段。这“两朵乌云”成为20世纪伟大物理学革命的导火线。",
                "事隔不到一年，就从第一朵乌云中降生了相对论，紧接着从第二朵乌云中降生了量子论，经典物理学的大厦被彻底动摇。相对论妇孺皆知的方程式就是“质能方程”, 数学表达式为：E=mc2（E 能量 m 质量 c 光速）。 由于c的平方是一个很大的数，所以一个很小的质量都可以爆发出很大的能量。它的一项后果是使人们意识到，如果铀原子核裂变成总质量稍小的两个核，就会释放出巨大的能量，即核裂变，这也是原子弹的能量释放的原理。"],
            "bigImgUrl":"http://p.ananas.chaoxing.com/star3/733_434c/5694abade4b0e85354b70214.jpg",
            "videoUrl":"http://s1.ananas.chaoxing.com/video/d2/569cb355e4b0e85354b95cf6/sd.mp4",
            "courseChapter":[
                {
                    "从经验物理到经典物理学":[
                        {"chapterNum":"1.1", "chapterName":"物理学的开端：经验物理时期"},
                        {"chapterNum":"1.2", "chapterName":"伽利略与经典物理学的诞生"},
                        {"chapterNum":"1.3", "chapterName":"经典物理的三大支柱：经典力学、经典电动力学、经典热力学和统计力学"},
                        {"chapterNum":"1.4", "chapterName":"经典物理的局限与量子论的诞生"}
                    ],
                    "爱因斯坦与相对论的诞生":[
                        {"chapterNum":"2.1", "chapterName":"爱因斯坦生平与科学贡献（一）"},
                        {"chapterNum":"2.2", "chapterName":"爱因斯坦生平与科学贡献（二）"},
                        {"chapterNum":"2.3", "chapterName":"迈克尔逊实验、洛伦兹变换与相对论的建立"},
                        {"chapterNum":"2.4", "chapterName":"相对论的几个结论"},
                        {"chapterNum":"2.5", "chapterName":"爱因斯坦等人对相对论诞生的贡献"}
                    ],
                    "相对论和原子弹":[
                        {"chapterNum":"3.1", "chapterName":"中子的发现"},
                        {"chapterNum":"3.2", "chapterName":"裂变与链式反应"},
                        {"chapterNum":"3.3", "chapterName":"原子弹研制的背景（一）"},
                        {"chapterNum":"3.4", "chapterName":"原子弹研制的背景（二）"},
                        {"chapterNum":"3.5", "chapterName":"原子弹的研制"},
                        {"chapterNum":"3.6", "chapterName":"原子弹的运用与氢弹的研制"},
                        {"chapterNum":"3.7", "chapterName":"中国原子弹和氢弹的研制"},
                        {"chapterNum":"3.8", "chapterName":"原子能的和平利用"}
                    ]
                }
            ]
        },
        {
            "courseid":"86561816",
            "courseName":"从爱因斯坦到霍金的宇宙（下）",
            "typeOne":"学科素养",
            "typeTwo":"科学与技术",
            "keySpeakName":"赵峥",
            "keySpeakUnivercity":"北京师范大学",
            "keySpeakPosition":"教授",
            "keySpeakIntroduce":"研究领域: 赵峥教授长期从事理论物理的教学与研究，为本科生和研究生讲授过统计物理、量子力学、近代物理学进展、物理学史、广义相对论、黑洞物理学和弯曲时空量子场论等课程；赵峥教授长期从事理论物理的教学与研究，为本科生和研究生讲授过统计物理、量子力学、近代物理学进展、物理学史、广义相对论、黑洞物理学和弯曲时空量子场论等课程。近年来同时在清华大学和北京师范大学讲授广义相对论。" +
            "论文与著作：参加和承担过多项国家自然科学基金项目，在相对论、黑洞物理等领域发表论文100余篇，在黑洞热性质、时空奇点、时间测量理论、钟速同步和热力学的关系等方面有创新性的工作。1986年、1996年两次获国家教委科技进步二等奖。主要著作有《黑洞的热性质与时空奇异性》、《黑洞与弯曲的时空》、《相对论问答录》，科普著作有《探求上帝的秘密-从哥白尼到爱因斯坦》、《物理学与人类文明》，其中《黑洞的热性质与时空奇异性》和《探求上帝的秘密》分获第11届和第12届中国图书奖。《黑洞与弯曲的时空》和《物理学与人类文明》2005年被中国物理学会选为世界物理年推荐书籍。" +
            "荣誉与奖励：近年来同时在清华大学和北京师范大学讲授广义相对论。参加和承担过多项国家自然科学基金项目，在相对论、黑洞物理等领域发表论文100余篇，在黑洞热性质、时空奇点、时间测量理论、钟速同步和热力学的关系等方面有创新性的工作。1986年、1996年两次获国家教委科技进步二等奖。",
            "courseIntroduce":["人类从“地心说”的认识水平发展到“日心说”理论，花了近1000多年的时间，其中布鲁诺为此付出了生命；从牛顿的绝对时空到爱因斯坦的相对论时空用了几百年的时间;之后又有霍金探讨了宇宙的起点和终点。观念在人们心中不停地改变，但是探索宇宙奥秘的脚步却从未停止。"],
            "bigImgUrl":"http://p.ananas.chaoxing.com/star3/733_434c/56ab2068e4b0e85354be4342.jpg",
            "videoUrl":"http://s1.ananas.chaoxing.com/video/6f/5537768be4b0199d270497c9/sd.mp4",
            "courseChapter":[
                {
                    "白矮星、中子星与黑洞":[
                        {"chapterNum":"1.1", "chapterName":"黑洞的理论预言"},
                        {"chapterNum":"1.2", "chapterName":"恒星的演化与白矮星的形成"},
                        {"chapterNum":"1.3", "chapterName":"白矮星的相关研究"},
                        {"chapterNum":"1.4", "chapterName":"中子星的发现与相关研究"},
                        {"chapterNum":"1.5", "chapterName":"黑洞的形成与性质（一）"},
                        {"chapterNum":"1.6", "chapterName":"黑洞的形成与性质（二）"},
                        {"chapterNum":"1.7", "chapterName":"霍金之前的黑洞研究"},
                        {"chapterNum":"1.8", "chapterName":"霍金的主要成就"},
                        {"chapterNum":"1.9", "chapterName":"黑洞的其他研究"}
                    ],
                    "相对论宇宙学":[
                        {"chapterNum":"2.1", "chapterName":"星空与太阳系（一）"},
                        {"chapterNum":"2.2", "chapterName":"星空与太阳系（二）"},
                        {"chapterNum":"2.3", "chapterName":"膨胀的宇宙"},
                        {"chapterNum":"2.4", "chapterName":"大爆炸宇宙模型"},
                        {"chapterNum":"2.5", "chapterName":"关于大爆炸学说的一些错误认识"},
                        {"chapterNum":"2.6", "chapterName":"虫洞和时空隧道"},
                        {"chapterNum":"2.7", "chapterName":"时间机器的可能性"},
                        {"chapterNum":"2.8", "chapterName":"时间的性质"}
                    ]
                }
            ]
        },
        {
            "courseid":"86340108",
            "courseName":"数学的奥秘：本质与思维",
            "typeOne":"学科素养",
            "typeTwo":"科学与技术",
            "keySpeakName":"王维克",
            "keySpeakUnivercity":"上海交通大学",
            "keySpeakPosition":"教授",
            "keySpeakIntroduce":"武汉大学理学博士，1993年被聘为教授， 1997－2000年期间曾任武汉大学数学系主任，数学与计算机科学学院院长，2002年－2009年期间曾任上海交通大学数学系主任。现为上海交通大学特聘教授，中国数学会常务理事，上海工业和应用数学会副理事长，国际数学杂志《Communications on Pure and Applied Analysis》合作主编。" +
            "长期担任数学系《数学分析》和《文科数学》课程教学， 2011年获上海高校教学名师奖。2012年主讲通识课《数学之旅》遴选为教育部 “精品视频公开课”。2014年获宝钢优秀教师特等奖提名奖。2014年作为主要参加者获得教育部教学成果一等奖。长期从事于偏微分方程的研究，2011年主持获得上海市自然科学一等奖。",
            "courseIntroduce":["数学的重要特征是它的抽象性，这一特征是令人生畏的,但也正是这一特征可以使人们在繁杂的世界中逐步懂得宇宙深处伟大设计者的语言；可以用理性的思维达到超出人类感官所及的宇宙的根本，这正是数学的魅力所在，也是数学在人类历史上起着其它科学不可替代作用的重要原因。本课将和学生一起从思想上重走一遍前辈们走过的路，我们不断揭示一些概念和数学思想形成的过程和历史，理解数学抽象的必要性和魅力，" +
            "真实体会数学抽象所表现出的人类心智的荣耀，潜移默化地从中培养数学抽象的能力。"],
            "bigImgUrl":"http://p.ananas.chaoxing.com/star3/733_434c/5683844a498e69718a39cdb4.png",
            "videoUrl":"http://s1.ananas.chaoxing.com/video/40/55ebff6b712e01a28cc6f6e2/sd.mp4",
            "courseChapter":[
                {
                    "心智的荣耀---数学是什么？":[
                        {"chapterNum":"1.1", "chapterName":"开头的话"},
                        {"chapterNum":"1.2", "chapterName":"数学思维"},
                        {"chapterNum":"1.3", "chapterName":"数学学习"}
                    ],
                    "从圆的面积谈起---微积分导论":[
                        {"chapterNum":"2.1", "chapterName":"从圆的面积谈起"},
                        {"chapterNum":"2.2", "chapterName":"曲线的切线斜率"},
                        {"chapterNum":"2.3", "chapterName":"微积分的工具和思想"},
                        {"chapterNum":"2.4", "chapterName":"微积分的历程"}
                    ],
                    "无穷是个新世界---自然数与实数":[
                        {"chapterNum":"3.1", "chapterName":"梵塔之谜"},
                        {"chapterNum":"3.2", "chapterName":"希尔伯特旅馆"},
                        {"chapterNum":"3.3", "chapterName":"有理数的“空隙”"},
                        {"chapterNum":"3.4", "chapterName":"无穷集合的基数"}
                    ],
                    "运动进入数学---极限理论":[
                        {"chapterNum":"3.1", "chapterName":"从图片到电影---极限"},
                        {"chapterNum":"3.2", "chapterName":"视频截屏---极限的算术化"},
                        {"chapterNum":"3.3", "chapterName":"阿基米德的智慧"}
                    ]
                }
            ]
        },
        {
            "courseid":"81090133",
            "courseName":"穿T恤听古典音乐",
            "typeOne":"兴趣技能",
            "typeTwo":"艺术鉴赏",
            "keySpeakName":"田艺苗",
            "keySpeakUnivercity":"上海交通大学",
            "keySpeakPosition":"副教授",
            "keySpeakIntroduce":"田艺苗教师;单位：上海音乐学院;职位：副教授",
            "courseIntroduce":["在公民的文化程度不断提升的今天，快餐式的流行音乐已不能满足人们的文化需求，因此对于“古典”回归的呼声也日益增高。“穿T恤听古典音乐”是在分享一种生活方式。如今我们不需要买高昂的门票，穿着礼服和高跟鞋去剧院才可以听到古典音乐。我们可以在家，穿着T恤听，穿着拖鞋听。其实，" +
            "穿什么听古典音乐只是一种表面的形式，我们要把听古典音乐作为一种生活方式，像穿T恤、穿牛仔一样是一种生活方式，去自由的聆听，不再拘泥于欣赏艺术的形式。自由的状态下我们才可以更有创意，才可以听到的更多。"],
            "bigImgUrl":"http://p.ananas.chaoxing.com/star3/733_434c/55e01849498e3b44554a69a4.jpg",
            "videoUrl":"http://s1.ananas.chaoxing.com/video/81/55e50f73e4b030b228d94ebd/sd.mp4",
            "courseChapter":[
                {
                    "走进古典音乐":[
                        {"chapterNum":"1.1", "chapterName":"音乐中的自然法则"},
                        {"chapterNum":"1.2", "chapterName":"音乐要素如何模仿"},
                        {"chapterNum":"1.3", "chapterName":"模仿与超越"}
                    ],
                    "每一天的巴赫":[
                        {"chapterNum":"2.1", "chapterName":"巴赫的故事与作品"},
                        {"chapterNum":"2.2", "chapterName":"对位法"},
                        {"chapterNum":"2.3", "chapterName":"数学之美"}
                    ],
                    "莫扎特：把日子过成歌剧":[
                        {"chapterNum":"3.1", "chapterName":"《莫扎特传》序曲——唐璜"},
                        {"chapterNum":"3.2", "chapterName":"历史地位与风格演变"},
                        {"chapterNum":"3.3", "chapterName":"咏叹调与宣叙调"},
                        {"chapterNum":"3.4", "chapterName":"《后宫诱逃》"},
                        {"chapterNum":"3.5", "chapterName":"《女人心》"},
                        {"chapterNum":"3.6", "chapterName":"《唐璜序曲》"},
                        {"chapterNum":"3.7", "chapterName":"《费加罗的婚礼》"},
                        {"chapterNum":"3.8", "chapterName":"《魔笛》"}
                    ],
                    "贝多芬日记":[
                        {"chapterNum":"4.1", "chapterName":"贝多芬小传"},
                        {"chapterNum":"4.2", "chapterName":"征服维也纳"},
                        {"chapterNum":"4.3", "chapterName":"圣城遗言"},
                        {"chapterNum":"4.4", "chapterName":"悲怆奏鸣曲"},
                        {"chapterNum":"4.5", "chapterName":"热情奏鸣曲"}
                    ],
                    "李斯特的人生大戏":[
                        {"chapterNum":"5.1", "chapterName":"钢琴家李斯特"},
                        {"chapterNum":"5.2", "chapterName":"作曲家李斯特"},
                        {"chapterNum":"5.3", "chapterName":"情人李斯特"},
                        {"chapterNum":"5.4", "chapterName":"神甫李斯特"},
                        {"chapterNum":"5.5", "chapterName":"一代宗师李斯特"}
                    ],
                    "卡门：作为一种命运的爱情":[
                        {"chapterNum":"6.1", "chapterName":"卡门序曲与第一幕"},
                        {"chapterNum":"6.2", "chapterName":"卡门第二幕"},
                        {"chapterNum":"6.3", "chapterName":"卡门第三幕和第四幕"},
                        {"chapterNum":"6.4", "chapterName":"卡门与梅里美原著相比"}
                    ],
                    "雾中的勃拉姆斯":[
                        {"chapterNum":"7.1", "chapterName":"勃拉姆斯印象"},
                        {"chapterNum":"7.2", "chapterName":"勃拉姆斯的音乐生活"},
                        {"chapterNum":"7.3", "chapterName":"勃拉姆斯的交响乐"},
                        {"chapterNum":"7.4", "chapterName":"新德意志乐派之争"}
                    ],
                    "舒曼与克拉拉":[
                        {"chapterNum":"8.1", "chapterName":"舒曼与克拉拉人物生平"},
                        {"chapterNum":"8.2", "chapterName":"舒曼与克拉拉的爱情故事"},
                        {"chapterNum":"8.3", "chapterName":"舒曼的音乐作品"},
                        {"chapterNum":"8.4", "chapterName":"女钢琴家的悲欢"}
                    ],
                    "普契尼歌剧":[
                        {"chapterNum":"9.1", "chapterName":"图兰朵"},
                        {"chapterNum":"9.2", "chapterName":"波西米亚人"}
                    ],
                    "开车跑步听什么":[
                        {"chapterNum":"10.1", "chapterName":"开车听什么"},
                        {"chapterNum":"10.2", "chapterName":"跑步听什么"},
                        {"chapterNum":"10.3", "chapterName":"有效曲目单"},
                        {"chapterNum":"10.4", "chapterName":"音乐治疗"}
                    ]
                }
            ]
        },
        {
            "courseid":"81088493",
            "courseName":"民歌鉴赏（上）",
            "typeOne":"兴趣技能",
            "typeTwo":"艺术鉴赏",
            "keySpeakName":"孟超美",
            "keySpeakUnivercity":"南开大学",
            "keySpeakPosition":"教授",
            "keySpeakIntroduce":"孟超美，南开大学文学院文化素质教学部教授，承担多门全校性音乐类公共选修课程，并兼任校内外多个合唱团的指挥及指导工作。曾带合唱团出访美国、俄罗斯、西班牙、意大利、法国、韩国、日本、德国、奥地利、荷兰、比利时、台湾、香港、北京、上海、南京、杭州、厦门、哈尔滨等地比赛和交流演出，其传略已入选《中国音乐家词典》（人民出版社2005年版）和《艺术中国》（中国画报出版社2006年版）。" +
            "论文与著作:《走进音乐殿堂》第一作者（1999年南开大学出版社出版）；《民族音乐之根——中国民歌鉴赏》独著（2002年天津人民美术出版社出版）；《大学生合唱与指挥艺术修养》独著（2003年南开大学出版社出版）；《华夏文化大观——古代卷》参与章节写作（2007年百花文艺出版社出版）；《中国之声——记南开大学学生合唱团及获奖作品》主编（2009年安徽音乐出版社出版）." +
            "荣誉与奖励:指挥的南开大学学生合唱团——暨天津市大学生合唱团；1997年在天津市第三届合唱艺术节上获一等奖；1998年在北京第四届中国国际合唱节上获最高奖——演唱奖；1999年在首届全国大学生艺术节上获合唱一等奖；2000年在北京第五届中国国际合唱节上获银奖；2002年在第二届世界奥林匹克合唱比赛中获青年混声合唱银奖、无伴奏民谣合唱金奖及有表演民谣合唱金奖冠军；2004年在德国艾森费尔德国际合唱邀请赛上获欧洲传统合唱冠军、民谣合唱亚军；" +
            "2004年在第二届世界奥林匹克合唱比赛中获有表演民谣合唱、女声合唱及传统宗教合唱三项金奖；2005年在教育部举办的首届全国大学生艺术展演中获声乐类节目一等奖第一名；2007年在天津市大学生艺术展演中获大合唱、小合唱两项比赛的第一名；2009年在教育部举办的第二届全国大学生艺术展演中再获声乐类节目冠军；",
            "courseIntroduce":["中国民歌作为一种古老的艺术形式，历经几十年、数百年的沉淀，已成为中华民族文化的瑰宝。然而，在现行教育体制下，很多青年学生对中国民歌却知之甚少，对中国的音乐传统知之甚少。本课通过学习民歌的多种形式与种类，以及它与其它艺术门类的关系，旨在引导学生了解中华民族优秀的音乐文化遗产，并通过亲自演唱，感受民歌的魅力，认识民歌的价值，从而更激发青年学生对祖国和人民的热爱，以及强烈的民族自豪感。"],
            "bigImgUrl":"http://p.ananas.chaoxing.com/star3/733_434c/55fd512b498ed981287e83a2.png",
            "videoUrl":"http://s1.ananas.chaoxing.com/video/db/55d4241de4b0529fd54022b2/sd.mp4",
            "courseChapter":[
                {
                    "民歌发展概况":[
                        {"chapterNum":"1.1", "chapterName":"民歌的产生"},
                        {"chapterNum":"1.2", "chapterName":"民歌的发展（一）：历史的足迹"},
                        {"chapterNum":"1.3", "chapterName":"民歌的发展（二）：民族性的体现"},
                        {"chapterNum":"1.4", "chapterName":"民歌的发展（三）：经典赏析"},
                        {"chapterNum":"1.5", "chapterName":"民歌的创作特征（一）:整体特色"},
                        {"chapterNum":"1.6", "chapterName":"民歌的创作特征（二）:经典赏析"}
                    ],
                    "民歌的题材分类":[
                        {"chapterNum":"2.1", "chapterName":"反映社会斗争的民歌"},
                        {"chapterNum":"2.2", "chapterName":"反映生产劳动的民歌"},
                        {"chapterNum":"2.3", "chapterName":"反映爱情生活的民歌（一）：情歌的分类"},
                        {"chapterNum":"2.4", "chapterName":"反映爱情生活的民歌（二）：情歌的传说"},
                        {"chapterNum":"2.5", "chapterName":"反映日常生活及吆喝叫卖的民歌"},
                        {"chapterNum":"2.6", "chapterName":"用生活常识启智、逗趣的民歌"},
                        {"chapterNum":"2.7", "chapterName":"叙述故事、描绘景物的民歌"},
                        {"chapterNum":"2.8", "chapterName":"歌颂英雄领袖的民歌"},
                        {"chapterNum":"2.9", "chapterName":"儿歌与摇儿歌"}
                    ],
                    "民歌的体裁分类——号子":[
                        {"chapterNum":"3.1", "chapterName":"号子之搬运号子"},
                        {"chapterNum":"3.2", "chapterName":"号子之工程号子"},
                        {"chapterNum":"3.3", "chapterName":"号子之农事号子"},
                        {"chapterNum":"3.4", "chapterName":"号子之船渔号子"}
                    ],
                    "民歌的体裁分类——山歌":[
                        {"chapterNum":"4.1", "chapterName":"山歌之矮腔山歌（一）：自由性的特征"},
                        {"chapterNum":"4.2", "chapterName":"山歌之矮腔山歌（二）：经典赏析"},
                        {"chapterNum":"4.3", "chapterName":"山歌之平腔山歌"},
                        {"chapterNum":"4.4", "chapterName":"山歌之高腔山歌"}
                    ]
                }
            ]
        },
        {
            "courseid":"81101308",
            "courseName":"民歌鉴赏（下）",
            "typeOne":"兴趣技能",
            "typeTwo":"艺术鉴赏",
            "keySpeakName":"孟超美",
            "keySpeakUnivercity":"南开大学",
            "keySpeakPosition":"教授",
            "keySpeakIntroduce":"孟超美，南开大学文学院文化素质教学部教授，承担多门全校性音乐类公共选修课程，并兼任校内外多个合唱团的指挥及指导工作。曾带合唱团出访美国、俄罗斯、西班牙、意大利、法国、韩国、日本、德国、奥地利、荷兰、比利时、台湾、香港、北京、上海、南京、杭州、厦门、哈尔滨等地比赛和交流演出，其传略已入选《中国音乐家词典》（人民出版社2005年版）和《艺术中国》（中国画报出版社2006年版）。" +
            "论文与著作:《走进音乐殿堂》第一作者（1999年南开大学出版社出版）；《民族音乐之根——中国民歌鉴赏》独著（2002年天津人民美术出版社出版）；《大学生合唱与指挥艺术修养》独著（2003年南开大学出版社出版）；《华夏文化大观——古代卷》参与章节写作（2007年百花文艺出版社出版）；《中国之声——记南开大学学生合唱团及获奖作品》主编（2009年安徽音乐出版社出版）." +
            "荣誉与奖励:指挥的南开大学学生合唱团——暨天津市大学生合唱团；1997年在天津市第三届合唱艺术节上获一等奖；1998年在北京第四届中国国际合唱节上获最高奖——演唱奖；1999年在首届全国大学生艺术节上获合唱一等奖；2000年在北京第五届中国国际合唱节上获银奖；2002年在第二届世界奥林匹克合唱比赛中获青年混声合唱银奖、无伴奏民谣合唱金奖及有表演民谣合唱金奖冠军；2004年在德国艾森费尔德国际合唱邀请赛上获欧洲传统合唱冠军、民谣合唱亚军；" +
            "2004年在第二届世界奥林匹克合唱比赛中获有表演民谣合唱、女声合唱及传统宗教合唱三项金奖；2005年在教育部举办的首届全国大学生艺术展演中获声乐类节目一等奖第一名；2007年在天津市大学生艺术展演中获大合唱、小合唱两项比赛的第一名；2009年在教育部举办的第二届全国大学生艺术展演中再获声乐类节目冠军；",
            "courseIntroduce":["中国民歌作为一种古老的艺术形式，历经几十年、数百年的沉淀，已成为中华民族文化的瑰宝。然而，在现行教育体制下，很多青年学生对中国民歌却知之甚少，对中国的音乐传统知之甚少。本课通过学习民歌的多种形式与种类，以及它与其它艺术门类的关系，旨在引导学生了解中华民族优秀的音乐文化遗产，并通过亲自演唱，感受民歌的魅力，认识民歌的价值，从而更激发青年学生对祖国和人民的热爱，以及强烈的民族自豪感。"],
            "bigImgUrl":"http://p.ananas.chaoxing.com/star3/733_434c/56e0dd72e4b0b07fe6c7c8d6.jpg",
            "videoUrl":"http://s1.ananas.chaoxing.com/video/db/55d4241de4b0529fd54022b2/sd.mp4",
            "courseChapter":[
                {
                    "民歌的体裁分类——小调":[
                        {"chapterNum":"1.1", "chapterName":"小调之吟唱调"},
                        {"chapterNum":"1.2", "chapterName":"小调之谣曲（一）：个性化的特征"},
                        {"chapterNum":"1.3", "chapterName":"小调之谣曲（二）：经典赏析"},
                        {"chapterNum":"1.4", "chapterName":"时调（一）：孟姜女调、剪靛花调、鲜花调"},
                        {"chapterNum":"1.5", "chapterName":"时调（二）：银纽丝调"},
                        {"chapterNum":"1.6", "chapterName":"时调（三）：无锡景调、绣荷包调等"},
                        {"chapterNum":"1.7", "chapterName":"时调（四）：时调的流传变迁"},
                        {"chapterNum":"1.8", "chapterName":"时调（四）：时调的流传变迁"}
                    ],
                    "北方少数民族民歌及其音乐特征":[
                        {"chapterNum":"2.1", "chapterName":"蒙古族长调（一）：作品的风格"},
                        {"chapterNum":"2.2", "chapterName":"蒙古族长调（二）：作品的故事"},
                        {"chapterNum":"2.3", "chapterName":"蒙古族短调及音乐特征"},
                        {"chapterNum":"2.4", "chapterName":"哈萨克族独唱"},
                        {"chapterNum":"2.5", "chapterName":"哈萨克族民歌的音乐特征"},
                        {"chapterNum":"2.6", "chapterName":"维吾尔族民歌的音乐特征"},
                        {"chapterNum":"2.7", "chapterName":"维吾尔族民歌的爱情歌曲"},
                        {"chapterNum":"2.8", "chapterName":"维吾尔族民歌的其他歌曲"},
                        {"chapterNum":"2.9", "chapterName":"塔吉克族民歌的音乐特征"},
                        {"chapterNum":"2.10", "chapterName":"朝鲜族民歌的音乐特征"},
                        {"chapterNum":"2.11", "chapterName":"回族民歌的音乐特征"},
                        {"chapterNum":"2.12", "chapterName":"藏族民歌的音乐特征"}
                    ],
                    "南方少数民族民歌及其音乐特征":[
                        {"chapterNum":"3.1", "chapterName":"苗族民歌的音乐特征"},
                        {"chapterNum":"3.2", "chapterName":"彝族民歌的音乐特征"},
                        {"chapterNum":"3.3", "chapterName":"少数民族民歌之壮族"},
                        {"chapterNum":"3.4", "chapterName":"少数民族民歌之瑶族"},
                        {"chapterNum":"3.5", "chapterName":"少数民族民歌之布依族"},
                        {"chapterNum":"3.6", "chapterName":"少数民族民歌之白族"},
                        {"chapterNum":"3.7", "chapterName":"少数民族民歌之拉祜族"}
                    ]
                }
            ]
        },
        {
            "courseid":"81096910",
            "courseName":"西方美术欣赏（上）",
            "typeOne":"兴趣技能",
            "typeTwo":"艺术鉴赏",
            "keySpeakName":"孙乃树",
            "keySpeakUnivercity":"华东师范大学",
            "keySpeakPosition":"教授",
            "keySpeakIntroduce":"中国高教学会美育研究会理事，美国维拉诺瓦大学客座教授 ，上海市中小学二期课程教材改革审查专家，华东师范大学第7、8届教学委员会委员，奥中关系促进会音乐、教育顾问，上海“东方大讲坛”讲师",
            "courseIntroduce":["课程从中西美术的比较入手，通过材料、对象、文化、环境等角度的对比来介绍西方美术作品的表现手法和鉴赏要点。课程中涉及到原始艺术，埃及艺术，希腊罗马艺术，中世纪美术，文艺复兴，十七、十八、十九世纪的欧洲美术，现代美术等方面，通过系统地介绍西方美术的历史、发展、演变及各个时期著名的艺术家和艺术作品使学生能领略到整个西方美术世界的魅力。"],
            "bigImgUrl":"http://p.ananas.chaoxing.com/star2/2014-06/733_434/1403058896963lfegj.jpg",
            "videoUrl":"",
            "courseChapter":[
                {
                    "西方美术是怎样的":[
                        {"chapterNum":"1.1", "chapterName":"中西绘画的差异"},
                        {"chapterNum":"1.2", "chapterName":"中国绘画的特色"},
                        {"chapterNum":"1.3", "chapterName":"传统绘画：中西方比较"},
                        {"chapterNum":"1.4", "chapterName":"现代绘画：中西方比较"}
                    ],
                    "怎样欣赏美术作品":[{"chapterNum":"2.1", "chapterName":"怎样欣赏美术作品"}],
                    "神奇的起源——原始艺术":[
                        {"chapterNum":"3.1", "chapterName":"探索原始艺术"},
                        {"chapterNum":"3.2", "chapterName":"艺术的起源"},
                        {"chapterNum":"3.3", "chapterName":"原始艺术作品"},
                        {"chapterNum":"3.4", "chapterName":"洞窟艺术与器具艺术"},
                        {"chapterNum":"3.5", "chapterName":"岩画艺术与陶器艺术"},
                        {"chapterNum":"3.6", "chapterName":"陶器艺术与巨石艺术"}
                    ],
                    "追求来世的永恒——埃及艺术":[
                        {"chapterNum":"4.1", "chapterName":"古埃及艺术概述"},
                        {"chapterNum":"4.2", "chapterName":"前王国时期的埃及艺术"},
                        {"chapterNum":"4.3", "chapterName":"古王国至新王国时期的建筑艺术"},
                        {"chapterNum":"4.4", "chapterName":"古埃及的雕塑艺术"},
                        {"chapterNum":"4.5", "chapterName":"古埃及的浮雕与绘画（上）"},
                        {"chapterNum":"4.6", "chapterName":"古埃及的浮雕与绘画（下）"}
                    ],
                    "“美”的伟大觉醒——古希腊罗马艺术":[
                        {"chapterNum":"5.1", "chapterName":"迈锡尼文化与克里特文化"},
                        {"chapterNum":"5.2", "chapterName":"古希腊艺术特色"},
                        {"chapterNum":"5.3", "chapterName":"古希腊雕塑概述"},
                        {"chapterNum":"5.4", "chapterName":"古典时期前期的雕塑家及其作品"},
                        {"chapterNum":"5.5", "chapterName":"古典时期后期的雕塑家及其作品"},
                        {"chapterNum":"5.6", "chapterName":"希腊时期艺术和古典时期艺术"},
                        {"chapterNum":"5.7", "chapterName":"古希腊绘画"},
                        {"chapterNum":"5.8", "chapterName":"古希腊建筑"},
                        {"chapterNum":"5.9", "chapterName":"古罗马艺术特色"},
                        {"chapterNum":"5.10", "chapterName":"古罗马艺术成就"}
                    ],
                    "基督的召唤——中世纪美术":[
                        {"chapterNum":"6.1", "chapterName":"东罗马帝国艺术"},
                        {"chapterNum":"6.2", "chapterName":"中世纪建筑、镶嵌画和手抄本"},
                        {"chapterNum":"6.3", "chapterName":"哥特式风格"}
                    ]
                }
            ]
        },
        {
            "courseid":"81091936",
            "courseName":"西方美术欣赏（下）",
            "typeOne":"兴趣技能",
            "typeTwo":"艺术鉴赏",
            "keySpeakName":"孙乃树",
            "keySpeakUnivercity":"华东师范大学",
            "keySpeakPosition":"教授",
            "keySpeakIntroduce":"中国高教学会美育研究会理事，美国维拉诺瓦大学客座教授 ，上海市中小学二期课程教材改革审查专家，华东师范大学第7、8届教学委员会委员，奥中关系促进会音乐、教育顾问，上海“东方大讲坛”讲师",
            "courseIntroduce":["课程从中西美术的比较入手，通过材料、对象、文化、环境等角度的对比来介绍西方美术作品的表现手法和鉴赏要点。课程中涉及到原始艺术，埃及艺术，希腊罗马艺术，中世纪美术，文艺复兴，十七、十八、十九世纪的欧洲美术，现代美术等方面，通过系统地介绍西方美术的历史、发展、演变及各个时期著名的艺术家和艺术作品使学生能领略到整个西方美术世界的魅力。"],
            "bigImgUrl":"http://p.ananas.chaoxing.com/star3/733_434c/55fd1e9ee4b040cfea186225.jpg",
            "videoUrl":"",
            "courseChapter":[
                {
                    "巨匠辈出的时代——文艺复兴":[
                        {"chapterNum":"1.1", "chapterName":"文艺复兴史"},
                        {"chapterNum":"1.2", "chapterName":"文艺复兴初期的意大利美术"},
                        {"chapterNum":"1.3", "chapterName":"《最后的晚餐》艺术成就"},
                        {"chapterNum":"1.4", "chapterName":"《蒙娜丽莎》和《岩间圣母》的艺术成就"},
                        {"chapterNum":"1.5", "chapterName":"米开朗琪罗的作品及艺术成就"},
                        {"chapterNum":"1.6", "chapterName":"拉斐尔的艺术成就"},
                        {"chapterNum":"1.7", "chapterName":"威尼斯画派作品赏析"},
                        {"chapterNum":"1.8", "chapterName":"丁托雷托的作品及艺术成就"},
                        {"chapterNum":"1.9", "chapterName":"尼德兰艺术及德国文艺复兴的艺术成就"}
                    ],
                    "十七、十八世纪欧洲美术":[
                        {"chapterNum":"2.1", "chapterName":"巴洛克的产生"},
                        {"chapterNum":"2.2", "chapterName":"巴洛克的特点"},
                        {"chapterNum":"2.3", "chapterName":"卡拉瓦乔、贝尼尼和鲁本斯的巴洛克风格"},
                        {"chapterNum":"2.4", "chapterName":"凡•戴克和委拉斯开兹的巴洛克艺术成就"},
                        {"chapterNum":"2.5", "chapterName":"荷兰画派的兴起"},
                        {"chapterNum":"2.6", "chapterName":"伦勃朗和维米尔的绘画成就"},
                        {"chapterNum":"2.7", "chapterName":"弗拉贡纳尔的成就"}
                    ],
                    "十九世纪欧洲美术":[
                        {"chapterNum":"3.1", "chapterName":"新古典主义与代表画家"},
                        {"chapterNum":"3.2", "chapterName":"浪漫主义的风格特点"},
                        {"chapterNum":"3.3", "chapterName":"浪漫主义代表画家及其作品"},
                        {"chapterNum":"3.4", "chapterName":"色彩三要素"},
                        {"chapterNum":"3.5", "chapterName":"现实主义画派的风格及作品"},
                        {"chapterNum":"3.6", "chapterName":"印象主义的兴起与特点"}
                    ],
                    "新艺术的震撼——现代美术":[
                        {"chapterNum":"4.1", "chapterName":"后印象主义与代表画家"},
                        {"chapterNum":"4.2", "chapterName":"梵高和高更的代表作赏析"},
                        {"chapterNum":"4.3", "chapterName":"马蒂斯和毕加索作品赏析"},
                        {"chapterNum":"4.4", "chapterName":"未来主义和表现主义画派风格"},
                        {"chapterNum":"4.5", "chapterName":"达达主义及其代表画家"},
                        {"chapterNum":"4.6", "chapterName":"超现实主义及其代表画家"},
                        {"chapterNum":"4.7", "chapterName":"达达主义及其代表画家"},
                        {"chapterNum":"4.8", "chapterName":"超现实主义及其代表画家"}
                    ]
                }
            ]
        },
        {
            "courseid":"82001391",
            "courseName":"贝多芬交响乐赏析",
            "typeOne":"兴趣技能",
            "typeTwo":"艺术鉴赏",
            "keySpeakName":"汪申申",
            "keySpeakUnivercity":"武汉音乐学院",
            "keySpeakPosition":"教授",
            "keySpeakIntroduce":"武汉音乐学院音乐学系教授。曾任学院音乐研究所副所长、学报《黄钟》副主编、音乐学系主任。多年来从事艺术概论、音乐美学和西方音乐史教育与研究。",
            "courseIntroduce":["“乐圣”贝多芬，一生集古典音乐之大成，开浪漫主义之先河，对世界音乐发展有着举足轻重的作用。贝多芬九大交响曲相信大家略有耳闻，今天汪老师就带领大家，赏析贝多芬九大交响曲中最具有代表性的几部作品，包括c小调第五交响曲《命运》、F大调第六交响曲《田园》、A大调第七交响曲、F大调第八交响曲、d小调第九交响曲《合唱》。课程从作品的创作背景，乐章的篇章结构到交响乐乐团的演奏欣赏，让人畅游在音乐的海洋里。听贝多芬的作品，探寻他的心灵历程，还等什么？一起来欣赏吧。"],
            "bigImgUrl":"http://p.ananas.chaoxing.com/star3/733_434c/5656980ae4b0e853549a68a8.jpg",
            "videoUrl":"http://s1.ananas.chaoxing.com/video/ab/56569a1ce4b0e853549a6994/sd.mp4",
            "courseChapter":[
                {
                    "走进贝多芬":[{"chapterNum":"1.1", "chapterName":"走进贝多芬"}],
                    "第五交响曲——《命运》":[
                        {"chapterNum":"2.1", "chapterName":"本章学习指引"},
                        {"chapterNum":"2.2", "chapterName":"《命运》：创作背景及其结构布局"},
                        {"chapterNum":"2.3", "chapterName":"第一乐章：灿烂的快板赏析"},
                        {"chapterNum":"2.4", "chapterName":"第二乐章：流畅的行板赏析"},
                        {"chapterNum":"2.5", "chapterName":"第三乐章：快板（谐虐曲）赏析"},
                        {"chapterNum":"2.6", "chapterName":"第四乐章：快板赏析"},
                        {"chapterNum":"2.7", "chapterName":"《命运》的音乐形象"}
                    ],
                    "第六交响曲——《田园》":[
                        {"chapterNum":"3.1", "chapterName":"本章学习指引"},
                        {"chapterNum":"3.2", "chapterName":"《田园》：创作背景及其结构布局"},
                        {"chapterNum":"3.3", "chapterName":"第一乐章《初到乡村的愉快感受》赏析"},
                        {"chapterNum":"3.4", "chapterName":"第二乐章《溪畔小景》赏析"},
                        {"chapterNum":"3.5", "chapterName":"第三乐章《乡民欢乐的集会》赏析"},
                        {"chapterNum":"3.6", "chapterName":"第四乐章、第五乐章赏析"}
                    ],
                    "第七交响曲——92号作品":[
                        {"chapterNum":"4.1", "chapterName":"本章学习指引"},
                        {"chapterNum":"4.2", "chapterName":"92号作品：创作背景及其结构布局"},
                        {"chapterNum":"4.3", "chapterName":"第一乐章：稍慢的引子—极快板赏析"},
                        {"chapterNum":"4.4", "chapterName":"第二乐章：小快板赏析"},
                        {"chapterNum":"4.5", "chapterName":"第三乐章：急板赏析"},
                        {"chapterNum":"4.6", "chapterName":"第四乐章：灿烂的快板赏析"}
                    ],
                    "第八交响曲——93号作品":[
                        {"chapterNum":"5.1", "chapterName":"本章学习指引"},
                        {"chapterNum":"5.2", "chapterName":"93号作品：创作背景及其结构布局"},
                        {"chapterNum":"5.3", "chapterName":"第一乐章：灿烂活泼的快板赏析"},
                        {"chapterNum":"5.4", "chapterName":"第二乐章：诙谐的小快板赏析"},
                        {"chapterNum":"5.5", "chapterName":"第三乐章：小步舞曲速度赏析"},
                        {"chapterNum":"5.6", "chapterName":"第四乐章：活泼的快板赏析"}
                    ],
                    "第九交响曲——《合唱》":[
                        {"chapterNum":"6.1", "chapterName":"本章学习指引"},
                        {"chapterNum":"6.2", "chapterName":"《合唱》的创作背景"},
                        {"chapterNum":"6.3", "chapterName":"《合唱》的结构布局"},
                        {"chapterNum":"6.4", "chapterName":"第一乐章：稍庄严而不太快的快板赏析"},
                        {"chapterNum":"6.5", "chapterName":"第二乐章：活泼的甚快板赏析"},
                        {"chapterNum":"6.6", "chapterName":"第三乐章：如歌而很慢的柔板赏析"},
                        {"chapterNum":"6.7", "chapterName":"第四乐章：交响戏剧部分赏析"},
                        {"chapterNum":"6.8", "chapterName":"第四乐章：大合唱部分赏析"},
                        {"chapterNum":"6.9", "chapterName":"贝多芬交响曲的创作手法及其评价"}
                    ],
                    "拓展与探究":[
                        {"chapterNum":"7.1", "chapterName":"知识拓展"},
                        {"chapterNum":"7.2", "chapterName":"讨论与展示"}
                    ]
                }
            ]
        },
        {
            "courseid":"81089975",
            "courseName":"口才艺术与社交礼仪（上）",
            "typeOne":"兴趣技能",
            "typeTwo":"通用技能",
            "keySpeakName":"艾跃进",
            "keySpeakUnivercity":"南开大学",
            "keySpeakPosition":"教授",
            "keySpeakIntroduce":"毛泽东思想的坚定拥护者，持辩证态度从文化大革命中看待毛泽东的学者。曾接受过新华社、央视《新闻联播》、《新闻频道》等媒体的采访，被媒体评为“魅力教授”、“最受欢迎教授”。",
            "courseIntroduce":["本系列主要讲口才与社交礼仪，主要内容有口语表达者应具备的素质、听众研究、内容与形式统一、口语表达流水线、辩论与演讲等知识章节内容，系统全面的介绍了各种应用口语的表达方式与应该注意的事项。通过内容的讲解与具体案例的结合以及实际的训练，使学生掌握口才艺术与社交礼仪的核心内容。"],
            "bigImgUrl":"http://p.ananas.chaoxing.com/star3/733_434c/55fd355e498ed981287e8102.jpg",
            "videoUrl":"http://s1.ananas.chaoxing.com/video/8a/56a9e08ee4b0e85354bdd25d/sd.mp4",
            "courseChapter":[
                {
                    "礼仪与做人":[
                        {"chapterNum":"1.1", "chapterName":"礼仪的概念"},
                        {"chapterNum":"1.2", "chapterName":"礼仪的内涵"},
                        {"chapterNum":"1.3", "chapterName":"做人的层次"},
                        {"chapterNum":"1.4", "chapterName":"礼仪无处不在无时不有"},
                        {"chapterNum":"1.5", "chapterName":"礼仪的坚持"}
                    ],
                    "口才艺术释义":[
                        {"chapterNum":"2.1", "chapterName":"口才艺术的释义、特点与要求"},
                        {"chapterNum":"2.2", "chapterName":"口语表达的标准"},
                        {"chapterNum":"2.3", "chapterName":"口语表达的误区"},
                        {"chapterNum":"2.4", "chapterName":"口才的理念"}
                    ],
                    "口语表达者应具备的素质":[
                        {"chapterNum":"3.1", "chapterName":"口语表达者应具备的素质（一）"},
                        {"chapterNum":"3.2", "chapterName":"口语表达者应具备的素质（二）"}
                    ],
                    "认真研究你的听众":[
                        {"chapterNum":"4.1", "chapterName":"讲说对象的构成"},
                        {"chapterNum":"4.2", "chapterName":"如何研究听者的反应和诉求"}
                    ],
                    "内容与形式的统一":[
                        {"chapterNum":"5.1", "chapterName":"内容的六个方面"},
                        {"chapterNum":"5.2", "chapterName":"讲说的形式"}
                    ],
                    "学生的日常礼仪":[
                        {"chapterNum":"6.1", "chapterName":"明礼诚信"},
                        {"chapterNum":"6.2", "chapterName":"团结友爱"},
                        {"chapterNum":"6.3", "chapterName":"体贴父母"},
                        {"chapterNum":"6.4", "chapterName":"学子之礼"},
                        {"chapterNum":"6.5", "chapterName":"友爱同学"},
                        {"chapterNum":"6.6", "chapterName":"校园礼仪"},
                        {"chapterNum":"6.7", "chapterName":"坦诚相交"},
                        {"chapterNum":"6.8", "chapterName":"涉外十四条通则"}
                    ]
                }
            ]
        },
        {
            "courseid":"81097508",
            "courseName":"口才艺术与社交礼仪（下）",
            "typeOne":"兴趣技能",
            "typeTwo":"通用技能",
            "keySpeakName":"艾跃进",
            "keySpeakUnivercity":"南开大学",
            "keySpeakPosition":"教授",
            "keySpeakIntroduce":"毛泽东思想的坚定拥护者，持辩证态度从文化大革命中看待毛泽东的学者。曾接受过新华社、央视《新闻联播》、《新闻频道》等媒体的采访，被媒体评为“魅力教授”、“最受欢迎教授”。",
            "courseIntroduce":["本系列主要讲口才与社交礼仪，主要内容有口语表达者应具备的素质、听众研究、内容与形式统一、口语表达流水线、辩论与演讲等知识章节内容，系统全面的介绍了各种应用口语的表达方式与应该注意的事项。通过内容的讲解与具体案例的结合以及实际的训练，使学生掌握口才艺术与社交礼仪的核心内容。"],
            "bigImgUrl":"http://p.ananas.chaoxing.com/star3/733_434c/55fd3591e4b040cfea186581.jpg",
            "videoUrl":"",
            "courseChapter":[
                {
                    "口语表达流水线":[
                        {"chapterNum":"1.1", "chapterName":"演讲的开场白"},
                        {"chapterNum":"1.2", "chapterName":"演讲的展开"},
                        {"chapterNum":"1.3", "chapterName":"演讲的结尾"},
                        {"chapterNum":"1.4", "chapterName":"讲说的调整方式"},
                        {"chapterNum":"1.5", "chapterName":"临场的应对"}
                    ],
                    "日常的口语表达方式——说话":[
                        {"chapterNum":"2.1", "chapterName":"双向说话的特点"},
                        {"chapterNum":"2.2", "chapterName":"双向说话表达的方式"},
                        {"chapterNum":"2.3", "chapterName":"单向说话需要处理的七个关系"},
                        {"chapterNum":"2.4", "chapterName":"师生交流"}
                    ],
                    "口语表达王冠上的明珠——辩论和演讲":[
                        {"chapterNum":"3.1", "chapterName":"辩论的定义"},
                        {"chapterNum":"3.2", "chapterName":"解析辩题与辩论方法"},
                        {"chapterNum":"3.3", "chapterName":"辩论的要求"},
                        {"chapterNum":"3.4", "chapterName":"演讲的定义和分类"},
                        {"chapterNum":"3.5", "chapterName":"演讲的特征和表达方式"},
                        {"chapterNum":"3.6", "chapterName":"演讲稿的准备"},
                        {"chapterNum":"3.7", "chapterName":"辩论赛的评判标准"},
                        {"chapterNum":"3.8", "chapterName":"演讲的注意事项"},
                        {"chapterNum":"3.9", "chapterName":"演讲的评判标准"}
                    ]
                }
            ]
        },
        {
            "courseid":"81786236",
            "courseName":"辩论修养（上）",
            "typeOne":"兴趣技能",
            "typeTwo":"通用技能",
            "keySpeakName":"史广顺",
            "keySpeakUnivercity":"南开大学",
            "keySpeakPosition":"副教授",
            "keySpeakIntroduce":"南开大学信息技术科学学院机器智能研究所工学博士、副教授。20岁时就从南开大学计算机专业理学士毕业，25岁从南开大学控制理论与控制工程专业工学博士毕业，28岁任南开大学机器智能研究所教师，天津奥赛软件公司OCR研发部经理，天津奥赛软件公司产学研管理部经理，南开越洋欧美软件出口咨询师，南开大学资深辩论专家。同时为南开学子提供多年就业指导，为众多企业提供人力资源培训。",
            "courseIntroduce":["本系列主要是介绍辩论的方法与辩论中常见问题，通过老师列举讲解具体辩题案例，以及课堂上的辩论互动，使学生更易于理解掌握知识要点。本系列主要包含辩论修养概述、辩论中的概念、杀人游戏、一边立论框架、战场概念、辩论战场的把握、辩论中的逻辑、势的运用、辩论的勇气、对抗、攻守的陈词与总结平衡等系列课程，基本涵盖了实际辩论中的各个环节。"],
            "bigImgUrl":"http://p.ananas.chaoxing.com/star2/2014-06/733_434/1401619503259kwcju.jpg",
            "videoUrl":"",
            "courseChapter":[
                {
                    "辩论修养概述":[
                        {"chapterNum":"1.1", "chapterName":"认识、判断、交流"},
                        {"chapterNum":"1.2", "chapterName":"辩论的起源"},
                        {"chapterNum":"1.3", "chapterName":"打破印象的束缚"}
                    ],
                    "辩论中的概念":[
                        {"chapterNum":"2.1", "chapterName":"“概念”的界定"},
                        {"chapterNum":"2.2", "chapterName":"辩题中经常出现的概念"},
                        {"chapterNum":"2.3", "chapterName":"“概念”的分析"}
                    ],
                    "杀人游戏":[
                        {"chapterNum":"3.1", "chapterName":"杀人游戏模拟练习"},
                        {"chapterNum":"3.2", "chapterName":"杀人游戏解析（上）"},
                        {"chapterNum":"3.3", "chapterName":"杀人游戏解析（下）"}
                    ],
                    "一辩立论框架":[
                        {"chapterNum":"4.1", "chapterName":"一辩立论框架（上）"},
                        {"chapterNum":"4.2", "chapterName":"一辩立论框架（下）"}
                    ],
                    "战场的概念":[
                        {"chapterNum":"5.1", "chapterName":"价值升华"},
                        {"chapterNum":"5.2", "chapterName":"何为战场"},
                        {"chapterNum":"5.3", "chapterName":"如何把握战场"},
                        {"chapterNum":"5.4", "chapterName":"战场的对抗"}
                    ],
                    "辩论战场的把握":[
                        {"chapterNum":"6.1", "chapterName":"举例辩题“高薪能养廉”（上）"},
                        {"chapterNum":"6.2", "chapterName":"举例辩题“高薪能养廉”（下）"},
                        {"chapterNum":"6.3", "chapterName":"举例辩题“知其不可”"},
                        {"chapterNum":"6.4", "chapterName":"把握辩论战场的技巧"},
                        {"chapterNum":"6.5", "chapterName":"举例辩题“微信该不该收费”"},
                        {"chapterNum":"6.6", "chapterName":"古代哲人思想与辩论"}
                    ]
                }
            ]
        },
        {
            "courseid":"81792340",
            "courseName":"辩论修养（下）",
            "typeOne":"兴趣技能",
            "typeTwo":"通用技能",
            "keySpeakName":"史广顺",
            "keySpeakUnivercity":"南开大学",
            "keySpeakPosition":"副教授",
            "keySpeakIntroduce":"南开大学信息技术科学学院机器智能研究所工学博士、副教授。20岁时就从南开大学计算机专业理学士毕业，25岁从南开大学控制理论与控制工程专业工学博士毕业，28岁任南开大学机器智能研究所教师，天津奥赛软件公司OCR研发部经理，天津奥赛软件公司产学研管理部经理，南开越洋欧美软件出口咨询师，南开大学资深辩论专家。同时为南开学子提供多年就业指导，为众多企业提供人力资源培训。",
            "courseIntroduce":["本系列主要是介绍辩论的方法与辩论中常见问题，通过老师列举讲解具体辩题案例，以及课堂上的辩论互动，使学生更易于理解掌握知识要点。本系列主要包含辩论修养概述、辩论中的概念、杀人游戏、一边立论框架、战场概念、辩论战场的把握、辩论中的逻辑、势的运用、辩论的勇气、对抗、攻守的陈词与总结平衡等系列课程，基本涵盖了实际辩论中的各个环节。"],
            "bigImgUrl":"http://p.ananas.chaoxing.com/star3/733_434c/55fd2db4498ed981287e8058.jpg",
            "videoUrl":"",
            "courseChapter":[
                {
                    "势的运用":[
                        {"chapterNum":"1.1", "chapterName":"势的含义"},
                        {"chapterNum":"1.2", "chapterName":"势在案例中的运用（上）"},
                        {"chapterNum":"1.3", "chapterName":"势在案例中的运用（下）"}
                    ],
                    "辩论中的逻辑":[
                        {"chapterNum":"2.1", "chapterName":"辩论中的逻辑"},
                        {"chapterNum":"2.2", "chapterName":"突破思维定势"},
                        {"chapterNum":"2.3", "chapterName":"突破思维定势"},
                        {"chapterNum":"2.4", "chapterName":"辩论中的推理"},
                        {"chapterNum":"2.5", "chapterName":"逻辑运用的角度"},
                        {"chapterNum":"2.6", "chapterName":"假的攻防转换"},
                        {"chapterNum":"2.7", "chapterName":"辩论中的援引与归谬"}
                    ],
                    "辩论的勇气":[
                        {"chapterNum":"3.1", "chapterName":"勇气的层次"},
                        {"chapterNum":"3.2", "chapterName":"如何让自己保持勇敢（上）"},
                        {"chapterNum":"3.3", "chapterName":"如何让自己保持勇敢（下）"}
                    ],
                    "对抗":[
                        {"chapterNum":"4.1", "chapterName":"何为对抗"},
                        {"chapterNum":"4.2", "chapterName":"对抗的结果"},
                        {"chapterNum":"4.3", "chapterName":"对抗中的思维模式（上）"},
                        {"chapterNum":"4.4", "chapterName":"对抗中的思维模式（下）"}
                    ],
                    "从案例辩题中看“势”":[
                        {"chapterNum":"5.1", "chapterName":"辩题分析"},
                        {"chapterNum":"5.2", "chapterName":"势的应用：立足点和价值主体"},
                        {"chapterNum":"5.3", "chapterName":"势的应用：攻防转变的核心"},
                        {"chapterNum":"5.4", "chapterName":"势的应用：嵌套关系与关联关系"}
                    ],
                    "攻守的陈词与总结平衡":[
                        {"chapterNum":"6.1", "chapterName":"辩论的心态和破与立的平衡"},
                        {"chapterNum":"6.2", "chapterName":"价值和事实的平衡"},
                        {"chapterNum":"6.3", "chapterName":"辩论的基本素质"}
                    ]
                }
            ]
        },
        {
            "courseid":"81090186",
            "courseName":"宋崇导演教你拍摄微电影",
            "typeOne":"兴趣技能",
            "typeTwo":"通用技能",
            "keySpeakName":"宋崇",
            "keySpeakUnivercity":"同济大学",
            "keySpeakPosition":"特聘教授 国家一级导演",
            "keySpeakIntroduce":"宋崇 国家一级导演；单位：同济大学特聘教授",
            "courseIntroduce":["随着网络分享平台的普及，拍摄属于自己的影片已成为数字时代的生活方式，本课程以微电影的拍摄为出发点，介绍了影片制作流程和细节，以务实的方式带领大家拍摄一部属于自己的作品。"],
            "bigImgUrl":"http://p.ananas.chaoxing.com/star3/733_434c/55cd9f59498e74bf2ff6e172.jpg",
            "videoUrl":"",
            "courseChapter":[
                {
                    "微电影概述":[
                        {"chapterNum":"1.1", "chapterName":"微电影制作概述"},
                        {"chapterNum":"1.2", "chapterName":"电影《龙头》鉴赏"},
                        {"chapterNum":"1.3", "chapterName":"微电影创作遵循的特点"},
                        {"chapterNum":"1.4", "chapterName":"为什么企业家关注微电影广告"}
                    ],
                    "微电影制作（一）":[
                        {"chapterNum":"2.1", "chapterName":"电影的镜头与景别"},
                        {"chapterNum":"2.2", "chapterName":"电影必须具备的七种镜头"},
                        {"chapterNum":"2.3", "chapterName":"美国好莱坞的“三镜头”法则"},
                        {"chapterNum":"2.4", "chapterName":"基本拍摄方法"},
                        {"chapterNum":"2.5", "chapterName":"演员表演时方向性问题"},
                        {"chapterNum":"2.6", "chapterName":"摄影机的运动"},
                        {"chapterNum":"2.7", "chapterName":"光是摄影造型的生命"},
                        {"chapterNum":"2.8", "chapterName":"什么是色温"},
                        {"chapterNum":"2.9", "chapterName":"三种构图"},
                        {"chapterNum":"2.10", "chapterName":"如何选择、修改、创作剧本（1）"},
                        {"chapterNum":"2.11", "chapterName":"如何选择、修改、创作剧本（2）"},
                        {"chapterNum":"2.12", "chapterName":"如何选择、修改、创作剧本（3）"},
                        {"chapterNum":"2.13", "chapterName":"如何选择、修改、创作剧本（4）"},
                        {"chapterNum":"2.14", "chapterName":"如何选择、修改、创作剧本（5）"},
                        {"chapterNum":"2.15", "chapterName":"如何选择、修改、创作剧本（6）"}
                    ],
                    "微电影制作（二）":[
                        {"chapterNum":"3.1", "chapterName":"演员创造角色"},
                        {"chapterNum":"3.2", "chapterName":"分析人物角色"},
                        {"chapterNum":"3.3", "chapterName":"电影中的排演"},
                        {"chapterNum":"3.4", "chapterName":"台词的潜在性"},
                        {"chapterNum":"3.5", "chapterName":"演员的调度"},
                        {"chapterNum":"3.6", "chapterName":"电影调度绘图与分镜头（一）"},
                        {"chapterNum":"3.7", "chapterName":"电影调度绘图与分镜头（二）"},
                        {"chapterNum":"3.8", "chapterName":"多机位拍摄的剪辑"},
                        {"chapterNum":"3.9", "chapterName":"剪辑技巧（一）"},
                        {"chapterNum":"3.10", "chapterName":"剪辑技巧（二）"},
                        {"chapterNum":"3.11", "chapterName":"蒙太奇的运用"}
                    ]
                }
            ]
        },
        {
            "courseid":"86349946",
            "courseName":"有效沟通技巧",
            "typeOne":"兴趣技能",
            "typeTwo":"通用技能",
            "keySpeakName":"赵永忠",
            "keySpeakUnivercity":"北京联合大学",
            "keySpeakPosition":"讲师",
            "keySpeakIntroduce":"研究领域社会心理学、跨文化交流，现为国家二级心理咨询师。论文著作:参与《基于学习通用设计的聋人大学课程建设研究与实践》（国家级，吕会华副教授主持）等科研项目2项，发表（《课堂教学中的语言沟通策略》）等学术论文6篇，作为副主编编写《大学语文》等教材1部，指导学生参加学科竞赛获奖3次。" +
            "荣誉与奖励:2000年，曾获得北京市第三届高校教师教学基本功比赛B组一等奖；2005年，被评为北京联合大学示范教师；2013年，荣获北京联合大学中青年教师执教能力一等奖；2013年，与联大旅游学院孙慧君老师合作主讲的《人际交往心理学》被评为北京联合大学第一门“校级精品视频公开课”；2014年，获得北京联合大学教学优秀一等奖。",
            "courseIntroduce":["沟通技巧是现代社会公认的宝贵的软实力，一个人的成功，当然离不开扎实的专业基础知识，然而在更大程度上受益于为人处事能力和沟通技巧。只有正确地了解自己，善意地理解他人，在日常学习、工作、生活中与他人展开阳光社交，才能在成才的路上高歌猛进。因此，沟通技巧对我们的物质生活和精神生活显得尤其重要。","" +
            "本课程立足传播学、社会心理学理论基础，借助大量典型情境设计和案例分析，从沟通要素、沟通规律、有效倾听、有声语言和无声语言沟通、克服自卑心态、开展阳光社交等方面，展开深入浅出、简便易行的教学辅导。目的在于既培养学生理性思考，又丰富学生感性认识；既学到沟通理论知识，又开拓了学习视野；既学到切实有效的沟通技巧，又能在现实交往中实践提升。相信一定会受到学生欢迎，并在现实中学以致用、走向成功的。"],
            "bigImgUrl":"http://p.ananas.chaoxing.com/star3/733_434c/56304388e4b04f4c2bf9796f.jpg",
            "videoUrl":"http://s1.ananas.chaoxing.com/video/ea/564d796a498ed8a429405eac/sd.mp4",
            "courseChapter":[
                {
                    "有效沟通的概说":[
                        {"chapterNum":"1.1", "chapterName":"人际沟通是交流信息的过程"},
                        {"chapterNum":"1.2", "chapterName":"人际沟通是有目的的活动"},
                        {"chapterNum":"1.3", "chapterName":"沟通有多种形式"}
                    ],
                    "有效沟通的一般规律":[
                        {"chapterNum":"2.1", "chapterName":"沟通中潜在的需要"},
                        {"chapterNum":"2.2", "chapterName":"信息是一个结合体"},
                        {"chapterNum":"2.3", "chapterName":"信息的意义因人而异"},
                        {"chapterNum":"2.4", "chapterName":"信息可以表达不同程度的礼貌"}
                    ],
                    "有声语言的有效沟通":[
                        {"chapterNum":"3.1", "chapterName":"自信地交流"},
                        {"chapterNum":"3.2", "chapterName":"保持良好情绪，避免以偏概全"},
                        {"chapterNum":"3.3", "chapterName":"区分事实与推论，按照事实描述"},
                        {"chapterNum":"3.4", "chapterName":"真诚赞美和谨慎评价"},
                        {"chapterNum":"3.5", "chapterName":"不断学习，动态评价"}
                    ],
                    "非语言信息的有效沟通":[
                        {"chapterNum":"4.1", "chapterName":"身体姿势"},
                        {"chapterNum":"4.2", "chapterName":"表情交流"},
                        {"chapterNum":"4.3", "chapterName":"眼神交流"},
                        {"chapterNum":"4.4", "chapterName":"身体接触"},
                        {"chapterNum":"4.5", "chapterName":"空间信息"},
                        {"chapterNum":"4.6", "chapterName":"衣着和身体饰物"}
                    ],
                    "有效沟通中的倾听":[
                        {"chapterNum":"5.1", "chapterName":"引言"},
                        {"chapterNum":"5.2", "chapterName":"移情倾听和客观倾听"},
                        {"chapterNum":"5.3", "chapterName":"表层倾听和深层倾听"},
                        {"chapterNum":"5.4", "chapterName":"积极倾听和消极倾听"}
                    ],
                    "发现身边的的陌生贵人":[
                        {"chapterNum":"6.1", "chapterName":"我们需要陌生贵人"},
                        {"chapterNum":"6.2", "chapterName":"与身边贵人的沟通障碍"},
                        {"chapterNum":"6.3", "chapterName":"与身边贵人的有效沟通"}
                    ]
                }
            ]
        },
        {
            "courseid":"86349927",
            "courseName":"情绪管理",
            "typeOne":"兴趣技能",
            "typeTwo":"通用技能",
            "keySpeakName":"韦庆旺",
            "keySpeakUnivercity":"中国人民大学",
            "keySpeakPosition":"讲师",
            "keySpeakIntroduce":"研究领域、社会心理学、论文与著作，迄今为止，发表核心期刊论文10余篇。荣誉与奖励：分别于2002年6月，2005年6月，2008年6月获吉林大学、中山大学和浙江大学应用心理学专业学士、硕士和博士学位。2008年9月—2010年6月，于中国人民大学心理研究所做博士后工作。2010年7月至今，为中国人民大学心理学系教师。" ,
            "courseIntroduce":["本课程围绕“如何控制情绪”的主题展开，分别讲述了怎样认识情绪，情绪的功能，压力与情绪的关系，怎样提高情商增强韧性，如何克服消除焦虑和抑郁，以及怎样调动积极情绪获取快乐与幸福。课程中引入介绍了大量著名的心理学实验，并展示了缓解负面情绪的具体办法。旨在帮助学习者正确认识、体察自我情绪，科学、有效地控制情绪，获得积极的心理感受和体验。"],
            "bigImgUrl":"http://p.ananas.chaoxing.com/star3/733_434c/56306432498e8943b8a461d5.jpg",
            "videoUrl":"http://s1.ananas.chaoxing.com/video/4e/56739d78e4b0e85354a6a81f/sd.mp4",
            "courseChapter":[
                {
                    "第一讲 认识情绪":[
                        {"chapterNum":"1.1", "chapterName":"认识情绪（上）"},
                        {"chapterNum":"1.2", "chapterName":"认识情绪（上）"}
                    ],
                    "第二讲 情绪的功能":[
                        {"chapterNum":"2.1", "chapterName":"情绪的功能（上）"},
                        {"chapterNum":"2.2", "chapterName":"情绪的功能（下）"}
                    ],
                    "第三讲 压力与情绪":[
                        {"chapterNum":"3.1", "chapterName":"压力与情绪（上）"},
                        {"chapterNum":"3.2", "chapterName":"压力与情绪（下）"}
                    ],
                    "第四讲 情商与韧性":[
                        {"chapterNum":"4.1", "chapterName":"情商与韧性（上）"},
                        {"chapterNum":"4.2", "chapterName":"情商与韧性（下）"}
                    ],
                    "第五讲 焦虑和抑郁":[
                        {"chapterNum":"5.1", "chapterName":"焦虑与抑郁（上）"},
                        {"chapterNum":"5.2", "chapterName":"焦虑与抑郁（下）"}
                    ],
                    "第六讲 快乐与幸福":[
                        {"chapterNum":"6.1", "chapterName":"快乐与幸福（上）"},
                        {"chapterNum":"6.2", "chapterName":"快乐与幸福（下）"}
                    ]
                }
            ]
        },
        {
            "courseid":"86001233",
            "courseName":"中国剪纸艺术欣赏与实践",
            "typeOne":"兴趣技能",
            "typeTwo":"文化传承",
            "keySpeakName":"郭宪",
            "keySpeakUnivercity":"中国地质大学",
            "keySpeakPosition":"教授",
            "keySpeakIntroduce":"郭宪，女，中国地质大学，教授。擅长山水画和剪纸。著有《中国传统山水画心法技法与实践》、《中国剪纸艺术欣赏与实践》。" ,
            "courseIntroduce":["本系列主要介绍了中国剪纸艺术欣赏与实践，主讲人首先从中国剪纸的思想方法和寓意入手，接着讲述了剪纸最长见的蝴蝶、龙、凤等动物，然后分别讲述了十二生肖中每一种动物的剪法，最后讲述了四季花、鸟、鱼、人物、雪花、蝙蝠一些常见动物的剪法。"],
            "bigImgUrl":"http://p.ananas.chaoxing.com/star/733_434c/1384935403505bgudp.jpg",
            "videoUrl":"",
            "courseChapter":[
                {
                    "中国剪纸的思想方法和寓意":[
                        {"chapterNum":"1.1", "chapterName":"中国剪纸的思想方法和寓意（上）"},
                        {"chapterNum":"1.2", "chapterName":"中国剪纸的思想方法和寓意（上）"}
                    ],
                    "剪纸技法——蝴蝶系列":[
                        {"chapterNum":"2.1", "chapterName":"剪纸技法——蝴蝶系列（上）"},
                        {"chapterNum":"2.2", "chapterName":"剪纸技法——蝴蝶系列（下）"}
                    ],
                    "剪纸技法——龙、凤":[
                        {"chapterNum":"3.1", "chapterName":"剪纸技法——龙、凤"}
                    ],
                    "十二生肖——鼠、牛、虎、兔":[
                        {"chapterNum":"4.1", "chapterName":"十二生肖——鼠、牛、虎、兔（上）"},
                        {"chapterNum":"4.2", "chapterName":"十二生肖——鼠、牛、虎、兔（下）"}
                    ],
                    "十二生肖——蛇、马、羊":[
                        {"chapterNum":"5.1", "chapterName":"十二生肖——蛇、马、羊（上）"},
                        {"chapterNum":"5.2", "chapterName":"十二生肖——蛇、马、羊（下）"}
                    ],
                    "十二生肖——猴、鸡、狗、猪":[
                        {"chapterNum":"6.1", "chapterName":"十二生肖——猴、鸡、狗、猪（上）"},
                        {"chapterNum":"6.2", "chapterName":"十二生肖——猴、鸡、狗、猪（下）"}
                    ],
                    "剪纸技法——四季花":[
                        {"chapterNum":"7.1", "chapterName":"剪纸技法——四季花（上）"},
                        {"chapterNum":"7.2", "chapterName":"剪纸技法——四季花（下）"}
                    ],
                    "剪纸技法——鸟、鱼":[
                        {"chapterNum":"8.1", "chapterName":"剪纸技法——鸟、鱼（上）"},
                        {"chapterNum":"8.2", "chapterName":"剪纸技法——鸟、鱼（下）"}
                    ],
                    "剪纸技法——人物、雪花、蝙蝠":[
                        {"chapterNum":"9.1", "chapterName":"剪纸技法——人物、雪花、蝙蝠（上）"},
                        {"chapterNum":"9.2", "chapterName":"剪纸技法——人物、雪花、蝙蝠（下）"}
                    ]
                }
            ]
        },
        {
            "courseid":"81097208",
            "courseName":"从泥巴到国粹(上）",
            "typeOne":"兴趣技能",
            "typeTwo":"文化传承",
            "keySpeakName":"刘怀勇",
            "keySpeakUnivercity":"清华大学",
            "keySpeakPosition":"教授",
            "keySpeakIntroduce":"刘怀勇，别署历下山夫，凹斋，1960年2月生于济南历城。现为中国美术家协会会员，中国书法家协会会员，清华大学中国画高研班主讲导师、教授。应邀为中国美术家协会中国画高研班、中国艺术研究院中国书法院、国立台湾台中教育大学艺术学院讲学。山水、花鸟、书法、篆刻，多次入选全国大展并获奖。入编《中国书法百家作品集》、《中国山水画百家作品集》，中国文联出版社出版《凹斋课稿》，清华大学出版社出版《清华大学中国画高级研修班---刘怀勇课稿》，河北美术出版社出版《刘怀勇花鸟课稿》、《刘怀勇书法课稿》，" +
            "北京工艺美术出版社出版《大匠之门——刘怀勇花鸟课稿》。荣誉与奖励：1989年获庆祝建国四十周年全国书画大联展一等奖，2000年至2005年全国中国画大展、全国中国画提名展入选、获优秀奖，特邀参加中国美协第五届“秦皇岛之夏”全国中国画名家邀请展；花鸟画作品曾入选2004年全国中国画提名展、2005年全国中国画提名展、2006年全国中国画百家作品展、入选全国首届写意画大展。书法作品入展中国书协“全国第八届中青展”、“首届青年展”、“全国六届篆刻展”。1989年创作《英魂舞》摘得庆祝建国四十周年全国书画大联展金奖后，一发不可收，先后获得中国美协" +
            "“西部辉煌全国中国画作品展”银奖；“纪念毛主席在延安文艺座谈会上的讲话发表60周年”全国美术作品展铜奖；2000年全国中国画大展优秀奖；2001、2002、2004全国中国画提名奖。其书作更是异军突起，让书坛画界刮目：2001年入选中国书协“全国第八届中青年书法家、篆刻家作品展”；2004年入选“全国首届青年展”；入选“第二届中韩书法交流展”；" +
            "获“第三回中韩书艺家协会交流展”银奖。刘怀勇，" +
            "其理论文章更以独到的视角，虚实结合，得到全国各专业报刊的青睐。其创作的几十幅书画作品得到了著名评论家、中央美院副院长范迪安教授，著名评论家邵大箴教授等名师大家的众口赞誉。邵大箴教授还以《在“悟”中前进》为题，为画集作序。" ,
            "courseIntroduce":["陶瓷，故有假玉之称，为中国几千年文明之精粹。然而，无论是清雅精致的青花，还是繁复多彩的重釉均脱离不了最基本的材质——泥巴。在本系列课程中清华大学刘怀墉教授将带领大家亲临千年陶都景德镇去体验陶瓷是如何从毫不起眼的泥巴变成一件件堪称国粹的艺术品，同时刘教授将亲身示范陶瓷绘画的魅力，让我们共同关注从泥巴到国粹的神奇旅程。"],
            "bigImgUrl":"http://p.ananas.chaoxing.com/star3/733_434c/55fd1716e4b040cfea1860c0.jpg",
            "videoUrl":"",
            "courseChapter":[
                {
                    "禅茶一味图的绘画":[
                        {"chapterNum":"1.1", "chapterName":"工具的选择与菊花的绘画原则"},
                        {"chapterNum":"1.2", "chapterName":"菊花画面细节的调整和加工"}
                    ],
                    "石头与牡丹的绘画":[
                        {"chapterNum":"2.1", "chapterName":"石头与牡丹的绘画"}
                    ],
                    "难得糊涂图的绘画":[
                        {"chapterNum":"3.1", "chapterName":"葫芦的绘画"}
                    ],
                    "秋日荷塘的绘画":[
                        {"chapterNum":"4.1", "chapterName":"秋日荷塘的绘画"},
                        {"chapterNum":"4.2", "chapterName":"秋日荷塘细节的调整和加工"}
                    ],
                    "大福禄图的绘画":[
                        {"chapterNum":"5.1", "chapterName":"大福禄图的绘画"}
                    ],
                    "室雅人和图的绘画":[
                        {"chapterNum":"6.1", "chapterName":"竹子的绘画"},
                        {"chapterNum":"6.2", "chapterName":"竹子细节的调整和加工"}
                    ],
                    "珠光图的绘画":[
                        {"chapterNum":"7.1", "chapterName":"葡萄的绘画"},
                        {"chapterNum":"7.2", "chapterName":"葡萄细节的调整和加工"}
                    ],
                    "秋山无尽图的绘画":[
                        {"chapterNum":"8.1", "chapterName":"山水画的基础知识"},
                        {"chapterNum":"8.2", "chapterName":"山水画的绘画技法"},
                        {"chapterNum":"8.3", "chapterName":"山水画细节的调整和加工"}
                    ],
                    "满庭芳图的绘画":[
                        {"chapterNum":"9.1", "chapterName":"釉下青花的绘画之经营位置"},
                        {"chapterNum":"9.2", "chapterName":"枝叶的创作"},
                        {"chapterNum":"9.3", "chapterName":"花朵的创作"},
                        {"chapterNum":"9.4", "chapterName":"花草山石的细节处理"},
                        {"chapterNum":"9.5", "chapterName":"动物绘画与整体构图调整"}
                    ],
                    "镶器的绘画创作":[
                        {"chapterNum":"10.1", "chapterName":"镶器的创作原则及绘画"},
                        {"chapterNum":"10.2", "chapterName":"画面构图与笔墨修养"},
                        {"chapterNum":"10.3", "chapterName":"花朵的创作"},
                        {"chapterNum":"10.4", "chapterName":"镶器画面中线与面的关系及整体细节修饰"}
                    ]
                }
            ]
        },
        {
            "courseid":"81091725",
            "courseName":"从泥巴到国粹(下）",
            "typeOne":"兴趣技能",
            "typeTwo":"文化传承",
            "keySpeakName":"刘怀勇",
            "keySpeakUnivercity":"清华大学",
            "keySpeakPosition":"教授",
            "keySpeakIntroduce":"刘怀勇，别署历下山夫，凹斋，1960年2月生于济南历城。现为中国美术家协会会员，中国书法家协会会员，清华大学中国画高研班主讲导师、教授。应邀为中国美术家协会中国画高研班、中国艺术研究院中国书法院、国立台湾台中教育大学艺术学院讲学。山水、花鸟、书法、篆刻，多次入选全国大展并获奖。入编《中国书法百家作品集》、《中国山水画百家作品集》，中国文联出版社出版《凹斋课稿》，清华大学出版社出版《清华大学中国画高级研修班---刘怀勇课稿》，河北美术出版社出版《刘怀勇花鸟课稿》、《刘怀勇书法课稿》，" +
            "北京工艺美术出版社出版《大匠之门——刘怀勇花鸟课稿》。荣誉与奖励：1989年获庆祝建国四十周年全国书画大联展一等奖，2000年至2005年全国中国画大展、全国中国画提名展入选、获优秀奖，特邀参加中国美协第五届“秦皇岛之夏”全国中国画名家邀请展；花鸟画作品曾入选2004年全国中国画提名展、2005年全国中国画提名展、2006年全国中国画百家作品展、入选全国首届写意画大展。书法作品入展中国书协“全国第八届中青展”、“首届青年展”、“全国六届篆刻展”。1989年创作《英魂舞》摘得庆祝建国四十周年全国书画大联展金奖后，一发不可收，先后获得中国美协" +
            "“西部辉煌全国中国画作品展”银奖；“纪念毛主席在延安文艺座谈会上的讲话发表60周年”全国美术作品展铜奖；2000年全国中国画大展优秀奖；2001、2002、2004全国中国画提名奖。其书作更是异军突起，让书坛画界刮目：2001年入选中国书协“全国第八届中青年书法家、篆刻家作品展”；2004年入选“全国首届青年展”；入选“第二届中韩书法交流展”；" +
            "获“第三回中韩书艺家协会交流展”银奖。刘怀勇，" +
            "其理论文章更以独到的视角，虚实结合，得到全国各专业报刊的青睐。其创作的几十幅书画作品得到了著名评论家、中央美院副院长范迪安教授，著名评论家邵大箴教授等名师大家的众口赞誉。邵大箴教授还以《在“悟”中前进》为题，为画集作序。" ,
            "courseIntroduce":["陶瓷，故有假玉之称，为中国几千年文明之精粹。然而，无论是清雅精致的青花，还是繁复多彩的重釉均脱离不了最基本的材质——泥巴。在本系列课程中清华大学刘怀墉教授将带领大家亲临千年陶都景德镇去体验陶瓷是如何从毫不起眼的泥巴变成一件件堪称国粹的艺术品，同时刘教授将亲身示范陶瓷绘画的魅力，让我们共同关注从泥巴到国粹的神奇旅程。"],
            "bigImgUrl":"http://p.ananas.chaoxing.com/star3/733_434c/55fcf561e4b040cfea185cc0.jpg",
            "videoUrl":"",
            "courseChapter":[
                {
                    "临摹吴昌硕的作品":[
                        {"chapterNum":"1.1", "chapterName":"吴昌硕《神仙眉寿》临摹要点"},
                        {"chapterNum":"1.2", "chapterName":"《神仙眉寿》的细节处理"},
                        {"chapterNum":"1.3", "chapterName":"吴昌硕《榴香图》临摹要点"},
                        {"chapterNum":"1.4", "chapterName":"《榴香图》的细节处理"}
                    ],
                    "临摹齐白石的作品":[
                        {"chapterNum":"2.1", "chapterName":"齐白石绘画临摹：由中国画到青花"},
                        {"chapterNum":"2.2", "chapterName":"图画转换中的要点"},
                        {"chapterNum":"2.3", "chapterName":"绘画中的纠误和线条排列"},
                        {"chapterNum":"2.4", "chapterName":"齐白石《吉利图》临摹要点"},
                        {"chapterNum":"2.5", "chapterName":"《吉利图》的细节处理"}
                    ],
                    "潘天寿及其作品赏析":[
                        {"chapterNum":"3.1", "chapterName":"潘天寿生平及绘画风格"},
                        {"chapterNum":"3.2", "chapterName":"潘天寿作品赏析及特点分析"}
                    ],
                    "陶瓷绘画":[
                        {"chapterNum":"4.1", "chapterName":"陶瓷绘画的理论基础"},
                        {"chapterNum":"4.2", "chapterName":"陶瓷绘画的实际演练"},
                        {"chapterNum":"4.3", "chapterName":"陶瓷绘画学生作品评讲"}
                    ],
                    "瓷板的釉上绘画":[
                        {"chapterNum":"5.1", "chapterName":"瓷板的釉上绘画"},
                        {"chapterNum":"5.2", "chapterName":"瓷板的釉上绘画之花鸟画布局"},
                        {"chapterNum":"5.3", "chapterName":"瓷板的釉上绘画之花鸟画底色绘画"},
                        {"chapterNum":"5.4", "chapterName":"瓷板的釉上绘画之花鸟部分绘画"},
                        {"chapterNum":"5.5", "chapterName":"瓷板的釉上绘画之花鸟画边线勾勒"},
                        {"chapterNum":"5.6", "chapterName":"小件瓷器绘画"}
                    ]
                }
            ]
        },
        {
            "courseid":"82020543",
            "courseName":"中国茶文化系列之趣谈篇",
            "typeOne":"兴趣技能",
            "typeTwo":"文化传承",
            "keySpeakName":"林治",
            "keySpeakUnivercity":"中国高等院校茶文化教材编委会",
            "keySpeakPosition":"教师",
            "keySpeakIntroduce":"中国高等院校茶文化教材编委会主任、中国茶文化国际交流协会常务理事兼副秘书长、中国国际茶文化研究会常务理事、浙江大学兼职博士生导师、湖南农业大学客座教授、西安六如茶艺培训中心导师，贵州盛华职业学院茶学院院长(志愿者)。" ,
            "courseIntroduce":["中国茶文化糅合佛、儒、道诸派思想，独成一体，是中国文化中的特色之笔。中国茶文化系列之趣谈篇包含《茶文化趣谈》和《茶叶的分类》两项专题讲座。《茶文化趣谈》中谈到了研究茶文化的使命感，探讨了何为茶，中国茶道与日本茶道的关系，展示了表演型和生活型的茶艺，道破了茶道养生的秘密。《茶叶的分类》讲述了绿茶、红茶、黄茶、白茶、黑茶、乌龙茶的门类及其制作工艺，介绍了中国十大名茶的相关知识。茶如人生，人生如茶。读一片茶叶，很深奥，深刻到要揭开一片人生，深沉地目睹一次生命的跌宕升沉。而我们也可以用简单的心情来看一片茶叶，" +
            "干枝，绿片，蜷曲，细碎……一起来品味这杯“中国茶”吧。"],
            "bigImgUrl":"http://p.ananas.chaoxing.com/star3/733_434c/565d07d9498ed8a429432f0a.png",
            "videoUrl":"http://s1.ananas.chaoxing.com/video/86/5643034ae4b0bb0dc8b0d25f/sd.mp4",
            "courseChapter":[
                {
                    "话说中国茶":[
                        {"chapterNum":"1.1", "chapterName":"本章学习指引"},
                        {"chapterNum":"1.2", "chapterName":"研究茶文化的使命"},
                        {"chapterNum":"1.3", "chapterName":"茶及其本质探讨"},
                        {"chapterNum":"1.4", "chapterName":"本章知识拓展"}
                    ],
                    "探寻中国茶艺":[
                        {"chapterNum":"2.1", "chapterName":"本章学习指引"},
                        {"chapterNum":"2.2", "chapterName":"表演型的茶艺"},
                        {"chapterNum":"2.3", "chapterName":"生活型的茶艺"},
                        {"chapterNum":"2.4", "chapterName":"本章知识拓展"}
                    ],
                    "茶道养生的秘密":[
                        {"chapterNum":"3.1", "chapterName":"本章学习指引"},
                        {"chapterNum":"3.2", "chapterName":"茶道养生的秘密"},
                        {"chapterNum":"3.3", "chapterName":"本章知识拓展"},
                        {"chapterNum":"3.4", "chapterName":"讨论与展示"}
                    ],
                    "中国茶叶的分类":[
                        {"chapterNum":"4.1", "chapterName":"本章学习指引"},
                        {"chapterNum":"4.2", "chapterName":"绿茶"},
                        {"chapterNum":"4.3", "chapterName":"红茶"},
                        {"chapterNum":"4.4", "chapterName":"黄茶和白茶"},
                        {"chapterNum":"4.5", "chapterName":"青茶"},
                        {"chapterNum":"4.6", "chapterName":"黑茶"},
                        {"chapterNum":"4.7", "chapterName":"本章知识拓展"}
                    ],
                    "中国十大名茶":[
                        {"chapterNum":"5.1", "chapterName":"本章学习指引"},
                        {"chapterNum":"5.2", "chapterName":"中国十大名茶"},
                        {"chapterNum":"5.3", "chapterName":"本章知识拓展"},
                        {"chapterNum":"5.4", "chapterName":"讨论与展示"}
                    ]
                }
            ]
        },
        {
            "courseid":"86866441",
            "courseName":"中国茶文化系列之茶源篇",
            "typeOne":"兴趣技能",
            "typeTwo":"文化传承",
            "keySpeakName":"臧嵘",
            "keySpeakUnivercity":"人民教育出版社",
            "keySpeakPosition":"编审",
            "keySpeakIntroduce":"臧嵘 ，著名历史学家、教育学家。现为人民教育出版社编审、课程教材研究所研究员。曾任历史编辑室副主任。1993年被评为国家级有突出贡献社会科学专家，领国务院特殊津贴。兼任中国教育学会历史专业委员会学术顾问、" +
            "中华书局《文史知识》编委。" ,
            "courseIntroduce":["中国是茶的故乡，中国茶文化博大精深。臧老师带领大家了解茶道的渊源，讲述中国茶文化如何传播至中华大地，并远播海外的种种故事。茶之路是沿着丝绸之路的发展而衍生的，让我们一同走上昔日的茶叶传播之路，共同探寻中国茶文化的奥秘，领略中国茶文化的风韵。"],
            "bigImgUrl":"http://p.ananas.chaoxing.com/star3/733_434c/564943dbe4b0e8535496c8e3.png",
            "videoUrl":"http://s1.ananas.chaoxing.com/video/86/5643034ae4b0bb0dc8b0d25f/sd.mp4",
            "courseChapter":[
                {
                    "茶道渊源":[
                        {"chapterNum":"1.1", "chapterName":"本章学习指引"},
                        {"chapterNum":"1.2", "chapterName":"茶的起源"},
                        {"chapterNum":"1.3", "chapterName":"茶之记载"},
                        {"chapterNum":"1.4", "chapterName":"茶起源中国说"},
                        {"chapterNum":"1.5", "chapterName":"本章知识拓展"}
                    ],
                    "茶道中国之路":[
                        {"chapterNum":"2.1", "chapterName":"本章学习指引"},
                        {"chapterNum":"2.2", "chapterName":"从阀阅、山门到凡世人间"},
                        {"chapterNum":"2.3", "chapterName":"“茶神”和《茶经》"},
                        {"chapterNum":"2.4", "chapterName":"茶与文人雅事"},
                        {"chapterNum":"2.5", "chapterName":"高雅茶文化的形成"},
                        {"chapterNum":"2.6", "chapterName":"茶文化之民族地区（上）"},
                        {"chapterNum":"2.7", "chapterName":"茶文化之民族地区（下）"}
                    ],
                    "中国茶道传播之路":[
                        {"chapterNum":"3.1", "chapterName":"本章学习指引"},
                        {"chapterNum":"3.2", "chapterName":"茶文化之东传（朝鲜）"},
                        {"chapterNum":"3.3", "chapterName":"茶文化之东传（日本）"},
                        {"chapterNum":"3.4", "chapterName":"茶文化之北传（俄罗斯）"},
                        {"chapterNum":"3.5", "chapterName":"茶文化之南传（东南亚）"},
                        {"chapterNum":"3.6", "chapterName":"茶文化之西传（中亚至非洲）"},
                        {"chapterNum":"3.7", "chapterName":"茶文化之西传（欧洲）"},
                        {"chapterNum":"3.8", "chapterName":"英国高雅茶文化"},
                        {"chapterNum":"3.9", "chapterName":"海上茶之路（美洲澳洲）"}
                    ],
                    "茶对人类发展的贡献":[
                        {"chapterNum":"4.1", "chapterName":"本章学习指引"},
                        {"chapterNum":"4.2", "chapterName":"茶对人类发展的贡献"},
                        {"chapterNum":"4.3", "chapterName":"体验式学习场所"},
                        {"chapterNum":"4.4", "chapterName":"展示与讨论"}
                    ]
                }
            ]
        },
        {
            "courseid":"81931647",
            "courseName":"道德之行",
            "typeOne":"专题教育",
            "typeTwo":"品德教育",
            "keySpeakName":"文雅",
            "keySpeakUnivercity":"中央财经大学",
            "keySpeakPosition":"讲师",
            "keySpeakIntroduce":"文雅，中央财经大学马克思主义学院讲师，北京大学伦理学博士。从事高校思想政治理论课教学4年。主要研究方向为西方伦理思想史和政治哲学。参加过各级各次教学基本功比赛，表现突出。主持国家社科基金青年项目《卢梭平等观在清末民初思想界的引入和诠释研究 (1895—1919)》（2014）。主要作品：《美国政治中的议程与不稳定性》，第二译者，北京大学出版社，2011年7月；《论奥古斯丁忏悔录的“爱”之诠释、进路及其意义》，山西师大学报（社会科学版），" +
            "2012年第11期；《斯坎伦和帕菲特论人的道德行为如何可能——基于理性、理由及个人的阐述》，中国矿业大学学报社科版，2011年第4期。" ,
            "courseIntroduce":["你知道吗？随着社会发展变化，中小学生思想道德建设面临许多新的情况和新的问题，根据《中共中央国务院关于进一步加强和改进未成年人思想道德建设的若干意见》、《公民道德建设实施纲要》的要求,教育部对上述守则和规范进行了修订，将《小学生守则》和《中学生守则》合并为《中小学生守则》。文老师、陈教授教授的《道德之行》，让我们知止有定、在心灵安宁之中探求真知、学会思考的课程；让我们在学校里开启追寻和创造至善之境的人生新旅！"],
            "bigImgUrl":"http://p.ananas.chaoxing.com/star3/733_434c/5678a095498ed8a4295dfaec.png",
            "videoUrl":"http://s1.ananas.chaoxing.com/video/6d/567cf697e4b0e85354aafeea/sd.mp4",
            "courseChapter":[
                {
                    "注重道德传承 加强道德实践":[
                        {"chapterNum":"1.1", "chapterName":"为什么要做有德之人"},
                        {"chapterNum":"1.2", "chapterName":"“道德”之本"},
                        {"chapterNum":"1.3", "chapterName":"“道德”之源"},
                        {"chapterNum":"1.4", "chapterName":"“道德”之用"},
                        {"chapterNum":"1.5", "chapterName":"道德困境"},
                        {"chapterNum":"1.6", "chapterName":"道德之根"},
                        {"chapterNum":"1.7", "chapterName":"中华传统美德的基本精神"},
                        {"chapterNum":"1.8", "chapterName":"传统美德的创造与创新"},
                        {"chapterNum":"1.9", "chapterName":"中国革命和中国革命道德"},
                        {"chapterNum":"1.10", "chapterName":"革命道德：做高尚的人和大写的人"},
                        {"chapterNum":"1.11", "chapterName":"未竟的革命事业和革命道德"},
                        {"chapterNum":"1.12", "chapterName":"道德之行"},
                        {"chapterNum":"1.13", "chapterName":"社会主义市场经济与社会主义道德"},
                        {"chapterNum":"1.14", "chapterName":"为人民服务和集体主义"}
                    ],
                    "遵守道德规范 锤炼高尚品格":[
                        {"chapterNum":"2.1", "chapterName":"公共生活及其特征"},
                        {"chapterNum":"2.2", "chapterName":"什么是好的公共生活"},
                        {"chapterNum":"2.3", "chapterName":"公共生活中的道德规范"},
                        {"chapterNum":"2.4", "chapterName":"如何形成好的公共生活"},
                        {"chapterNum":"2.5", "chapterName":"我们为什么要工作"},
                        {"chapterNum":"2.6", "chapterName":"职业道德"},
                        {"chapterNum":"2.7", "chapterName":"自觉遵守职业道德"},
                        {"chapterNum":"2.8", "chapterName":"爱的本体论"},
                        {"chapterNum":"2.9", "chapterName":"爱的阶段说"},
                        {"chapterNum":"2.10", "chapterName":"婚姻中的道德规范"},
                        {"chapterNum":"2.11", "chapterName":"弘扬家庭美德"},
                        {"chapterNum":"2.12", "chapterName":"个人品德结构"},
                        {"chapterNum":"2.13", "chapterName":"个人品德与道德修养"},
                        {"chapterNum":"2.14", "chapterName":"追求崇高的道德境界"}
                    ]
                }
            ]
        },
        {
            "courseid":"81869366",
            "courseName":"法治思维",
            "typeOne":"专题教育",
            "typeTwo":"品德教育",
            "keySpeakName":"张小平",
            "keySpeakUnivercity":"中央财经大学",
            "keySpeakPosition":"副教授",
            "keySpeakIntroduce":"张小平，法学博士，中央财经大学法学院副教授，加州大学伯克利分校访问学者。兼任中央财经大学中国环境金融法研究中心副主任，" +
            "中国证券法学研究会理事，中国能源法研究会理事、副秘书长。荣获中央财经大学第六届青年教师基本功比赛一等奖。长期从事《法学导论》、《法律方法》、《国际环境法》、《外国法制史》等课程的教学，并用英语为留学生和海外交换生讲授《中国法律概论》和《比较法》课程。有多本专著、译著和多篇学术论文发表。" ,
            "courseIntroduce":[" 什么是法律？宪法和其他法律的区别是什么？而我们又有什么权利和义务呢？和校园暴力、违法的事件频传，主要的原因之一就是同学们忽视犯罪行为的严重性，或者对法律了解太少。在日常生活中，你以为没有什麼大不了的事，其实已经触犯了法律。虽然同学们还未成年，但是万一不小心触犯了法律，还是会受到『少年事件处理法的惩罚』。因此，" +
            "为了防范於未然，同学们一定要有基本的法律常识，以免不小心误触法律，遗憾终生。","法律，用规则治理我们生活的世界；法律，为人们的行为提供正当性基础；法律，为纠纷解决提供平台和渠道；努力成为具备法制意识的国家公明和社会成员。法制是坚定的信仰，没有共同的践行只能成为僵死的教条；法制是有方向的旅行，走好自己的路才能到达远方。了解法制，呵护法制，是你我义不容辞的责任。"],
            "bigImgUrl":"http://p.ananas.chaoxing.com/star3/733_434c/5677aff9498ed8a4295dcb18.png",
            "videoUrl":"http://s1.ananas.chaoxing.com/video/bb/5680a1a7e4b0e85354abb161/sd.mp4",
            "courseChapter":[
                {
                    "学习宪法法律  建设法治体系":[
                        {"chapterNum":"1.1", "chapterName":"什么是“法律”"},
                        {"chapterNum":"1.2", "chapterName":"法律的特征"},
                        {"chapterNum":"1.3", "chapterName":"“道德”之源"},
                        {"chapterNum":"1.4", "chapterName":"法的演进与发展"},
                        {"chapterNum":"1.5", "chapterName":"社会主义法律的特征"},
                        {"chapterNum":"1.6", "chapterName":"社会主义法律的作用"},
                        {"chapterNum":"1.7", "chapterName":"社会主义法律的运行（上）"},
                        {"chapterNum":"1.8", "chapterName":"社会主义法律的运行（下）"},
                        {"chapterNum":"1.9", "chapterName":"我国宪法的基本原则"},
                        {"chapterNum":"1.10", "chapterName":"我国宪法确立的制度"},
                        {"chapterNum":"1.11", "chapterName":"我国的实体法律部门"},
                        {"chapterNum":"1.12", "chapterName":"我国的程序法律部门"},
                        {"chapterNum":"1.13", "chapterName":"建设中国特色社会主义法治体系的意义"},
                        {"chapterNum":"1.14", "chapterName":"建设中国特色社会主义法治体系的内容"},
                        {"chapterNum":"1.14", "chapterName":"全面依法治国的基本格局"}
                    ],
                    "树立法制观念 尊重法律权威":[
                        {"chapterNum":"2.1", "chapterName":"坚持走中国特色社会主义法治道路"},
                        {"chapterNum":"2.2", "chapterName":"坚持党的领导、人民当家作主与依法治国相统一"},
                        {"chapterNum":"2.3", "chapterName":"坚持依法治国和以德治国相结合"},
                        {"chapterNum":"2.4", "chapterName":"加强宪法实施 落实依宪治国"},
                        {"chapterNum":"2.5", "chapterName":"法治思维的含义"},
                        {"chapterNum":"2.6", "chapterName":"法治思维的基本内容"},
                        {"chapterNum":"2.7", "chapterName":"如何培养法治思维？"},
                        {"chapterNum":"2.8", "chapterName":"法律权威缘何重要？"},
                        {"chapterNum":"2.9", "chapterName":"我们应如何维护法律权威？"}
                    ],
                    "行使法律权利 履行法律义务":[
                        {"chapterNum":"3.1", "chapterName":"权利是谁赋予的？"},
                        {"chapterNum":"3.2", "chapterName":"人权是普世的吗？"},
                        {"chapterNum":"3.3", "chapterName":"义务是什么"},
                        {"chapterNum":"3.4", "chapterName":"权力越大一定越幸福吗？"},
                        {"chapterNum":"3.5", "chapterName":"选举权是天生的吗？"},
                        {"chapterNum":"3.6", "chapterName":"自由需要如何保障和规范？"},
                        {"chapterNum":"3.7", "chapterName":"如何看待财产权与公权力的冲突？"},
                        {"chapterNum":"3.8", "chapterName":"学生可以信教吗？"},
                        {"chapterNum":"3.9", "chapterName":"维权一定天经地义吗？"},
                        {"chapterNum":"3.10", "chapterName":"权利被侵害怎么办？"},
                        {"chapterNum":"3.11", "chapterName":"为什么要维护他人权利？"},
                        {"chapterNum":"3.12", "chapterName":"中国公民要履行那些义务？"}
                    ]
                }
            ]
        },
        {
            "courseid":"81929897",
            "courseName":"青春信仰",
            "typeOne":"专题教育",
            "typeTwo":"品德教育",
            "keySpeakName":"邢国忠",
            "keySpeakUnivercity":"中央财经大学",
            "keySpeakPosition":"副教授",
            "keySpeakIntroduce":"邢国忠，法学博士，中央财经大学马克思主义学院副教授。主要从事信仰与信仰教育研究。先后主持国家社会科学基金项目《当前大学生对宗教的关注度及心理取向研究》（项目编号：12CKS023）、北京市哲学社会科学规划项目《态度形成理论视角下首都大学生信仰问题研究》（项目编号：12KDC042）等5项课题，发表学术论文20余篇，获北京市高校思想政治理论课教学基本功比赛一等奖（2011年7月）、2009—2010年首都大学生思想政治教育优秀科研成果论文类二等奖（2011年2月）、中国广播电视协会全国征文比赛一等奖（2012年2月）、教育部高校思想政治理论课教学指导委员会教学研究百题征文比赛一等奖（2012年4月）、北京市首届高校思想政治理论课教学能手（2014年9月）、教" +
            "育部高校思想政治理论课教学能手（2014年11月）等多项教学科研奖励。" ,
            "courseIntroduce":["周恩来同志在年少时说出的那句“为中华之崛起而读书”，深深激励了一代又一代学子。在本课程中，邢教授和谢教授将会帮助同学们树立正确的世界观，人生观，树立正确的名利观，努力培养良好的价值精神，提高自身素质，完善人格品质，做有益于祖国和人民的人；要成为引领社会风气之先的力量，为推动我国先进生产力和先进文化的发展发挥积极作用；要从自己做起，努力做中华民族传统美德的传承者，良好社会风尚的倡导者。"],
            "bigImgUrl":"http://p.ananas.chaoxing.com/star3/origin/5678c169e4b0e85354a8bf33.jpg",
            "videoUrl":"http://s1.ananas.chaoxing.com/video/0d/567cf749e4b0e85354aaff33/sd.mp4",
            "courseChapter":[
                {
                    "追求远大理想 坚定崇高信念":[
                        {"chapterNum":"1.1", "chapterName":"理想的含义与特点"},
                        {"chapterNum":"1.2", "chapterName":"理想的类型"},
                        {"chapterNum":"1.3", "chapterName":"信念的含义与特点"},
                        {"chapterNum":"1.4", "chapterName":"信念系统的层次性"},
                        {"chapterNum":"1.5", "chapterName":"理想信念的重要意义"},
                        {"chapterNum":"1.6", "chapterName":"信仰是什么"},
                        {"chapterNum":"1.7", "chapterName":"为什么需要信仰"},
                        {"chapterNum":"1.8", "chapterName":"信仰有哪些层次"},
                        {"chapterNum":"1.9", "chapterName":"选择信仰的四个参考标准"},
                        {"chapterNum":"1.10", "chapterName":"确立马克思主义的科学信仰"},
                        {"chapterNum":"1.11", "chapterName":"马克思主义信仰的基本特点"},
                        {"chapterNum":"1.12", "chapterName":"树立中国特色社会主义共同理想"},
                        {"chapterNum":"1.13", "chapterName":"正确理解理想与现实的关系"},
                        {"chapterNum":"1.14", "chapterName":"坚持个人理想与社会理想的统一"},
                        {"chapterNum":"1.14", "chapterName":"在实现中国梦的实践中放飞青春梦想"}
                    ],
                    "弘扬中国精神 共助精神家园":[
                        {"chapterNum":"2.1", "chapterName":"什么是精神"},
                        {"chapterNum":"2.2", "chapterName":"什么是中国精神"},
                        {"chapterNum":"2.3", "chapterName":"中国精神的历史发展"},
                        {"chapterNum":"2.4", "chapterName":"如何看待今日中国之中国精神"},
                        {"chapterNum":"2.5", "chapterName":"中华民族精神基调和底色是什么"},
                        {"chapterNum":"2.6", "chapterName":"爱国主义何以成为民族精神的核心"},
                        {"chapterNum":"2.7", "chapterName":"新时期的爱国主义发生了哪些新变化？"},
                        {"chapterNum":"2.8", "chapterName":"当代青年学生如何做忠诚的爱国者"},
                        {"chapterNum":"2.9", "chapterName":"我们这个时代需要怎样的时代精神？"},
                        {"chapterNum":"2.10", "chapterName":"当代青年学生如何做改革创新的实践者？"}
                    ],
                    "领悟人生真谛 创造人生价值":[
                        {"chapterNum":"3.1", "chapterName":"人之为人的本质是什么？"},
                        {"chapterNum":"3.2", "chapterName":"人生是什么"},
                        {"chapterNum":"3.3", "chapterName":"既然人都是要死的，但为何还要活着"},
                        {"chapterNum":"3.4", "chapterName":"人为什么活着"},
                        {"chapterNum":"3.5", "chapterName":"几种值得反思的人生"},
                        {"chapterNum":"3.6", "chapterName":"怎样的人生是有价值的"},
                        {"chapterNum":"3.7", "chapterName":"如何完成一个我"},
                        {"chapterNum":"3.8", "chapterName":"如何从成己到成物、成人"},
                        {"chapterNum":"3.9", "chapterName":"如何学会与人生环境相处"},
                        {"chapterNum":"3.10", "chapterName":"如何安放我们的心"},
                        {"chapterNum":"3.11", "chapterName":"如何获得人生的自由"}
                    ]
                }
            ]
        },
        {
            "courseid":"82646184",
            "courseName":"家长如何与孩子有效沟通",
            "typeOne":"专题教育",
            "typeTwo":"成长教育",
            "keySpeakName":"邢军",
            "keySpeakUnivercity":"贵州沙道金教育投资管理公司",
            "keySpeakPosition":"著名亲子教育专家",
            "keySpeakIntroduce":"邢军，著名亲子教育专家 《父母课堂》创办人，毕业于师范院校，多年来一直从事成人教育培训工作。曾被多次受邀在国内多所高校及知名企业作培训演讲，同时热衷于“家庭教育”这一领域的学习和研究。首创21次现代家长素质教育培训课程，并于2008年创办了《父母课堂》，用通俗易懂、深入浅出的讲授方法不断进行正确的家庭教育观的实践与传播。已成功教授无数家长掌握了现代孩子教育的技巧和方法，帮助无数家长找到了他们在教育孩子过程中的盲点，" +
        "引导家长走出家庭教育的误区，改善了他们的亲子关系，家长好评如潮。" ,
            "courseIntroduce":["该课程讲解有关家长如何与孩子有效沟通以及多重案例分析，涉及青少年教育等多个知识点的讲解，对家长以及孩子的立场进行了全面的剖析。良好和谐的家庭氛围是家长与孩子顺利沟通的重要条件。一方面要求家庭成员之间要和睦相处，相互体谅，互相尊重；另一方面家长与孩子能在民主、平等的氛围中生活，精神上没有压力。此外，谈话的时间、场合也应考虑、选择，尽量安排在比较轻松、自然的环境中进行，比如可以在饭桌上，也可以在散步的时候进行轻松的交谈。"],
            "bigImgUrl":"http://p.ananas.chaoxing.com/star3/733_434c/564d9665e4b0e85354981bc1.png",
            "videoUrl":"http://s1.ananas.chaoxing.com/video/a6/564d9c68e4b0e85354981e41/sd.mp4",
            "courseChapter":[
                {
                    "孩子的一切问题源于父母":[
                        {"chapterNum":"1.1", "chapterName":"学习指引"},
                        {"chapterNum":"1.2", "chapterName":"孩子的一切问题源于父母"}
                    ],
                    "克服家长与孩子间的沟通障碍":[
                        {"chapterNum":"2.1", "chapterName":"学习指引"},
                        {"chapterNum":"2.2", "chapterName":"克服家长与孩子间的沟通障碍"}
                    ],
                    "孩子需要家长的李杰和关爱":[
                        {"chapterNum":"3.1", "chapterName":"学习指引"},
                        {"chapterNum":"3.2", "chapterName":"孩子需要家长的理解和关爱"}
                    ],
                    "家长对孩子的教育应遵循原则":[
                        {"chapterNum":"4.1", "chapterName":"学习指引"},
                        {"chapterNum":"4.2", "chapterName":"家长对孩子的教育应遵循原则"}
                    ],
                    "家长与孩子沟通的正确方法":[
                        {"chapterNum":"5.1", "chapterName":"学习指引"},
                        {"chapterNum":"5.2", "chapterName":"家长与孩子沟通的正确方法"}
                    ],
                    "通过改变自己来影响孩子":[
                        {"chapterNum":"6.1", "chapterName":"学习指引"},
                        {"chapterNum":"6.2", "chapterName":"通过改变自己来影响孩子"}
                    ]
                }
            ]
        },
        {
            "courseid":"81599033",
            "courseName":"情感哲学与情感教育",
            "typeOne":"专题教育",
            "typeTwo":"成长教育",
            "keySpeakName":"杨岚",
            "keySpeakUnivercity":"南开大学",
            "keySpeakPosition":"教授",
            "keySpeakIntroduce":"杨岚，女，1966年6月出生，1986年毕业于内蒙古大学哲学系，获哲学学士学位，1989年毕业于南开大学哲学系美学专业，获哲学硕士学位，分配到天津市委党校工作，1995年晋升为副教授，1998年10月起任天津市委党校哲学部副主任. 2001年毕业于南开大学哲学系社会哲学专业，获哲学博士学位，2002年晋升为教授。中华美学学会会员，天津市艺术学会理事，天津市美学学会理事。" ,
            "courseIntroduce":["情感朝向人的内心世界，与人的生活息息相关。而长久以来我们的应试教育体制偏重认知训练、忽略情感成长与引导的教育模式下，所带来的关乎心理健康、生活质量、社会和谐的问题随之而来。该课包含情感哲学、情感现象学、情感教育三个板块，从不同的角度去分析情感，研究情感发展的规律，对人类情感发展的理想与现实之间的冲突与趋近的态势进行理性导引，有助于学习者进行有效的自我情感分析，" +
            "调整生活状态，提升人类生存的质量，促进人类心理科学的完善。"],
            "bigImgUrl":"http://p.ananas.chaoxing.com/star3/733_434c/56209892e4b0222c70a8bb66.png",
            "videoUrl":"",
            "courseChapter":[
                {
                    "中国情感教育现状分析及对策研究":[
                        {"chapterNum":"1.1", "chapterName":"中国情感教育现状分析及对策研究（一）"},
                        {"chapterNum":"1.2", "chapterName":"中国情感教育现状分析及对策研究（二）"},
                        {"chapterNum":"1.3", "chapterName":"中国情感教育现状分析及对策研究（三）"},
                        {"chapterNum":"1.4", "chapterName":"中国情感教育现状分析及对策研究（四）"}
                    ],
                    "情感研究的意义与目标":[
                        {"chapterNum":"2.1", "chapterName":"情感研究的意义"},
                        {"chapterNum":"2.2", "chapterName":"情感研究的目标"},
                        {"chapterNum":"2.3", "chapterName":"情感的特性"},
                        {"chapterNum":"2.4", "chapterName":"国外的情感研究"}
                    ],
                    "简单而强烈的情感":[
                        {"chapterNum":"3.1", "chapterName":"恐惧（上）"},
                        {"chapterNum":"3.2", "chapterName":"恐惧（下）"},
                        {"chapterNum":"3.3", "chapterName":"愤怒（上）"},
                        {"chapterNum":"3.4", "chapterName":"愤怒（下）"},
                        {"chapterNum":"3.5", "chapterName":"喜乐（上）"},
                        {"chapterNum":"3.6", "chapterName":"喜乐（下）"},
                        {"chapterNum":"3.7", "chapterName":"同情）"},
                        {"chapterNum":"3.8", "chapterName":"关爱（下）"},
                        {"chapterNum":"3.9", "chapterName":"关爱（上）"}
                    ],
                    "情感现象的讨论":[
                        {"chapterNum":"4.1", "chapterName":"情感现象的讨论（上）"},
                        {"chapterNum":"4.2", "chapterName":"情感现象的讨论（下）"}
                    ],
                    "复杂而灰调的情感":[
                        {"chapterNum":"5.1", "chapterName":"厌憎"},
                        {"chapterNum":"5.2", "chapterName":"嫉妒"},
                        {"chapterNum":"5.3", "chapterName":"仇恨"},
                        {"chapterNum":"5.4", "chapterName":"悲伤"},
                        {"chapterNum":"5.5", "chapterName":"忧愁"},
                        {"chapterNum":"5.6", "chapterName":"怀疑"},
                        {"chapterNum":"5.7", "chapterName":"烦恼"}
                    ],
                    "自我反思性的情感":[
                        {"chapterNum":"6.1", "chapterName":"忏悔"},
                        {"chapterNum":"6.2", "chapterName":"遗憾"}
                    ],
                    "抽象的情感":[
                        {"chapterNum":"7.1", "chapterName":"希望"},
                        {"chapterNum":"7.2", "chapterName":"失望"},
                        {"chapterNum":"7.3", "chapterName":"绝望"},
                        {"chapterNum":"7.4", "chapterName":"空虚"},
                        {"chapterNum":"7.5", "chapterName":"淡漠"},
                        {"chapterNum":"7.6", "chapterName":"宁静"},
                        {"chapterNum":"7.7", "chapterName":"超脱"},
                        {"chapterNum":"7.8", "chapterName":"怡然"}
                    ],
                    "关系型情感":[
                        {"chapterNum":"8.1", "chapterName":"慈悲"},
                        {"chapterNum":"8.2", "chapterName":"拯救"},
                        {"chapterNum":"8.3", "chapterName":"崇拜"},
                        {"chapterNum":"8.4", "chapterName":"尊敬"},
                        {"chapterNum":"8.5", "chapterName":"爱"}
                    ],
                    "情感的认知":[
                        {"chapterNum":"9.1", "chapterName":"情感的认知（上）"},
                        {"chapterNum":"9.2", "chapterName":"情感的认知（中）"},
                        {"chapterNum":"9.3", "chapterName":"情感的认知（下）"}
                    ],
                    "情感形式分析":[
                        {"chapterNum":"10.1", "chapterName":"情感形式分析（上）"},
                        {"chapterNum":"10.2", "chapterName":"情感形式分析（下）"}
                    ],
                    "情感世界规律":[
                        {"chapterNum":"11.1", "chapterName":"情感世界规律"},
                        {"chapterNum":"11.2", "chapterName":"良善风俗"},
                        {"chapterNum":"11.3", "chapterName":"舆论与情感（上）"},
                        {"chapterNum":"11.4", "chapterName":"舆论与情感（中）"},
                        {"chapterNum":"11.5", "chapterName":"舆论与情感（下）"}
                    ],
                    "情感世界分析":[
                        {"chapterNum":"12.1", "chapterName":"个体情感"},
                        {"chapterNum":"12.2", "chapterName":"社会情感"},
                        {"chapterNum":"12.3", "chapterName":"文化情感"}
                    ],
                    "全球化时代的情感世界":[
                        {"chapterNum":"13.1", "chapterName":"胎儿、婴儿阶段"},
                        {"chapterNum":"13.2", "chapterName":"小学阶段"},
                        {"chapterNum":"13.3", "chapterName":"中学阶段"},
                        {"chapterNum":"13.4", "chapterName":"大学阶段"}
                    ]
                }
            ]
        },
        {
            "courseid":"81923679",
            "courseName":"放飞心灵 激扬青春——青少年心理健康",
            "typeOne":"专题教育",
            "typeTwo":"成长教育",
            "keySpeakName":"颜苏勤",
            "keySpeakUnivercity":"上海市商业学校",
            "keySpeakPosition":"高级教师；国家二级心理咨询师",
            "keySpeakIntroduce":"研究领域:十多年来，颜老师致力于青少年的心理健康教育、青春期教育、感恩教育、心理韧性的培养、危机干预及家庭教育等方面的理论研究和教学实践探索。同时开展社区讲座，精心策划并组织对心理教师的团体心理辅导、沙盘游戏操作培训等等，尤其擅长对高职、中职等不良认知和情绪情感困惑的心理咨询与家庭辅导。" +
            "著作:编著 《中职生心理健康》 上海人民出版社出版；主编 《中职生青春期心理健康自助手册》 高等教育出版社出版；主编 《团体心理辅导主题活动方案》  高等教育出版社出版。" +
            "荣誉与奖励：荣获2014年全国职教黄炎培杰出教师奖" ,
            "courseIntroduce":["本课程是针对高中生这一青少年群体设计并开发的课程，课程内容从多个角度，多个层面讲解有关高中生青少年群体的心理健康问题，以帮助这一时期的他们健康、快乐成长。每一章节主要围绕高中生青少年群体的心理需求和特点设计内容，通过“专家讲解”深入浅出地介绍心理健康的基本知识及相关理论，" +
            "让高中生青少年群体了解心理健康常识，树立心理健康意识；通过“互动成长”板块，引导高中生青少年群体直面成长过程中的矛盾和内心冲突，帮助高中生青少年群体正确应对挫折，提高适应社会的能力；在“虚拟心理咨询室“，通过趣味心理测验和心理健康小贴士来让学生认识自己的心理困惑，找到调适心理困惑的方法，以提高解决成长、心理困惑或行为问题的能力。“拓展教与学”板块为教师和学生提供大量的有针对性的资源，便于教师组织教学活动，和学生课外自主学习。"],
            "bigImgUrl":"http://p.ananas.chaoxing.com/star3/733_434c/5657b847498ed8a429421eb7.png",
            "videoUrl":"http://s1.ananas.chaoxing.com/video/5b/56568c44e4b0e853549a63ec/sd.mp4",
            "courseChapter":[
                {
                    "心理健康——人生成功的基石":[
                        {"chapterNum":"1.1", "chapterName":"心理健康我关注"},
                        {"chapterNum":"1.2", "chapterName":"走出嫉妒天地宽"}
                    ],
                    "认识自我——人生潜能的开发":[
                        {"chapterNum":"2.1", "chapterName":"用心看自己"},
                        {"chapterNum":"2.2", "chapterName":"自信在心中"},
                        {"chapterNum":"2.3", "chapterName":"握好方向盘"}
                    ],
                    "通情达理——人生情绪的调控":[
                        {"chapterNum":"3.1", "chapterName":"情绪我调控"},
                        {"chapterNum":"3.2", "chapterName":"心情我做主"}
                    ],
                    "青春护航——人生花季的交往":[
                        {"chapterNum":"4.1", "chapterName":"男生与女生"}
                    ],
                    "人际亲情——人生成长的支持":[
                        {"chapterNum":"5.1", "chapterName":"感恩父母心"},
                        {"chapterNum":"5.2", "chapterName":"与益友同行"},
                        {"chapterNum":"5.3", "chapterName":"筑师生情谊"}
                    ],
                    "有效学习——人生发展的基础":[
                        {"chapterNum":"6.1", "chapterName":"我要金手指"},
                        {"chapterNum":"6.2", "chapterName":"提高注意力"}
                    ],
                    "珍爱生命——人生旅途的责任":[
                        {"chapterNum":"7.1", "chapterName":"直面挫折"},
                        {"chapterNum":"7.2", "chapterName":"珍爱生命"}
                    ]
                }
            ]
        },
        {
            "courseid":"86912997",
            "courseName":"高中生生涯规划(高三)",
            "typeOne":"专题教育",
            "typeTwo":"成长教育",
            "keySpeakName":"熊丙奇",
            "keySpeakUnivercity":"上海交通大学",
            "keySpeakPosition":"编审",
            "keySpeakIntroduce":"熊丙奇  上海交通大学  编审著名教育学者、博士，21世纪教育研究院副院长，中国高校校报协会副会长，上海市高校校报研究会理事长。代表作品《大学有问题》、《体制迷墙》、《青春档案》、《高中生职业生涯规划》等。",
            "courseIntroduce":["规划和把握人生，就是知与行不断超越、循环往复向新目标前进的过程。这种超越和向新目标的攀登，是自我综合素质的一种质变。从高一开始的三年中学生活，其实也包含着这样的过程。人们常说，生活之树常青。能否把对人生的追求融于常青之树的生活之树中，是对人生选择是否成功的考验。"],
            "bigImgUrl":"http://p.ananas.chaoxing.com/star3/733_434c/5678e1c3e4b0e85354a8e745.jpg",
            "videoUrl":"",
            "courseChapter":[
                {
                    "新高三——摆脱高三焦虑":[
                        {"chapterNum":"1.1", "chapterName":"高考焦虑"},
                        {"chapterNum":"1.2", "chapterName":"摆脱焦虑"},
                        {"chapterNum":"1.3", "chapterName":"高考发挥"}
                    ],
                    "新动力——高三选择与准备":[
                        {"chapterNum":"2.1", "chapterName":"本科院校"},
                        {"chapterNum":"2.2", "chapterName":"高职院校"},
                        {"chapterNum":"2.3", "chapterName":"自主招生"},
                        {"chapterNum":"2.4", "chapterName":"出国留学"}
                    ],
                    "新志愿——高考志愿填报的理念与方法":[
                        {"chapterNum":"3.1", "chapterName":"录取规则"},
                        {"chapterNum":"3.2", "chapterName":"等第志愿"},
                        {"chapterNum":"3.3", "chapterName":"平行志愿"},
                        {"chapterNum":"3.4", "chapterName":"警惕高考诈骗"}
                    ],
                    "新未来——高中后的多元发展":[
                        {"chapterNum":"4.1", "chapterName":"高考成败"},
                        {"chapterNum":"4.2", "chapterName":"终身学习"},
                        {"chapterNum":"4.3", "chapterName":"大学发展"}
                    ]
                }
            ]
        },
        {
            "courseid":"86347199",
            "courseName":"今天，你安全吗？",
            "typeOne":"专题教育",
            "typeTwo":"安全教育",
            "keySpeakName":"李长虹",
            "keySpeakUnivercity":"广东工程职业技术学院",
            "keySpeakPosition":"教师",
            "keySpeakIntroduce":"李长虹 教师  单位：广东工程职业技术学院  职位：心理健康辅导中心主任",
            "courseIntroduce":["厨房里有可能引发火灾；用湿抹布擦电插座可能会触电；手机可能在公交车上被顺手牵羊......今天，你安全吗？学生背后支撑的是千万家庭的和谐与幸福，学校作为孩子们在校的“大家长”，更需要将安全教育强有力的灌输给每一位在校学生，因为在灾难和危险面前，人的生命脆弱的不堪一击。如何保护珍贵的生命，规避不必要的隐患，又如何拥有一个平安和谐的生活，是值得我们深思和重视的问题。"],
            "bigImgUrl":"http://p.ananas.chaoxing.com/star3/733_434c/56972a58e4b0e85354b7b6db.png",
            "videoUrl":"",
            "courseChapter":[
                {
                    "人身安全":[
                        {"chapterNum":"1.1", "chapterName":"“黄色”警戒"},
                        {"chapterNum":"1.2", "chapterName":"“小甜头隐大苦头”"},
                        {"chapterNum":"1.3", "chapterName":"千万勿动第一口"},
                        {"chapterNum":"1.4", "chapterName":"小矛盾带来大伤害（上）"},
                        {"chapterNum":"1.5", "chapterName":"小矛盾带来大伤害（下）"},
                        {"chapterNum":"1.6", "chapterName":"与打架斗殴说再见"},
                        {"chapterNum":"1.7", "chapterName":"如何应对滋扰事件"},
                        {"chapterNum":"1.8", "chapterName":"做女生好难"},
                        {"chapterNum":"1.9", "chapterName":"作为女生一定要注意的"}
                    ],
                    "心理安全":[
                        {"chapterNum":"2.1", "chapterName":"走进中学生心理安全"},
                        {"chapterNum":"2.2", "chapterName":"正确应对压力与挫折"},
                        {"chapterNum":"2.3", "chapterName":"挫折心理与心理安全感"},
                        {"chapterNum":"2.4", "chapterName":"中学生人际交往的心理误区"},
                        {"chapterNum":"2.5", "chapterName":"良好人际关系的建立和改善"},
                        {"chapterNum":"2.6", "chapterName":"同学心理安全的识别与维护"},
                        {"chapterNum":"2.7", "chapterName":"“我”的现在与未来"}
                    ],
                    "运动安全":[
                        {"chapterNum":"3.1", "chapterName":"运动损伤分类及处理"},
                        {"chapterNum":"3.2", "chapterName":"肌肉拉伤及处理"},
                        {"chapterNum":"3.3", "chapterName":"肌肉痉挛及处理"},
                        {"chapterNum":"3.4", "chapterName":"中暑及处理"},
                        {"chapterNum":"3.5", "chapterName":"重力性休克及处理"},
                        {"chapterNum":"3.6", "chapterName":"运动中腹痛及处理"},
                        {"chapterNum":"3.7", "chapterName":"健康评估常识"},
                        {"chapterNum":"3.8", "chapterName":"运动处方设计"},
                        {"chapterNum":"3.9", "chapterName":"运动疲劳消除"},
                        {"chapterNum":"3.10", "chapterName":"常见运动中的保护措施"},
                        {"chapterNum":"3.11", "chapterName":"运动营养"},
                        {"chapterNum":"3.12", "chapterName":"溺水救助"}
                    ],
                    "财产安全":[
                        {"chapterNum":"4.1", "chapterName":"“天下有贼”"},
                        {"chapterNum":"4.2", "chapterName":"如何避免成为歹徒的“猎物”"},
                        {"chapterNum":"4.3", "chapterName":"为什么受骗的会是我"},
                        {"chapterNum":"4.4", "chapterName":"你遇到过这些诈骗吗？"},
                        {"chapterNum":"4.5", "chapterName":"“两个凡是一求助”"},
                        {"chapterNum":"4.6", "chapterName":"损坏公共财产的代价"},
                        {"chapterNum":"4.7", "chapterName":"馅饼越大陷阱越深"},
                        {"chapterNum":"4.8", "chapterName":"远离非法传教及邪教"}
                    ],
                    "女子防狼自卫术":[
                        {"chapterNum":"5.1", "chapterName":"基本擒拿示范"},
                        {"chapterNum":"5.2", "chapterName":"防狼四法"},
                        {"chapterNum":"5.3", "chapterName":"掌击下颌"},
                        {"chapterNum":"5.4", "chapterName":"提膝顶裆"},
                        {"chapterNum":"5.5", "chapterName":"弹踢击裆"},
                        {"chapterNum":"5.6", "chapterName":"寸力拍裆"},
                        {"chapterNum":"5.7", "chapterName":"猛踩脚趾"},
                        {"chapterNum":"5.8", "chapterName":"手臂击裆"},
                        {"chapterNum":"5.9", "chapterName":"倒地蹬蹄"},
                        {"chapterNum":"5.10", "chapterName":"指挖双眼"}
                    ]
                }
            ]
        },
        {
            "courseid":"86462301",
            "courseName":"今天，做维护社会和平的超人",
            "typeOne":"专题教育",
            "typeTwo":"安全教育",
            "keySpeakName":"张国清",
            "keySpeakUnivercity":"同济大学",
            "keySpeakPosition":"教授",
            "keySpeakIntroduce":"张国清 教授  单位：同济大学  职位：军事教研室主任",
            "courseIntroduce":["一个国家，其公民国家安全意识的高低，事关整个国家的安全与否。作为国家的未来和希望的中小学生，其国家安全意识的强弱，对国家的安全更有着直接的影响。通过对本门课的学习，学生可以较为系统的学习国家安全、公共安全、消防安全、交通安全、艾滋病知识及预防，全面提升社会安全意识。今天，你可以做维护社会和平的超人。"],
            "bigImgUrl":"http://p.ananas.chaoxing.com/star3/733_434c/5698c87ce4b0e85354b88b43.jpg",
            "videoUrl":"",
            "courseChapter":[
                {
                    "课程导学":[
                        {"chapterNum":"1.1", "chapterName":"安全在心中"}
                    ],
                    "国家安全":[
                        {"chapterNum":"2.1", "chapterName":"了解国家总体安全观"},
                        {"chapterNum":"2.2", "chapterName":"提高国家主权安全观"},
                        {"chapterNum":"2.3", "chapterName":"增强国土安全意识"},
                        {"chapterNum":"2.4", "chapterName":"捍卫国家海洋国土"},
                        {"chapterNum":"2.5", "chapterName":"反对分裂、台海统一"},
                        {"chapterNum":"2.6", "chapterName":"富国强兵，强兵卫国"},
                        {"chapterNum":"2.7", "chapterName":"崇尚科学反对邪教"},
                        {"chapterNum":"2.8", "chapterName":"遵守校纪校规，树立法律意识"}
                    ],
                    "公共安全":[
                        {"chapterNum":"3.1", "chapterName":"突发公共事件与应急预防演练"},
                        {"chapterNum":"3.2", "chapterName":"常见自然灾害的自救"},
                        {"chapterNum":"3.3", "chapterName":"气象灾害的安全防御"},
                        {"chapterNum":"3.4", "chapterName":"极端温度的防御"},
                        {"chapterNum":"3.5", "chapterName":"地震、泥石流、洪水的防护"},
                        {"chapterNum":"3.6", "chapterName":"恐怖活动知多少"},
                        {"chapterNum":"3.7", "chapterName":"恐怖活动 沉着应对"}
                    ],
                    "消防安全":[
                        {"chapterNum":"4.1", "chapterName":"消防安全，重于泰山"},
                        {"chapterNum":"4.2", "chapterName":"消防案例解析"},
                        {"chapterNum":"4.3", "chapterName":"火灾猛于虎"},
                        {"chapterNum":"4.4", "chapterName":"火灾形成三要素及灭火原理"},
                        {"chapterNum":"4.5", "chapterName":"火灾种类及灭火方法"},
                        {"chapterNum":"4.6", "chapterName":"你会拨打119吗？"},
                        {"chapterNum":"4.7", "chapterName":"什么是初起火？"},
                        {"chapterNum":"4.8", "chapterName":"你身边的灭火剂"},
                        {"chapterNum":"4.9", "chapterName":"常见消防器材的使用"},
                        {"chapterNum":"4.10", "chapterName":"火场逃生误区"},
                        {"chapterNum":"4.11", "chapterName":"火场逃生九诀"}
                    ],
                    "交通安全":[
                        {"chapterNum":"5.1", "chapterName":"交通标志、标线"},
                        {"chapterNum":"5.2", "chapterName":"灯色信号、手势信号"},
                        {"chapterNum":"5.3", "chapterName":"行人通行设施"},
                        {"chapterNum":"5.4", "chapterName":"“私家车”出行安全四要素"},
                        {"chapterNum":"5.5", "chapterName":"行人安全篇（上）"},
                        {"chapterNum":"5.6", "chapterName":"行人安全篇（下）"},
                        {"chapterNum":"5.7", "chapterName":"非机动车安全篇"},
                        {"chapterNum":"5.8", "chapterName":"行车驾驶陋习"},
                        {"chapterNum":"5.9", "chapterName":"行车准备与驾乘须知"},
                        {"chapterNum":"5.10", "chapterName":"驾驶注意事项 事故现场处置"}
                    ],
                    "艾滋病知识及预防":[
                        {"chapterNum":"6.1", "chapterName":"艾滋病的起源"},
                        {"chapterNum":"6.2", "chapterName":"流行现状"},
                        {"chapterNum":"6.3", "chapterName":"临床表现"},
                        {"chapterNum":"6.4", "chapterName":"两性传播"},
                        {"chapterNum":"6.5", "chapterName":"血液传播和母婴传播"},
                        {"chapterNum":"6.6", "chapterName":"预防与控制"},
                        {"chapterNum":"6.7", "chapterName":"HIV自愿检测咨询"},
                        {"chapterNum":"6.8", "chapterName":"反对艾滋病歧视"},
                        {"chapterNum":"6.9", "chapterName":"关爱艾滋 反对歧视"}
                    ]
                }
            ]
        },
        {
            "courseid":"81102417",
            "courseName":"国防军事教育（现代化军事战争）",
            "typeOne":"专题教育",
            "typeTwo":"安全教育",
            "keySpeakName":"艾跃进",
            "keySpeakUnivercity":"南开大学",
            "keySpeakPosition":"教授",
            "keySpeakIntroduce":"曾接受过新华社、央视《新闻联播》、《新闻频道》等媒体的采访，被媒体评为“魅力教授”、“最受欢迎教授”。南开大学教授，全国著名演讲家，口才艺术、社交礼仪专家；领袖学、成功学、军事学专家；国际问题和形势政策专家；中华规范婚礼创始人；著名策划人、主持人，天津市国学研究会副会长，多次接受包括新华社、央视《新闻联播》、《新闻频道》等媒体的采访，担任天津电视台四个栏目的嘉宾，被媒体评为“魅力教授”、“最受欢迎教授”。每年在全国各地的政府机关，企事业单位，北大、清华等著名学府，举办上百场讲座和演讲，现场反响强烈，好评如潮。艾跃进教授每年都要在天津和全国各地的政府机关，事业单位，科研院所，部队（包括军校），农村、知名企业和北大、清华等著名学府，举办上百场讲座和演讲；还给SOS村的孤儿、养老院的职工、监狱的犯人和干警、开发区的农民工讲课，都受到了热烈欢迎。 　　艾跃进教授演讲风格幽默、激情四射，具有极强的感染力与号召力。其中在北京大学举办的《美伊战争后的世界形势》的演讲，现场反响强烈，好评如潮，掌声经久不息，演讲实录被收入《在北大听讲座》一书，《书摘》杂志旋即予以转载。",
            "courseIntroduce":["军事理论课程以国防教育为主线，按照教育要面向现代化、面向世界、面向未来，适应我国人才培养的长远战略目标和加强国防后备力量建设的需要，通过艾跃进教授极具感染力和号召力的讲述，能够使学生掌握基本军事理论与军事技能，增强国防观念和国家安全意识，强化爱国主义、集体主义观念，加强组织纪律性，促进在校学生综合素质的提高，培养作为中国人的危机感与责任感。"],
            "bigImgUrl":"http://p.ananas.chaoxing.com/star3/733_434c/55fbb8f4498ed981287e643f.jpg",
            "videoUrl":"http://s1.ananas.chaoxing.com/video/1b/5577c149e4b0ec35e2d1163b/sd.mp4",
            "courseChapter":[
                {
                    "世界军事环境":[
                        {"chapterNum":"1.1", "chapterName":"世界格局的演变"},
                        {"chapterNum":"1.2", "chapterName":"美国在伊斯兰世界的扩张"},
                        {"chapterNum":"1.3", "chapterName":"美国在东亚、俄罗斯的扩张"},
                        {"chapterNum":"1.4", "chapterName":"美国的战争策略与文化扩张"},
                        {"chapterNum":"1.5", "chapterName":"战略环境与国际战略格局"},
                        {"chapterNum":"1.6", "chapterName":"当前世界军事形势与中国周边军事环境"},
                        {"chapterNum":"1.7", "chapterName":"强国是中国的当务之急"},
                        {"chapterNum":"1.8", "chapterName":"中美建交史"},
                        {"chapterNum":"1.9", "chapterName":"实现中国梦的十大主张"}
                    ],
                    "现代战争知识":[
                        {"chapterNum":"2.1", "chapterName":"信息化战争的定义"},
                        {"chapterNum":"2.2", "chapterName":"信息化战争的产生和形成"},
                        {"chapterNum":"2.3", "chapterName":"信息化战争的特征及发展趋势"},
                        {"chapterNum":"2.4", "chapterName":"联合作战理论"},
                        {"chapterNum":"2.5", "chapterName":"信息作战理论、精确作战理论"}
                    ],
                    "局部战争战例分析":[
                        {"chapterNum":"3.1", "chapterName":"海湾战争的作战企图"},
                        {"chapterNum":"3.2", "chapterName":"海湾战争的战争准备"},
                        {"chapterNum":"3.3", "chapterName":"海湾战争的经过与启示"},
                        {"chapterNum":"3.4", "chapterName":"科索沃战争的作战企图"},
                        {"chapterNum":"3.5", "chapterName":"科索沃战争的战争准备"},
                        {"chapterNum":"3.6", "chapterName":"科索沃战争的经过与启示"},
                        {"chapterNum":"3.7", "chapterName":"阿富汗战争的作战企图与战争准备"},
                        {"chapterNum":"3.8", "chapterName":"阿富汗战争的经过与启示"},
                        {"chapterNum":"3.9", "chapterName":"伊拉克战争的作战企图"},
                        {"chapterNum":"3.10", "chapterName":"伊拉克战争的战争准备"},
                        {"chapterNum":"3.11", "chapterName":"伊拉克战争的经过与评价"}
                    ]
                }
            ]
        },
        {
            "courseid":"81086442",
            "courseName":"国防军事教育（高科技下的军事）",
            "typeOne":"专题教育",
            "typeTwo":"安全教育",
            "keySpeakName":"赵宗九",
            "keySpeakUnivercity":"南京政治学院",
            "keySpeakPosition":"教授 教研室主任",
            "keySpeakIntroduce":"任空军政治学院、南京政治学院上海分院军事教研室主任，大校军衔，硕士生导师。兼任上海国际战略研究会副秘书长，军队管理学会副秘书长，上海战略研究所、上海国防研究所、上海国防教育讲师团及上海多个区讲师团教授。近年来，以军事专家的身份在上海电视台、东方电视台、上海卫视台、上海有线电视台、上海教育台、东方电台的《晚间新闻》、《东视广角》、《当代军人》、《新闻观察》、《新闻透视》等8个栏目中制作有关专题和国防教育电视节目40余次。在全国二十几家报刊发表了《战争起源、战争定义及战争一词的使用》等250余篇论文，计150余万字。著作有：《军事战略》、《军事指挥》、《大环境－周边军情研究》等20余部，计400余万字。其中，有关战争起源研究为全国学术界主要代表人物；《军事十万个为什么》为国家九五重点图书；《现代国防与军队现代化》在全军获优秀理论教材特别奖、空军科研二等奖。主编、制作电脑教学软件的《现代军用飞机》获全国多媒体教学软件三等奖、空军科技成果二等奖；《周边军情》获中国人民解放军军队管理学会一等奖。",
            "courseIntroduce":["军事理论课程以国防教育为主线，按照教育要面向现代化、面向世界、面向未来，适应我国人才培养的长远战略目标和加强国防后备力量建设的需要，通过艾跃进教授极具感染力和号召力的讲述，能够使学生掌握基本军事理论与军事技能，增强国防观念和国家安全意识，强化爱国主义、集体主义观念，加强组织纪律性，促进在校学生综合素质的提高，培养作为中国人的危机感与责任感。"],
            "bigImgUrl":"http://p.ananas.chaoxing.com/star3/733_434c/54471b8fa310a7916bc4809e.png",
            "videoUrl":"http://s1.ananas.chaoxing.com/video/1b/5577c149e4b0ec35e2d1163b/sd.mp4",
            "courseChapter":[
                {
                    "军事高技术概论":[
                        {"chapterNum":"1.1", "chapterName":"概述"},
                        {"chapterNum":"1.2", "chapterName":"军事高技术的特点与影响"}
                    ],
                    "侦察监视技术":[
                        {"chapterNum":"2.1", "chapterName":"概述"},
                        {"chapterNum":"2.2", "chapterName":"水下与航空侦察监视技术"},
                        {"chapterNum":"2.3", "chapterName":"侦察卫星的概况与运用"}
                    ],
                    "伪装与隐身技术":[
                        {"chapterNum":"3.1", "chapterName":"概述"},
                        {"chapterNum":"3.2", "chapterName":"隐身技术的运用"}
                    ],
                    "航天技术":[
                        {"chapterNum":"4.1", "chapterName":"航天技术的发展状况"}
                    ],
                    "军事领域中的信息技术":[
                        {"chapterNum":"5.1", "chapterName":"信息技术及其在军事领域的应用"},
                        {"chapterNum":"5.2", "chapterName":"建设数字化部队"},
                        {"chapterNum":"5.3", "chapterName":"信息的获取、传递、处理技术"}
                    ],
                    "军队指挥信息系统":[
                        {"chapterNum":"6.1", "chapterName":"概述"},
                        {"chapterNum":"6.2", "chapterName":"军队指挥信息系统的影响与发展"}
                    ],
                    "精确制导武器":[
                        {"chapterNum":"7.1", "chapterName":"概述"},
                        {"chapterNum":"7.2", "chapterName":"精确制导武器的指导方式"},
                        {"chapterNum":"7.3", "chapterName":"精确制导武器的分类（一）"},
                        {"chapterNum":"7.4", "chapterName":"精确制导武器的分类（二）"},
                        {"chapterNum":"7.5", "chapterName":"精确制导武器的分类（三）"}
                    ],
                    "高端武器概述":[
                        {"chapterNum":"8.1", "chapterName":"核武器概述"},
                        {"chapterNum":"8.2", "chapterName":"生物武器概述"},
                        {"chapterNum":"8.3", "chapterName":"化学武器概述"}
                    ],
                    "新概念武器":[
                        {"chapterNum":"9.1", "chapterName":"概论"},
                        {"chapterNum":"9.2", "chapterName":"新概念武器的分类（一）"},
                        {"chapterNum":"9.3", "chapterName":"新概念武器的分类（二）"}
                    ]
                }
            ]
        },
        {
            "courseid":"81102330",
            "courseName":"国防军事教育（中国国防）",
            "typeOne":"专题教育",
            "typeTwo":"安全教育",
            "keySpeakName":"艾跃进",
            "keySpeakUnivercity":"南开大学",
            "keySpeakPosition":"教授",
            "keySpeakIntroduce":"曾接受过新华社、央视《新闻联播》、《新闻频道》等媒体的采访，被媒体评为“魅力教授”、“最受欢迎教授”。南开大学教授，全国著名演讲家，口才艺术、社交礼仪专家；领袖学、成功学、军事学专家；国际问题和形势政策专家；中华规范婚礼创始人；著名策划人、主持人，天津市国学研究会副会长，多次接受包括新华社、央视《新闻联播》、《新闻频道》等媒体的采访，担任天津电视台四个栏目的嘉宾，被媒体评为“魅力教授”、“最受欢迎教授”。每年在全国各地的政府机关，企事业单位，北大、清华等著名学府，举办上百场讲座和演讲，现场反响强烈，好评如潮。艾跃进教授每年都要在天津和全国各地的政府机关，事业单位，科研院所，部队（包括军校），农村、知名企业和北大、清华等著名学府，举办上百场讲座和演讲；还给SOS村的孤儿、养老院的职工、监狱的犯人和干警、开发区的农民工讲课，都受到了热烈欢迎。 　　艾跃进教授演讲风格幽默、激情四射，具有极强的感染力与号召力。其中在北京大学举办的《美伊战争后的世界形势》的演讲，现场反响强烈，好评如潮，掌声经久不息，演讲实录被收入《在北大听讲座》一书，《书摘》杂志旋即予以转载。",
            "courseIntroduce":["军事理论课程以国防教育为主线，按照教育要面向现代化、面向世界、面向未来，适应我国人才培养的长远战略目标和加强国防后备力量建设的需要，通过艾跃进教授极具感染力和号召力的讲述，能够使学生掌握基本军事理论与军事技能，增强国防观念和国家安全意识，强化爱国主义、集体主义观念，加强组织纪律性，促进在校学生综合素质的提高，培养作为中国人的危机感与责任感。"],
            "bigImgUrl":"http://p.ananas.chaoxing.com/star3/733_434c/570f028a712e5503e3e2adbb.jpg",
            "videoUrl":"http://s1.ananas.chaoxing.com/video/1b/5577c149e4b0ec35e2d1163b/sd.mp4",
            "courseChapter":[
                {
                    "中国国防":[
                        {"chapterNum":"1.1", "chapterName":"国防概述"},
                        {"chapterNum":"1.2", "chapterName":"中国国防史——先秦到元朝"},
                        {"chapterNum":"1.3", "chapterName":"中国国防史——明清之衰"},
                        {"chapterNum":"1.4", "chapterName":"中国国防史——日、俄之侵"},
                        {"chapterNum":"1.5", "chapterName":"中国现代国防与国防战略"},
                        {"chapterNum":"1.6", "chapterName":"国防立法与各国国防力量"},
                        {"chapterNum":"1.7", "chapterName":"中国武装力量"}
                    ],
                    "军事思想":[
                        {"chapterNum":"2.1", "chapterName":"军事思想概述"},
                        {"chapterNum":"2.2", "chapterName":"中国古代军事思想——先秦到唐五代"},
                        {"chapterNum":"2.3", "chapterName":"中国古代军事思想——宋至清前期"}
                    ],
                    "毛泽东军事思想":[
                        {"chapterNum":"3.1", "chapterName":"毛泽东军事思想的定义和特色"},
                        {"chapterNum":"3.2", "chapterName":"毛泽东军事思想的形成和发展"},
                        {"chapterNum":"3.3", "chapterName":"毛泽东的战争观和方法论"},
                        {"chapterNum":"3.4", "chapterName":"毛泽东军事思想视野下的全球局势"},
                        {"chapterNum":"3.5", "chapterName":"毛泽东人民战争思想"},
                        {"chapterNum":"3.6", "chapterName":"毛泽东人民战争的战略战术"},
                        {"chapterNum":"3.7", "chapterName":"毛泽东人民战争战略战术的正确性"},
                        {"chapterNum":"3.8", "chapterName":"解放战争的战略分析"},
                        {"chapterNum":"3.9", "chapterName":"三大战役及全面解放"},
                        {"chapterNum":"3.10", "chapterName":"国防建设概况"},
                        {"chapterNum":"3.11", "chapterName":"毛泽东的历史地位"},
                        {"chapterNum":"3.12", "chapterName":"毛泽东军事指挥胜利的国际意义"},
                        {"chapterNum":"3.13", "chapterName":"毛泽东军事思想的历史意义"},
                        {"chapterNum":"3.14", "chapterName":"新时期国防与军队建设思想"},
                        {"chapterNum":"3.15", "chapterName":"习近平国防与军队建设思想"}
                    ],
                    "《孙子兵法》导读":[
                        {"chapterNum":"4.1", "chapterName":"《孙子兵法》导读（一）"},
                        {"chapterNum":"4.2", "chapterName":"《孙子兵法》导读（二）"},
                        {"chapterNum":"4.3", "chapterName":"《孙子兵法》导读（三）"},
                        {"chapterNum":"4.4", "chapterName":"《孙子兵法》导读（四）"}
                    ]
                }
            ]
        },
        {
            "courseid":"81094541",
            "courseName":"基础生命科学",
            "typeOne":"大学先修",
            "typeTwo":"",
            "keySpeakName":"张金红",
            "keySpeakUnivercity":"南开大学",
            "keySpeakPosition":"教授",
            "keySpeakIntroduce":"南开大学生命科学学院教授。",
            "courseIntroduce":["生命是很神奇的，生命科学是研究生命现象、生命活动的本质、特征和发生、发展规律，以及各种生物之间和生物与环境之间相互关系的科学。在基础生命科学这一课程里，张金红教授讲述了生命的物质基础、生物的新陈代谢、细胞、从基因到基因工程、遗传病和人类基因组计划、生物体内的信息传递、免疫系统、能够传染致病的蛋白质粒子普列昂、多利羊带来的挑战与困惑、丰富多彩的生物世界、生物与环境、生命起源和生物进化等内容。旨在让学生深入了解基础生命科学，认识到生命的珍贵。"],
            "bigImgUrl":"http://p.ananas.chaoxing.com/star2/2014-06/733_434/1403057263940spnff.jpg",
            "videoUrl":"",
            "courseChapter":[
                {
                    "基础生命科学 绪论":[
                        {"chapterNum":"1.1", "chapterName":"基础生命科学 绪论（上）"},
                        {"chapterNum":"1.2", "chapterName":"基础生命科学 绪论（下）"}
                    ],
                    "生命的物质基础":[
                        {"chapterNum":"2.1", "chapterName":"生命的物质基础（一）"},
                        {"chapterNum":"2.2", "chapterName":"生命的物质基础（二）"},
                        {"chapterNum":"2.3", "chapterName":"生命的物质基础（三）"}
                    ],
                    "生物的新陈代谢":[
                        {"chapterNum":"3.1", "chapterName":"生物的新陈代谢（一）"},
                        {"chapterNum":"3.2", "chapterName":"生物的新陈代谢（二）"},
                        {"chapterNum":"3.3", "chapterName":"生物的新陈代谢（三）"}
                    ],
                    "细胞":[
                        {"chapterNum":"4.1", "chapterName":"细胞（一）"},
                        {"chapterNum":"4.2", "chapterName":"细胞（二）"},
                        {"chapterNum":"4.3", "chapterName":"细胞（三）"},
                        {"chapterNum":"4.4", "chapterName":"胞（四）"}
                    ],
                    "从基因到基因工程":[
                        {"chapterNum":"5.1", "chapterName":"从基因到基因工程（上）"},
                        {"chapterNum":"5.2", "chapterName":"从基因到基因工程（下）"}
                    ],
                    "遗传病和人类基因组计划":[
                        {"chapterNum":"6.1", "chapterName":"遗传病和人类基因组计划（上）"},
                        {"chapterNum":"6.2", "chapterName":"遗传病和人类基因组计划（下）"}
                    ],
                    "多利羊带来的挑战与困惑":[
                        {"chapterNum":"7.1", "chapterName":"多利羊带来的挑战与困惑（上）"},
                        {"chapterNum":"7.2", "chapterName":"多利羊带来的挑战与困惑（下）"}
                    ],
                    "丰富多彩的生物世界":[
                        {"chapterNum":"8.1", "chapterName":"丰富多彩的生物世界（一）"},
                        {"chapterNum":"8.2", "chapterName":"丰富多彩的生物世界（二）"},
                        {"chapterNum":"8.3", "chapterName":"丰富多彩的生物世界（三）"}
                    ],
                    "生物与环境":[
                        {"chapterNum":"9.1", "chapterName":"生物与环境（一）"},
                        {"chapterNum":"9.2", "chapterName":"生物与环境（二）"},
                        {"chapterNum":"9.3", "chapterName":"生物与环境（三）"}
                    ],
                    "生命起源和生物进化":[
                        {"chapterNum":"10.1", "chapterName":"生命起源和生物进化（上）"},
                        {"chapterNum":"10.2", "chapterName":"生命起源和生物进化（下）"}
                    ]
                }
            ]
        },
        {
            "courseid":"81093778",
            "courseName":"马克思主义基本原理",
            "typeOne":"大学先修",
            "typeTwo":"",
            "keySpeakName":"韦正翔",
            "keySpeakUnivercity":"清华大学",
            "keySpeakPosition":"教授",
            "keySpeakIntroduce":"韦正翔：清华大学马克思主义学院教授、博士生导师、共家学派的倡立者。曾接受联合国的联系组织扶轮国际和美国南卡罗来纳大学的邀请，在美国用英文讲授了三年的《中国哲学》，在墨尔本大学应用哲学和公共伦理研究中心做了一年的交换学者，随清华顾秉林校长和袁驷副校长率领的清华大型百年校庆访美团在美国的哈佛大学、斯坦福大学、哥伦比亚大学、芝加哥大学、麻省理工学院、加州伯克利大学、联合国大学做关于“马克思主义与中国传统哲学的现代化”的英文演讲和会谈。主要代表作有：《共产党宣言探究》（对照中、德、英、法、俄文版）、《大众化的马克思主义》等6部独著以及1部独译《金融领域中的伦理冲突》。",
            "courseIntroduce":["马克思主义基本原理是高校思想政治理论课程体系的主干课程，是全国所有高校大学生的公共必修课。该课程涵盖了包括马克思主义哲学、政治经济学和科学社会主义三个主要组成部分在内的全部内容。韦正翔教授以阐释马克思主义世界观、方法论为重点，以人类社会发展的基本规律为主线，全面阐明马克思主义的基本理论、基本立场、基本观点和基本方法，旨在使学生从整体上把握马克思主义，正确认识人类社会发展的基本规律，树立马克思主义的人生观和价值观，培养和提高学生运用马克思主义理论分析和解决实际问题的能力。"],
            "bigImgUrl":"http://p.ananas.chaoxing.com/star2/2014-06/733_434/1403061599085iujgd.jpg",
            "videoUrl":"",
            "courseChapter":[
                {
                    "共产主义是人类最崇高的社会理想":[
                        {"chapterNum":"1.1", "chapterName":"共产主义是人类最崇高的社会理想（一）"},
                        {"chapterNum":"1.2", "chapterName":"共产主义是人类最崇高的社会理想（二）"},
                        {"chapterNum":"1.3", "chapterName":"共产主义是人类最崇高的社会理想（三）"},
                        {"chapterNum":"1.4", "chapterName":"共产主义是人类最崇高的社会理想（四）"},
                        {"chapterNum":"1.5", "chapterName":"共产主义是人类最崇高的社会理想（五）"}
                    ],
                    "马克思主义基本原理绪论":[
                        {"chapterNum":"2.1", "chapterName":"马克思主义基本原理绪论（一）"},
                        {"chapterNum":"2.2", "chapterName":"马克思主义基本原理绪论（二）"},
                        {"chapterNum":"2.3", "chapterName":"马克思主义基本原理绪论（三）"}
                    ],
                    "世界的物质性及其发展规律":[
                        {"chapterNum":"3.1", "chapterName":"世界的物质性及其发展规律"},
                        {"chapterNum":"3.2", "chapterName":"世界的物质性及其发展规律"},
                        {"chapterNum":"3.3", "chapterName":"世界的物质性及其发展规律"},
                        {"chapterNum":"3.4", "chapterName":"世界的物质性及其发展规律"},
                        {"chapterNum":"3.5", "chapterName":"世界的物质性及其发展规律"},
                        {"chapterNum":"3.6", "chapterName":"世界的物质性及其发展规律"},
                        {"chapterNum":"3.7", "chapterName":"世界的物质性及其发展规律"},
                        {"chapterNum":"3.8", "chapterName":"世界的物质性及其发展规律"},
                        {"chapterNum":"3.9", "chapterName":"世界的物质性及其发展规律"},
                        {"chapterNum":"3.10", "chapterName":"世界的物质性及其发展规律"},
                        {"chapterNum":"3.11", "chapterName":"世界的物质性及其发展规律（十一）"}
                    ],
                    "认识的本质及其发展规律":[
                        {"chapterNum":"4.1", "chapterName":"认识的本质及其发展规律（一）"},
                        {"chapterNum":"4.2", "chapterName":"认识的本质及其发展规律（二）"},
                        {"chapterNum":"4.3", "chapterName":"认识的本质及其发展规律（三）"},
                        {"chapterNum":"4.4", "chapterName":"认识的本质及其发展规律（四）"},
                        {"chapterNum":"4.5", "chapterName":"认识的本质及其发展规律（五）"},
                        {"chapterNum":"4.6", "chapterName":"认识的本质及其发展规律（六）"}
                    ],
                    "人类社会及其发展规律":[
                        {"chapterNum":"5.1", "chapterName":"人类社会及其发展规律（一）"},
                        {"chapterNum":"5.2", "chapterName":"人类社会及其发展规律（二）"},
                        {"chapterNum":"5.3", "chapterName":"人类社会及其发展规律（三）"},
                        {"chapterNum":"5.4", "chapterName":"人类社会及其发展规律（四）"},
                        {"chapterNum":"5.5", "chapterName":"人类社会及其发展规律（五）"},
                        {"chapterNum":"5.6", "chapterName":"人类社会及其发展规律（六）"},
                        {"chapterNum":"5.7", "chapterName":"人类社会及其发展规律（七）"},
                        {"chapterNum":"5.8", "chapterName":"人类社会及其发展规律（八）"},
                        {"chapterNum":"5.9", "chapterName":"人类社会及其发展规律（九）"},
                        {"chapterNum":"5.10", "chapterName":"人类社会及其发展规律（十）"}
                    ],
                    "资本主义的形成及其本质":[
                        {"chapterNum":"6.1", "chapterName":"资本主义的形成及其本质（一）"},
                        {"chapterNum":"6.2", "chapterName":"资本主义的形成及其本质（二）"},
                        {"chapterNum":"6.3", "chapterName":"资本主义的形成及其本质（三）"},
                        {"chapterNum":"6.4", "chapterName":"资本主义的形成及其本质（四）"},
                        {"chapterNum":"6.5", "chapterName":"资本主义的形成及其本质（五）"},
                        {"chapterNum":"6.6", "chapterName":"资本主义的形成及其本质（六）"},
                        {"chapterNum":"6.7", "chapterName":"资本主义的形成及其本质（七）"},
                        {"chapterNum":"6.8", "chapterName":"资本主义的形成及其本质（八）"},
                        {"chapterNum":"6.9", "chapterName":"资本主义的形成及其本质（九）"},
                        {"chapterNum":"6.10", "chapterName":"资本主义的形成及其本质（十）"},
                        {"chapterNum":"6.11", "chapterName":"资本主义的形成及其本质（十一）"},
                        {"chapterNum":"6.12", "chapterName":"资本主义的形成及其本质（十二）"}
                    ],
                    "资本主义发展的历史进程":[
                        {"chapterNum":"7.1", "chapterName":"资本主义发展的历史进程（一）"},
                        {"chapterNum":"7.2", "chapterName":"资本主义发展的历史进程（二）"},
                        {"chapterNum":"7.3", "chapterName":"资本主义发展的历史进程（三）"},
                        {"chapterNum":"7.4", "chapterName":"资本主义发展的历史进程（四）"},
                        {"chapterNum":"7.5", "chapterName":"资本主义发展的历史进程（五）"},
                        {"chapterNum":"7.6", "chapterName":"资本主义发展的历史进程（六）"},
                        {"chapterNum":"7.7", "chapterName":"资本主义发展的历史进程（七）"}
                    ],
                    "社会主义社会及其发展":[
                        {"chapterNum":"8.1", "chapterName":"社会主义社会及其发展（一）"},
                        {"chapterNum":"8.2", "chapterName":"社会主义社会及其发展（二）"},
                        {"chapterNum":"8.3", "chapterName":"社会主义社会及其发展（三）"},
                        {"chapterNum":"8.4", "chapterName":"社会主义社会及其发展（四）"},
                        {"chapterNum":"8.5", "chapterName":"社会主义社会及其发展（五）"},
                        {"chapterNum":"8.6", "chapterName":"社会主义社会及其发展（六）"},
                        {"chapterNum":"8.7", "chapterName":"社会主义社会及其发展（七）"}
                    ],
                    "总结":[
                        {"chapterNum":"9.1", "chapterName":"总结"}
                    ]
                }
            ]
        },
        {
            "courseid":"81094585",
            "courseName":"大学物理（一）",
            "typeOne":"大学先修",
            "typeTwo":"",
            "keySpeakName":"董占海",
            "keySpeakUnivercity":"上海交通大学",
            "keySpeakPosition":"教授",
            "keySpeakIntroduce":"董占海，上海交通大学物理系教授。主要从事电子强关联系统物理特性和红外辐射特性仿真等方面的研究。在Phys.Rev.B，JPCM，Solid State Communication等国内外刊物发表论文20余篇；近几年内主持或参与国防预研项目或国防重大项目多项。获奖经历：从事基础物理教学工作，为国家精品课程主讲教师之一。曾获得“美国硅谷校友会”优秀教学奖、“最受学生欢迎的教师”奖、优秀教师奖多次。",
            "courseIntroduce":["大学物理课程是理科和工科本科生必修的公共基础课，是经、管、文等本科生的选修课程 。通过课程的学习，使学生逐步掌握物理学研究问题的思路和方法，在获取知识的同时，使学生拥有的建立物理模型的能力，定性分析、估算与定量计算的能力，以及独立获取知识的能力、理论联系实际的能力都获得同步提高与发展。通过课程的学习，使学生掌握科学的学习方法和形成良好的学习习惯，形成辩证唯物主义的世界观和方法论。"],
            "bigImgUrl":"http://p.ananas.chaoxing.com/star3/733_434c/558a5425e4b0ec35e2d29cb2.jpg",
            "videoUrl":"",
            "courseChapter":[
                {
                    "绪论":[
                        {"chapterNum":"1.1", "chapterName":"走进物理"},
                        {"chapterNum":"1.2", "chapterName":"如何学习物理"}
                    ],
                    "质点运动学":[
                        {"chapterNum":"2.1", "chapterName":"质点的位矢"},
                        {"chapterNum":"2.2", "chapterName":"质点的运动方程和轨道方程"},
                        {"chapterNum":"2.3", "chapterName":"位移"},
                        {"chapterNum":"2.4", "chapterName":"速度"},
                        {"chapterNum":"2.5", "chapterName":"加速度"},
                        {"chapterNum":"2.6", "chapterName":"运动学中的两类问题"}
                    ],
                    "质点动力学":[
                        {"chapterNum":"3.1", "chapterName":"四种基本作用力"},
                        {"chapterNum":"3.2", "chapterName":"牛顿运动定律"},
                        {"chapterNum":"3.3", "chapterName":"常见的作用力"},
                        {"chapterNum":"3.4", "chapterName":"牛顿定律的应用"},
                        {"chapterNum":"3.5", "chapterName":"伽利略相对性原理"},
                        {"chapterNum":"3.6", "chapterName":"惯性力"},
                        {"chapterNum":"3.7", "chapterName":"狭义相对论"}
                    ],
                    "运动定理":[
                        {"chapterNum":"4.1", "chapterName":"冲量与动量"},
                        {"chapterNum":"4.2", "chapterName":"功与能"},
                        {"chapterNum":"4.3", "chapterName":"相对论"},
                        {"chapterNum":"4.4", "chapterName":"冲量矩与角动量"},
                        {"chapterNum":"4.5", "chapterName":"对称性"}
                    ],
                    "刚体力学":[
                        {"chapterNum":"5.1", "chapterName":"刚体的基本运动"},
                        {"chapterNum":"5.2", "chapterName":"刚体定轴转动的描述"},
                        {"chapterNum":"5.3", "chapterName":"刚体的角动量"},
                        {"chapterNum":"5.4", "chapterName":"刚体的动能"},
                        {"chapterNum":"5.5", "chapterName":"刚体定点转动"},
                        {"chapterNum":"5.6", "chapterName":"进动"},
                        {"chapterNum":"5.7", "chapterName":"刚体平面平行运动"}
                    ],
                    "热力学平衡态":[
                        {"chapterNum":"6.1", "chapterName":"热力学系统及研究方法"},
                        {"chapterNum":"6.2", "chapterName":"平衡态"},
                        {"chapterNum":"6.3", "chapterName":"热力学第零定律和状态参量"},
                        {"chapterNum":"6.4", "chapterName":"温度和温标"},
                        {"chapterNum":"6.5", "chapterName":"理想气体状态方程"},
                        {"chapterNum":"6.6", "chapterName":"理想气体压强和温度"},
                        {"chapterNum":"6.7", "chapterName":"分子热运动的速度和速率统计分布规律"},
                        {"chapterNum":"6.8", "chapterName":"涨落现象"}
                    ],
                    "热力学":[
                        {"chapterNum":"7.1", "chapterName":"准静态过程"},
                        {"chapterNum":"7.2", "chapterName":"内能、功、热和热力学第一定律"},
                        {"chapterNum":"7.3", "chapterName":"热容"},
                        {"chapterNum":"7.4", "chapterName":"循环过程"},
                        {"chapterNum":"7.5", "chapterName":"热力学第二定律"},
                        {"chapterNum":"7.6", "chapterName":"熵"},
                        {"chapterNum":"7.7", "chapterName":"熵的统计学意义"}
                    ],
                    "静电场":[
                        {"chapterNum":"8.1", "chapterName":"电荷"},
                        {"chapterNum":"8.2", "chapterName":"库仑定律"},
                        {"chapterNum":"8.3", "chapterName":"电场"},
                        {"chapterNum":"8.4", "chapterName":"高斯定理"},
                        {"chapterNum":"8.5", "chapterName":"环路定理"},
                        {"chapterNum":"8.6", "chapterName":"电势"}
                    ],
                    "导体电学":[
                        {"chapterNum":"9.1", "chapterName":"导体经典平衡性质"},
                        {"chapterNum":"9.2", "chapterName":"电容及电容器"},
                        {"chapterNum":"9.3", "chapterName":"电流"},
                        {"chapterNum":"9.4", "chapterName":"稳恒电场"},
                        {"chapterNum":"9.5", "chapterName":"电源"}
                    ],
                    "电介质":[
                        {"chapterNum":"10.1", "chapterName":"电介质及其极化"},
                        {"chapterNum":"10.2", "chapterName":"极化强度"},
                        {"chapterNum":"10.3", "chapterName":"介质中的高斯定理"},
                        {"chapterNum":"10.4", "chapterName":"介质边界两侧的静电场"},
                        {"chapterNum":"10.5", "chapterName":"静电场的能量"}
                    ]
                }
            ]
        },
        {
            "courseid":"81094977",
            "courseName":"高等数学（上）",
            "typeOne":"大学先修",
            "typeTwo":"",
            "keySpeakName":"李换琴",
            "keySpeakUnivercity":"西安交通大学",
            "keySpeakPosition":"教授",
            "keySpeakIntroduce":"研究领域：智能优化方法理论与应用研究（包括遗传算法、粒子群算法、蚁群算法等），数据挖掘的理论、算法及应用，神经网络在复杂系统建模中的应用，计算生物学等。论文与著作：参与编著著作：《MATLAB软件与基础数学实验》，西安交通大学出版社《工科数学分析基础释疑解难》，高等教育出版社《工科数学分析网络教材》，高等教育出版社《工程优化方法及其应用》，西按交通大学出版社荣誉与奖励1996年获“西安交通大学理学院首届青年教师授课竞赛”一等奖1997年获“陕西省高等院校第二次青年教师讲课比赛”三等奖2000年获“西安交通大学青年教师讲课比赛”一等奖2003年获“系统工程研究所胡氏奖学奖教金”二等奖",
            "courseIntroduce":["高等数学是高等院校理工科各专业必修的一门很重要的公共基础课，以微积分为主要内容，广泛应用于自然科学、社会科学、经济管理、工程技术等各个领域，以培养学生的抽象思维能力、逻辑推理能力、空间想象能力、实验及观察能力以及综合运用所学知识分析问题解决问题的能力为重心，是开展数学素质教育、培养学习者创新精神和创新能力的重要课程。本课程是高等数学的典型课程之一，由西安交通大学应用数学教授李换琴老师讲授，分为（上）、（下）两个部分，主要包括一元函数微积分及其应用、无穷级数、多元函数微积分及其应用、常微分方程等内容，系统全面，逻辑清晰，数学语言严谨，对于巩固学生基础课程的学习，完善学生的数学思维，提高学生的专业知识理解能力都大有裨益。"],
            "bigImgUrl":"http://p.ananas.chaoxing.com/star3/733_434c/550698ca537016c9ba1e1fdf.jpg",
            "videoUrl":"",
            "courseChapter":[
                {
                    "绪论":[
                        {"chapterNum":"1.1", "chapterName":"高等数学学习谈"},
                        {"chapterNum":"1.2", "chapterName":"微积分的基本思想和方法"}
                    ],
                    "函数、极限、连续":[
                        {"chapterNum":"2.1", "chapterName":"集合、映射与函数"},
                        {"chapterNum":"2.2", "chapterName":"数列的极限"},
                        {"chapterNum":"2.3", "chapterName":"函数的极限"},
                        {"chapterNum":"2.4", "chapterName":"无穷小量与无穷大量"},
                        {"chapterNum":"2.5", "chapterName":"连续函数"},
                        {"chapterNum":"2.6", "chapterName":"综合题选讲"}
                    ],
                    "一元函数微分学及其应用":[
                        {"chapterNum":"3.1", "chapterName":"导数的概念"},
                        {"chapterNum":"3.2", "chapterName":"求导的基本法则"},
                        {"chapterNum":"3.3", "chapterName":"微分"},
                        {"chapterNum":"3.4", "chapterName":"微分中值定理及其应用"},
                        {"chapterNum":"3.5", "chapterName":"Faylor定理及其应用"},
                        {"chapterNum":"3.6", "chapterName":"函数性态的研究"}
                    ],
                    "一元函数积分学及其应用":[
                        {"chapterNum":"4.1", "chapterName":"定积分的概念、存在条件与性质"},
                        {"chapterNum":"4.2", "chapterName":"微积分基本公式与基本定理"},
                        {"chapterNum":"4.3", "chapterName":"两种基本积分法"},
                        {"chapterNum":"4.4", "chapterName":"定积分的应用"},
                        {"chapterNum":"4.5", "chapterName":"反常积分"},
                        {"chapterNum":"4.6", "chapterName":"几类简单的微分方程"}
                    ],
                    "无穷级数":[
                        {"chapterNum":"5.1", "chapterName":"常数项级数"},
                        {"chapterNum":"5.2", "chapterName":"函数项级数"},
                        {"chapterNum":"5.3", "chapterName":"幂级数"},
                        {"chapterNum":"5.4", "chapterName":"Fourier级数"}
                    ]
                }
            ]
        },
        {
            "courseid":"81095211",
            "courseName":"广播电视概论",
            "typeOne":"大学先修",
            "typeTwo":"",
            "keySpeakName":"易前良",
            "keySpeakUnivercity":"河海大学公共管理学院",
            "keySpeakPosition":"副教授",
            "keySpeakIntroduce":"男，湖南双峰人，南京大学文学博士，美国加州大学圣地亚哥分校访问学者；现为河海大学公共管理学院传播学系副教授，硕士生导师，兼任江苏传媒艺术协会秘书长、苏州大学“新媒体与青年文化研究中心”研究员；研究专长为“广播电视研究”、“新闻社会学研究”、“媒介文化研究”。出版过《美国“电视研究”的学术源流》（2010，中国传媒大学出版社）、《御宅：二次元世界的迷狂》（2012，苏州大学出版社）等论著；代表性论文有《西方电视文化研究的三种范式》（《现代传播》）、《从语态改变到意见表达：中国电视新闻的三个节点》（《国际新闻界》）、《青年御宅族的媒介认知研究》（《新闻与传播研究》）、《乡村集体行动中的信息传播研究：以小陶村为例》（《国际新闻界》）、《透析电视讲坛现象》（《中国电视》）等。",
            "courseIntroduce":["随着经济社会的不断发展，传媒业也以飞速惊人的速度在发展着，要想在飞速的传媒“横流”中站稳脚跟，抓住最准确的消息，必须了解传媒发展的历史和现状。在易前良副教授的《广播电视概论》课程中，老师清晰准确地向我们介绍了媒介类型、传播媒介的特点和划分概况，并且结合社会发展带领我们去认识媒介的进化。在课程中后期，主要侧重于中国广播电视的发展概况。","教师团队"],
            "bigImgUrl":"http://p.ananas.chaoxing.com/star3/733_434c/54129e9e53703d8b3b563cc1.png",
            "videoUrl":"",
            "courseChapter":[
                {
                    "认识媒介":[
                        {"chapterNum":"1.1", "chapterName":"认识媒介（一）"},
                        {"chapterNum":"1.2", "chapterName":"认识媒介（二）"},
                        {"chapterNum":"1.3", "chapterName":"认识媒介（三）"}
                    ],
                    "广播电视的诞生与发展":[
                        {"chapterNum":"2.1", "chapterName":"广播电视的诞生与发展（一）"},
                        {"chapterNum":"2.2", "chapterName":"广播电视的诞生与发展（二）"},
                        {"chapterNum":"2.3", "chapterName":"广播电视的诞生与发展（三）"},
                        {"chapterNum":"2.4", "chapterName":"广播电视的诞生与发展（四）"},
                        {"chapterNum":"2.5", "chapterName":"广播电视的诞生与发展（五）"},
                        {"chapterNum":"2.6", "chapterName":"广播电视的诞生与发展（六）"},
                        {"chapterNum":"2.7", "chapterName":"广播电视的诞生与发展（七）"}
                    ],
                    "中国广播电视的发展与变迁":[
                        {"chapterNum":"3.1", "chapterName":"中国广播电视的发展与变迁（一）"},
                        {"chapterNum":"3.2", "chapterName":"中国广播电视的发展与变迁（二）"},
                        {"chapterNum":"3.3", "chapterName":"中国广播电视的发展与变迁（三）"}
                    ],
                    "广播电视产业概要":[
                        {"chapterNum":"4.1", "chapterName":"广播电视产业概要（一）"},
                        {"chapterNum":"4.2", "chapterName":"广播电视产业概要（二）"},
                        {"chapterNum":"4.3", "chapterName":"广播电视产业概要（三）"}
                    ],
                    "省级卫视的市场竞争":[
                        {"chapterNum":"5.1", "chapterName":"省级卫视的市场竞争（一）"},
                        {"chapterNum":"5.2", "chapterName":"省级卫视的市场竞争（二）"}
                    ],
                    "电视节目":[
                        {"chapterNum":"6.1", "chapterName":"电视节目（一）"},
                        {"chapterNum":"6.2", "chapterName":"电视节目（二）"},
                        {"chapterNum":"6.3", "chapterName":"电视节目（三）"},
                        {"chapterNum":"6.4", "chapterName":"电视节目（四）"},
                        {"chapterNum":"6.5", "chapterName":"电视节目（五）"},
                        {"chapterNum":"6.6", "chapterName":"电视节目（六）"}
                    ],
                    "新闻节目的诞生与发展":[
                        {"chapterNum":"7.1", "chapterName":"新闻节目的诞生与发展（一）"},
                        {"chapterNum":"7.2", "chapterName":"新闻节目的诞生与发展（二）"},
                        {"chapterNum":"7.3", "chapterName":"新闻节目的诞生与发展（三）"}
                    ],
                    "电视新闻节目类型":[
                        {"chapterNum":"8.1", "chapterName":"电视新闻节目类型（一）"},
                        {"chapterNum":"8.2", "chapterName":"电视新闻节目类型（二）"},
                        {"chapterNum":"8.3", "chapterName":"电视新闻节目类型（三）"},
                        {"chapterNum":"8.4", "chapterName":"电视新闻节目类型（四）"}
                    ],
                    "电视娱乐节目":[
                        {"chapterNum":"9.1", "chapterName":"电视娱乐节目（一）"},
                        {"chapterNum":"9.2", "chapterName":"电视娱乐节目（二）"},
                        {"chapterNum":"9.3", "chapterName":"电视娱乐节目（三）"},
                        {"chapterNum":"9.4", "chapterName":"电视娱乐节目（四）"}
                    ],
                    "真人秀":[
                        {"chapterNum":"10.1", "chapterName":"真人秀（一）"},
                        {"chapterNum":"10.2", "chapterName":"真人秀（二）"}
                    ],
                    "电视纪录片":[
                        {"chapterNum":"11.1", "chapterName":"电视纪录片（一）"},
                        {"chapterNum":"11.2", "chapterName":"电视纪录片（二）"},
                        {"chapterNum":"11.3", "chapterName":"电视纪录片（三）"},
                        {"chapterNum":"11.4", "chapterName":"电视纪录片（四）"}
                    ],
                    "电视发展新趋势":[
                        {"chapterNum":"12.1", "chapterName":"电视发展新趋势（一）"},
                        {"chapterNum":"12.2", "chapterName":"电视发展新趋势（二）"},
                        {"chapterNum":"12.3", "chapterName":"电视发展新趋势（三）"},
                        {"chapterNum":"12.4", "chapterName":"电视发展新趋势（四）"}
                    ]
                }
            ]
        },
        {
            "courseid":"81094496",
            "courseName":"航空与航天",
            "typeOne":"大学先修",
            "typeTwo":"",
            "keySpeakName":"艾剑良",
            "keySpeakUnivercity":"复旦大学",
            "keySpeakPosition":"教授",
            "keySpeakIntroduce":"个人荣誉：1.美国联合技术公司（UTC）容闳科技教育奖（1999年） 2．2002-2003年度西北工业大学优秀奖教金 3．西北工业大学1995年度、2000年度校优秀青年教师 4．2002-2003年西北工业大学“十五建功立业”杰出青年教师  论文与著作：1．《现代飞机总体综合设计》，西北工业大学出版社，2001年（第四作者） 2．《现代飞机结构综合设计》，西北工业大学出版社，2001年（第三作者） 3.《飞机原理与构造》，西北工业大学出版社，2002年第三作者） 4.《现代飞行器总体综合设计》，西北工业大学出版社，2004 年（第四作者）",
            "courseIntroduce":["航空航天事业的发展是20世纪科学技术飞跃进步，社会生产突飞猛进的结果。航空航天的成果集中了科学技术的众多新成就，是一个国家尖端技术发展的引擎。迄今为止的航空航天活动，虽然还只是人类离开地球这个摇篮的最初几步，但它的作用已远远超出科学技术领域，对政治、经济、军事以至人类社会生活都产生了广泛而深远的影响。迄今，中国在航天技术的一些重要领域已跻身世界先进行列，取得了举世瞩目的成就。本课从航空航天概论、飞机的构造、飞机飞行的原理、直升机、无人机、航天飞行器、飞机动力装置等内容来讲述，通过这些内容的学习，让学生对飞机这一复杂的工程系统及其设计过程有一个基本而全面的了解。"],
            "bigImgUrl":"http://p.ananas.chaoxing.com/star3/733_434c/546beff6a3107a6fe3640c1f.jpg",
            "videoUrl":"",
            "courseChapter":[
                {
                    "航空航天概论":[
                        {"chapterNum":"1.1", "chapterName":"航空航天概论（一）"},
                        {"chapterNum":"1.2", "chapterName":"航空航天概论（二）"},
                        {"chapterNum":"1.3", "chapterName":"航空航天概论（三）"},
                        {"chapterNum":"1.4", "chapterName":"航空航天概论（四）"},
                        {"chapterNum":"1.5", "chapterName":"航空航天概论（五）"},
                        {"chapterNum":"1.6", "chapterName":"航空航天概论（六）"},
                        {"chapterNum":"1.7", "chapterName":"航空航天概论（七）"}
                    ],
                    "飞行器的分类":[
                        {"chapterNum":"2.1", "chapterName":"飞行器的分类（一）"},
                        {"chapterNum":"2.2", "chapterName":"飞行器的分类（二）"},
                        {"chapterNum":"2.3", "chapterName":"飞行器的分类（三）"},
                        {"chapterNum":"2.4", "chapterName":"飞行器的分类（四）"}
                    ],
                    "飞机飞行的基本原理":[
                        {"chapterNum":"3.1", "chapterName":"飞机飞行的基本原理（一）"},
                        {"chapterNum":"3.2", "chapterName":"飞机飞行的基本原理（二）"},
                        {"chapterNum":"3.3", "chapterName":"飞机飞行的基本原理（三）"},
                        {"chapterNum":"3.4", "chapterName":"飞机飞行的基本原理（四）"}
                    ],
                    "飞机的稳定和操纵":[
                        {"chapterNum":"4.1", "chapterName":"飞机的稳定和操纵（一）"},
                        {"chapterNum":"4.2", "chapterName":"飞机的稳定和操纵（二）"},
                        {"chapterNum":"4.3", "chapterName":"飞机的稳定和操纵（三）"}
                    ],
                    "飞机的构造":[
                        {"chapterNum":"5.1", "chapterName":"飞机的构造（一）"},
                        {"chapterNum":"5.2", "chapterName":"飞机的构造（二）"},
                        {"chapterNum":"5.3", "chapterName":"飞机的构造（三）"},
                        {"chapterNum":"5.4", "chapterName":"飞机的构造（四）"}
                    ],
                    "直升机":[
                        {"chapterNum":"6.1", "chapterName":"直升机（一）"},
                        {"chapterNum":"6.2", "chapterName":"直升机（二）"},
                        {"chapterNum":"6.3", "chapterName":"直升机（三）"}
                    ],
                    "无人机":[
                        {"chapterNum":"7.1", "chapterName":"无人机（一）"},
                        {"chapterNum":"7.2", "chapterName":"无人机（二）"},
                        {"chapterNum":"7.3", "chapterName":"无人机（三）"},
                        {"chapterNum":"7.4", "chapterName":"无人机（四）"}
                    ],
                    "航天飞行器":[
                        {"chapterNum":"8.1", "chapterName":"航天飞行器（一）"},
                        {"chapterNum":"8.2", "chapterName":"航天飞行器（二）"},
                        {"chapterNum":"8.3", "chapterName":"航天飞行器（三）"},
                        {"chapterNum":"8.4", "chapterName":"航天飞行器（四）"}
                    ],
                    "飞行动力装置":[
                        {"chapterNum":"9.1", "chapterName":"飞行动力装置（一）"},
                        {"chapterNum":"9.2", "chapterName":"飞行动力装置（二）"}
                    ]
                }
            ]
        },
        {
            "courseid":"80075066",
            "courseName":"现代自然地理学",
            "typeOne":"大学先修",
            "typeTwo":"",
            "keySpeakName":"王建",
            "keySpeakUnivercity":"南京师范大学",
            "keySpeakPosition":"教授",
            "keySpeakIntroduce":"王建：现为南京师范大学教授，博士生导师，副校长。专业领域：自然地理学，地貌学，第四纪地质学。代表性成果：《现代自然地理学》、《现代自然地理学实习教程》等。",
            "courseIntroduce":["《现代自然地理学》以全新的体系和结构阐述地球表层系统,环绕地球的大气圈、岩石圈、水圈、生物圈各自的组成、结构、运动、特征,以及各圈层之间的相互关系和相互作用,人与环境的关系等，在讲解理论的同时，本课程还涉及到自然地理学的应用知识，可谓理论与实践结合。"],
            "bigImgUrl":"http://p.ananas.chaoxing.com/star2/2014-06/733_434/1403548877299yzqvr.jpg",
            "videoUrl":"",
            "courseChapter":[
                {
                    "现代自然地理学绪论":[
                        {"chapterNum":"1.1", "chapterName":"现代自然地理学绪论"}
                    ],
                    "自然地理学与地球表层系统":[
                        {"chapterNum":"2.1", "chapterName":"自然地理学与人类环境"},
                        {"chapterNum":"2.2", "chapterName":"地外系统对地表环境的影响"},
                        {"chapterNum":"2.3", "chapterName":"地内系统对地表环境的影响"},
                        {"chapterNum":"2.4", "chapterName":"地球表层系统的结构、特征及功能"},
                        {"chapterNum":"2.5", "chapterName":"人类与地表环境"}
                    ],
                    "岩石圈":[
                        {"chapterNum":"3.1", "chapterName":"岩石圈的组成"},
                        {"chapterNum":"3.2", "chapterName":"岩石圈的结构和运动类型"},
                        {"chapterNum":"3.3", "chapterName":"板块构造和岩石圈的运动机制"},
                        {"chapterNum":"3.4", "chapterName":"固体地球表面的结构与轮廓"}
                    ],
                    "大气圈":[
                        {"chapterNum":"4.1", "chapterName":"大气圈的组成、结构"},
                        {"chapterNum":"4.2", "chapterName":"大气圈的运动"},
                        {"chapterNum":"4.3", "chapterName":"大气圈的物质输移、能量传送"},
                        {"chapterNum":"4.4", "chapterName":"气候分异规律、大气圈与人类"}
                    ],
                    "水圈":[
                        {"chapterNum":"5.1", "chapterName":"海洋水、陆地水、河水"},
                        {"chapterNum":"5.2", "chapterName":"湖泊、沼泽、冰川"},
                        {"chapterNum":"5.3", "chapterName":"水圈的结构、演化与水的运动"},
                        {"chapterNum":"5.4", "chapterName":"水量平衡、水圈与人类"}
                    ],
                    "生物圈":[
                        {"chapterNum":"6.1", "chapterName":"生物圈的组成、结构与地狱分异"},
                        {"chapterNum":"6.2", "chapterName":"生物圈的形成与演化"},
                        {"chapterNum":"6.3", "chapterName":"人与生物圈"}
                    ],
                    "圈层间的相互作用":[
                        {"chapterNum":"7.1", "chapterName":"大气圈与岩石圈的相互作用"},
                        {"chapterNum":"7.2", "chapterName":"地貌与气候的关系"}
                    ],
                    "水圈与岩石圈的相互作用":[
                        {"chapterNum":"8.1", "chapterName":"岩石与水"},
                        {"chapterNum":"8.2", "chapterName":"构造－侵蚀－地貌循环"},
                        {"chapterNum":"8.3", "chapterName":"沟谷流水作用与地貌"},
                        {"chapterNum":"8.4", "chapterName":"海岸发育与海岸地貌"},
                        {"chapterNum":"8.5", "chapterName":"海陆相互作用与河口、三角洲"}
                    ],
                    "水圈与大气圈的相互作用":[
                        {"chapterNum":"9.1", "chapterName":"水汽与天气"},
                        {"chapterNum":"9.2", "chapterName":"水与气候、大气与水体的运动"},
                        {"chapterNum":"9.3", "chapterName":"厄尔尼诺、风暴潮"}
                    ],
                    "生物圈与水圈、大气圈、岩石圈的相互作用":[
                        {"chapterNum":"10.1", "chapterName":"生物圈与岩石、大气圈的相互作用"},
                        {"chapterNum":"10.2", "chapterName":"生物圈与水圈的相互作用"},
                        {"chapterNum":"10.3", "chapterName":"水圈、大气圈、生物圈的相互作用"}
                    ],
                    "自然地理学的应用——方法原理与实例":[
                        {"chapterNum":"11.1", "chapterName":"地表环境评估与区划"},
                        {"chapterNum":"11.2", "chapterName":"地貌地质、水资源的评价"},
                        {"chapterNum":"11.3", "chapterName":"土地分类、分级与评估"}
                    ]
                }
            ]
        },
        {
            "courseid":"81094450",
            "courseName":"美学原理",
            "typeOne":"大学先修",
            "typeTwo":"",
            "keySpeakName":"叶朗",
            "keySpeakUnivercity":"北京大学",
            "keySpeakPosition":"教授",
            "keySpeakIntroduce":"北京大学教授，博导。现仍兼任艺术学系主任。同时兼任国务院学位委员会哲学学科评议组成员，教育部高等学校哲学学科教学指导委员会主任委员，中华美学学会副会长兼高校美学研究会会长，北京市哲学会会长。研究领域：美学原理、中国美学史。专著：《中国小说美学》、《中国美学史大纲》等。",
            "courseIntroduce":["美学是哲学主要分支学科之一，主要研究美、艺术和审美经验。《美学原理》作为一门概论性的美学课程，将集中讲解中外美学史上关于美、艺术和审美经验的代表性理论，介绍一些新兴的理论趋势，结合当前审美和艺术现状，提出一些具有时代特色的美学问题进行讨论。比如，大审美与文化产业的问题、现代艺术的美学理解问题、美和美感的社会性问题、自然审美、艺术审美和社会美学问题、审美与人生的关系问题等。这些新的问题的引进，旨在将抽象的美学理论同具体的审美实际联系起来，提高学生运用理论解决实际问题的兴趣。"],
            "bigImgUrl":"http://p.ananas.chaoxing.com/star2/2014-06/733_434/1403007484652isxes.jpg",
            "videoUrl":"",
            "courseChapter":[
                {
                    "什么是美学":[
                        {"chapterNum":"1.1", "chapterName":"美学历史及20世纪中国美学概况"},
                        {"chapterNum":"1.2", "chapterName":"美学研究的对象及学科性质"},
                        {"chapterNum":"1.3", "chapterName":"为什么与如何学习美学"}
                    ],
                    "“美”是什么":[
                        {"chapterNum":"2.1", "chapterName":"关于美的本质的讨论"},
                        {"chapterNum":"2.2", "chapterName":"美的本质的定义"},
                        {"chapterNum":"2.3", "chapterName":"审美意象与审美活动"},
                        {"chapterNum":"2.4", "chapterName":"意象世界照亮一个真实世界"}
                    ],
                    "美感的分析":[
                        {"chapterNum":"3.1", "chapterName":"美感是体验而非认识"},
                        {"chapterNum":"3.2", "chapterName":"审美态度"},
                        {"chapterNum":"3.3", "chapterName":"美感、快感、高峰体验"}
                    ],
                    "美和美感的社会性":[
                        {"chapterNum":"4.1", "chapterName":"自然、社会对审美活动的影响"},
                        {"chapterNum":"4.2", "chapterName":"审美趣味和审美格调"},
                        {"chapterNum":"4.3", "chapterName":"审美风尚和时代风貌"}
                    ],
                    "自然美":[
                        {"chapterNum":"5.1", "chapterName":"自然美的性质"},
                        {"chapterNum":"5.2", "chapterName":"自然美和传统文化中的生态意识"}
                    ],
                    "社会美":[
                        {"chapterNum":"6.1", "chapterName":"人物美"},
                        {"chapterNum":"6.2", "chapterName":"日常生活的美"},
                        {"chapterNum":"6.3", "chapterName":"民俗、节庆、休闲文化中的美"}
                    ],
                    "艺术美":[
                        {"chapterNum":"7.1", "chapterName":"艺术是什么"},
                        {"chapterNum":"7.2", "chapterName":"艺术和非艺术的区分"},
                        {"chapterNum":"7.3", "chapterName":"艺术创造与艺术作品"},
                        {"chapterNum":"7.4", "chapterName":"什么是意境"}
                    ],
                    "大审美经济与文化产业":[
                        {"chapterNum":"8.1", "chapterName":"理解文化产业"}
                    ],
                    "《红楼梦》的意蕴":[
                        {"chapterNum":"9.1", "chapterName":"红学、红学家"},
                        {"chapterNum":"9.2", "chapterName":"《红楼梦》的意蕴"},
                        {"chapterNum":"9.3", "chapterName":"对改编古典文学作品的评析"}
                    ],
                    "审美范畴":[
                        {"chapterNum":"10.1", "chapterName":"审美范畴与审美形态"},
                        {"chapterNum":"10.2", "chapterName":"悲剧、优美和崇高"}
                    ],
                    "美育":[
                        {"chapterNum":"11.1", "chapterName":"美育的人文内涵及功能"},
                        {"chapterNum":"11.2", "chapterName":"美育在教育体系中的地位和作用"},
                        {"chapterNum":"11.3", "chapterName":"美育的广泛性"}
                    ],
                    "人生境界":[
                        {"chapterNum":"12.1", "chapterName":"人生境界与品位"},
                        {"chapterNum":"12.2", "chapterName":"人生境界与审美的人生"}
                    ]
                }
            ]
        },
        {
            "courseid":"81093589",
            "courseName":"毛泽东思想和中国特色社会主义理论体系概论",
            "typeOne":"大学先修",
            "typeTwo":"",
            "keySpeakName":"彭付芝",
            "keySpeakUnivercity":"北京航空航天大学",
            "keySpeakPosition":"副教授",
            "keySpeakIntroduce":"北航思想政治理论学院当代中国马克思主义教研部主任、国情与马克思主义中国化研究中心主任；是北京市精品课“毛泽东思想和中国特色社会主义理论体系概论”和学校精品课“中国历史与传统文化”的具体负责人。参与或主持省部级等各级课题近20项，独立或与人合作出版学术专著、教材20多部，发表教学科研论文近50篇。",
            "courseIntroduce":["“毛泽东思想和中国特色社会主义理论体系概论”是高等学校思想政治理论课核心课程，该课程以中国化马克思主义为主题，以马克思主义中国化为主线，以中国特色社会主义为重点，结合中国共产党将马克思主义与中国实际相结合的历史进程，讲清马克思主义中国化的两大理论成果，尤其是中国特色社会主义理论体系的最新成果。引导大学生全面了解国情，正确认识马克思主义中国化的理论成果和最新成果在指导中国革命、建设和改革中的重要历史地位和作用，掌握中国化马克思主义的基本理论和精神实质；引导他们确立科学社会主义信仰和建设中国特色社会主义的共同理想；提高政治理论素养，坚定建设中国特色社会主义的理想和信念，增强投身中国特色社会主义建设的坚定性，增强执行党的基本路线和基本纲领的自觉性，为全面建设小康社会和实现社会主义现代化做出自己应有的贡献。"],
            "bigImgUrl":"http://p.ananas.chaoxing.com/star3/733_434c/541a44bda3106c27b61b0048.jpg",
            "videoUrl":"",
            "courseChapter":[
                {
                    "马克思主义中国化两大理论成果":[
                        {"chapterNum":"1.1", "chapterName":"马克思主义中国化两大理论成果（一）"},
                        {"chapterNum":"1.2", "chapterName":"马克思主义中国化两大理论成果（二）"},
                        {"chapterNum":"1.3", "chapterName":"马克思主义中国化两大理论成果（三）"},
                        {"chapterNum":"1.4", "chapterName":"马克思主义中国化两大理论成果（四）"},
                        {"chapterNum":"1.5", "chapterName":"马克思主义中国化两大理论成果（五）"},
                        {"chapterNum":"1.6", "chapterName":"马克思主义中国化两大理论成果（六）"},
                        {"chapterNum":"1.7", "chapterName":"马克思主义中国化两大理论成果（七）"},
                        {"chapterNum":"1.8", "chapterName":"马克思主义中国化两大理论成果（八）"},
                        {"chapterNum":"1.9", "chapterName":"马克思主义中国化两大理论成果（九）"},
                        {"chapterNum":"1.10", "chapterName":"马克思主义中国化两大理论成果（十）"}
                    ],
                    "新民主主义革命理论":[
                        {"chapterNum":"2.1", "chapterName":"新民主主义革命理论（一）"},
                        {"chapterNum":"2.2", "chapterName":"新民主主义革命理论（二）"},
                        {"chapterNum":"2.3", "chapterName":"新民主主义革命理论（三）"},
                        {"chapterNum":"2.4", "chapterName":"新民主主义革命理论（四）"},
                        {"chapterNum":"2.5", "chapterName":"新民主主义革命理论（五）"},
                        {"chapterNum":"2.6", "chapterName":"新民主主义革命理论（六）"},
                        {"chapterNum":"2.7", "chapterName":"新民主主义革命理论（七）"}
                    ],
                    "社会主义改造理论":[
                        {"chapterNum":"3.1", "chapterName":"社会主义改造理论（一）"},
                        {"chapterNum":"3.2", "chapterName":"社会主义改造理论（二）"},
                        {"chapterNum":"3.3", "chapterName":"社会主义改造理论（三）"},
                        {"chapterNum":"3.4", "chapterName":"社会主义改造理论（四）"}
                    ],
                    "社会主义建设道路初步探索的理论成果":[
                        {"chapterNum":"4.1", "chapterName":"社会主义建设道路初步探索的理论成果（一）"},
                        {"chapterNum":"4.2", "chapterName":"社会主义建设道路初步探索的理论成果（二）"},
                        {"chapterNum":"4.3", "chapterName":"社会主义建设道路初步探索的理论成果（三）"},
                        {"chapterNum":"4.4", "chapterName":"社会主义建设道路初步探索的理论成果（四）"},
                        {"chapterNum":"4.5", "chapterName":"社会主义建设道路初步探索的理论成果（五）"}
                    ],
                    "建设中国特色社会主义总依据":[
                        {"chapterNum":"5.1", "chapterName":"建设中国特色社会主义总依据（一）"},
                        {"chapterNum":"5.2", "chapterName":"建设中国特色社会主义总依据（二）"},
                        {"chapterNum":"5.3", "chapterName":"建设中国特色社会主义总依据（三）"},
                        {"chapterNum":"5.4", "chapterName":"建设中国特色社会主义总依据（四）"}
                    ],
                    "社会主义本质和建设中国特色社会主义总任务":[
                        {"chapterNum":"6.1", "chapterName":"社会主义本质和建设中国特色社会主义总任务（一）"},
                        {"chapterNum":"6.2", "chapterName":"社会主义本质和建设中国特色社会主义总任务（二）"},
                        {"chapterNum":"6.3", "chapterName":"社会主义本质和建设中国特色社会主义总任务（三）"},
                        {"chapterNum":"6.4", "chapterName":"社会主义本质和建设中国特色社会主义总任务（四）"},
                        {"chapterNum":"6.5", "chapterName":"社会主义本质和建设中国特色社会主义总任务（五）"},
                        {"chapterNum":"6.6", "chapterName":"社会主义本质和建设中国特色社会主义总任务（六）"},
                        {"chapterNum":"6.7", "chapterName":"社会主义本质和建设中国特色社会主义总任务（七）"},
                        {"chapterNum":"6.8", "chapterName":"社会主义本质和建设中国特色社会主义总任务（八）"},
                        {"chapterNum":"6.9", "chapterName":"社会主义本质和建设中国特色社会主义总任务（九）"},
                        {"chapterNum":"6.10", "chapterName":"社会主义本质和建设中国特色社会主义总任务（十）"},
                        {"chapterNum":"6.11", "chapterName":"社会主义本质和建设中国特色社会主义总任务（十一）"},
                        {"chapterNum":"6.12", "chapterName":"社会主义本质和建设中国特色社会主义总任务（十二）"},
                        {"chapterNum":"6.13", "chapterName":"社会主义本质和建设中国特色社会主义总任务（十三）"},
                        {"chapterNum":"6.14", "chapterName":"社会主义本质和建设中国特色社会主义总任务（十四）"},
                        {"chapterNum":"6.15", "chapterName":"社会主义本质和建设中国特色社会主义总任务（十五）"},
                        {"chapterNum":"6.16", "chapterName":"社会主义本质和建设中国特色社会主义总任务（十六）"}
                    ],
                    "社会主义改革开放理论":[
                        {"chapterNum":"7.1", "chapterName":"社会主义改革开放理论（一）"},
                        {"chapterNum":"7.2", "chapterName":"社会主义改革开放理论（二）"},
                        {"chapterNum":"7.3", "chapterName":"社会主义改革开放理论（三）"},
                        {"chapterNum":"7.4", "chapterName":"社会主义改革开放理论（四）"},
                        {"chapterNum":"7.5", "chapterName":"社会主义改革开放理论（五）"},
                        {"chapterNum":"7.6", "chapterName":"社会主义改革开放理论（六）"},
                        {"chapterNum":"7.7", "chapterName":"社会主义改革开放理论（七）"}
                    ],
                    "建设中国特色社会主义经济":[
                        {"chapterNum":"8.1", "chapterName":"建设中国特色社会主义经济（一）"},
                        {"chapterNum":"8.2", "chapterName":"建设中国特色社会主义经济（二）"},
                        {"chapterNum":"8.3", "chapterName":"建设中国特色社会主义经济（三）"},
                        {"chapterNum":"8.4", "chapterName":"建设中国特色社会主义经济（四）"},
                        {"chapterNum":"8.5", "chapterName":"建设中国特色社会主义经济（五）"},
                        {"chapterNum":"8.6", "chapterName":"建设中国特色社会主义经济（六）"},
                        {"chapterNum":"8.7", "chapterName":"建设中国特色社会主义经济（七）"},
                        {"chapterNum":"8.8", "chapterName":"建设中国特色社会主义经济（八）"}
                    ],
                    "建设中国特色社会主义政治":[
                        {"chapterNum":"9.1", "chapterName":"建设中国特色社会主义政治（一）"},
                        {"chapterNum":"9.2", "chapterName":"建设中国特色社会主义政治（二）"},
                        {"chapterNum":"9.3", "chapterName":"建设中国特色社会主义政治（三）"},
                        {"chapterNum":"9.4", "chapterName":"建设中国特色社会主义政治（四）"},
                        {"chapterNum":"9.5", "chapterName":"建设中国特色社会主义政治（五）"},
                        {"chapterNum":"9.6", "chapterName":"建设中国特色社会主义政治（六）"},
                        {"chapterNum":"9.7", "chapterName":"建设中国特色社会主义政治（七）"},
                        {"chapterNum":"9.8", "chapterName":"建设中国特色社会主义政治（八）"}
                    ],
                    "建设中国特色社会主义文化":[
                        {"chapterNum":"10.1", "chapterName":"建设中国特色社会主义文化（一）"},
                        {"chapterNum":"10.2", "chapterName":"建设中国特色社会主义文化（二）"},
                        {"chapterNum":"10.3", "chapterName":"建设中国特色社会主义文化（三）"},
                        {"chapterNum":"10.4", "chapterName":"建设中国特色社会主义文化（四）"},
                        {"chapterNum":"10.5", "chapterName":"建设中国特色社会主义文化（五）"},
                        {"chapterNum":"10.6", "chapterName":"建设中国特色社会主义文化（六）"},
                        {"chapterNum":"10.7", "chapterName":"建设中国特色社会主义文化（七）"},
                        {"chapterNum":"10.8", "chapterName":"建设中国特色社会主义文化（八）"}
                    ],
                    "建设社会主义和谐社会":[
                        {"chapterNum":"11.1", "chapterName":"建设社会主义和谐社会（一）"},
                        {"chapterNum":"11.2", "chapterName":"建设社会主义和谐社会（二）"},
                        {"chapterNum":"11.3", "chapterName":"建设社会主义和谐社会（三）"}
                    ],
                    "建设中国特色社会主义生态文明":[
                        {"chapterNum":"12.1", "chapterName":"建设中国特色社会主义生态文明（一）"},
                        {"chapterNum":"12.2", "chapterName":"建设中国特色社会主义生态文明（二）"},
                        {"chapterNum":"12.3", "chapterName":"建设中国特色社会主义生态文明（三）"}
                    ]
                }
            ]
        },
        {
            "courseid":"87610803",
            "courseName":"高考地理复习基础知识",
            "typeOne":"高考考点串讲",
            "typeTwo":"",
            "keySpeakName":"刘子午",
            "keySpeakUnivercity":"北京大学附属中学",
            "keySpeakPosition":"特级教师",
            "keySpeakIntroduce":"北大附中地理特级教师，地理教研组组长。多年来一直在全国各省、直辖市、自治区高考备考研讨会介绍备考经验，对高考命题有独到研究与见解，有多篇涉及考题评价文章见诸报端。在《中国科普名家名作’不知道的世界’系列丛书》中著《大地海洋篇》，并多次再版。幼年得名很具学科特色，多年的勤学又满腹经纶，跨学科知识广博，颇受听课师生尊敬与爱戴。",
            "courseIntroduce":["多看书、抓基础知识、注意细节、掌握牢固、注意休息、保证睡眠、劳逸结合提高效率是很重要的，更重要的是有良好的心态和科学的方法。"],
            "bigImgUrl":"http://p.ananas.chaoxing.com/star3/733_434c/54f905e7e4b06685dee145eb.jpg",
            "videoUrl":"",
            "courseChapter":[
                {
                    "前言":[
                        {"chapterNum":"1.1", "chapterName":"往年知识点与考点分值分析"},
                        {"chapterNum":"1.2", "chapterName":"打好基础、课本为主"},
                        {"chapterNum":"1.3", "chapterName":"知识点与考点复习"}
                    ],
                    "地图知识，基础夯实":[
                        {"chapterNum":"2.1", "chapterName":"知识点分析"},
                        {"chapterNum":"2.2", "chapterName":"经纬网地图的应用案例分析"},
                        {"chapterNum":"2.3", "chapterName":"各类等值线图的阅读分析应用"},
                        {"chapterNum":"2.4", "chapterName":"各类地形图的读图案例分析"},
                        {"chapterNum":"2.5", "chapterName":"示意图、景观图"},
                        {"chapterNum":"2.6", "chapterName":"辅助图的应用"},
                        {"chapterNum":"2.7", "chapterName":"数字地图"}
                    ],
                    "地球运动，要会运用":[
                        {"chapterNum":"3.1", "chapterName":"地球远动案例分析"}
                    ],
                    "天气气候，系统掌握":[
                        {"chapterNum":"4.1", "chapterName":"知识点总结"},
                        {"chapterNum":"4.2", "chapterName":"地中海气候案例分析"},
                        {"chapterNum":"4.3", "chapterName":"热带雨林气候案例分析"},
                        {"chapterNum":"4.4", "chapterName":"热带季风气候案例分析"},
                        {"chapterNum":"4.5", "chapterName":"温带大陆、热带草原气候案例分析"},
                    ],
                    "陆地海洋，熟悉规律":[
                        {"chapterNum":"5.1", "chapterName":"知识点总结"},
                        {"chapterNum":"5.2", "chapterName":"地壳的物质循环案例分析"},
                        {"chapterNum":"5.3", "chapterName":"自然界的水循环案例分析"},
                        {"chapterNum":"5.4", "chapterName":"水资源的利用"}
                    ],
                    "农业区位，影响因素":[
                        {"chapterNum":"6.1", "chapterName":"影响农业发展的因素"},
                        {"chapterNum":"6.2", "chapterName":"世界主要农业地域类型的比较"}
                    ],
                    "工业区位与工业区":[
                        {"chapterNum":"7.1", "chapterName":"工业类型总结"},
                        {"chapterNum":"7.2", "chapterName":"2010年大纲案例分析"},
                        {"chapterNum":"7.3", "chapterName":"2011年大纲案例分析"},
                        {"chapterNum":"7.4", "chapterName":"2012年大纲案例分析"}
                    ],
                    "人口增长与城市化":[
                        {"chapterNum":"8.1", "chapterName":"知识点总结"},
                        {"chapterNum":"8.2", "chapterName":"人口分布案例分析"},
                    ],
                    "区域地理可持续发展":[
                        {"chapterNum":"9.1", "chapterName":"知识点总结"},
                        {"chapterNum":"9.2", "chapterName":"2012北京试卷案例分析"},
                        {"chapterNum":"9.3", "chapterName":"森林在自然地理环境中的作用"},
                        {"chapterNum":"9.4", "chapterName":"区域地理可持续发展的案例分析"}
                    ],
                    "自然灾害，旅游地理":[
                        {"chapterNum":"10.1", "chapterName":"自然灾害类型、防治及分布"},
                        {"chapterNum":"10.2", "chapterName":"地质地貌灾害案例分析"},
                        {"chapterNum":"10.3", "chapterName":"旅游地理案例分析"},
                    ]
                }
            ]
        },
        {
            "courseid":"87610748",
            "courseName":"高考语文知识点讲解 作文部分",
            "typeOne":"高考考点串讲",
            "typeTwo":"",
            "keySpeakName":"李永茂",
            "keySpeakUnivercity":"北京市顺义区杨镇一中",
            "keySpeakPosition":"特级教师",
            "keySpeakIntroduce":"北京市顺义区杨镇一中语文教师，从事教育事业35载，担任班主任工作30年，座右铭“润物无声育茂林。现为“北京市语文学科带头人，全国优秀语文教师，全国科研优秀教师，北京市政府评定的优秀教师，顺义区语文学科首席教师，首批参加教育部“跨世纪园丁”工程国家级培训教师，北京市紫金杯特等奖优秀班主任。",
            "courseIntroduce":[" 写作是语文高考一个重要的组成部分，文章从审题、语言、结构等方面对高考作文应试技巧做了一些探讨。"," 写作对于语文高考来说是极其重要的，如何提高写作水平是我们面临的一道难题。写作水平是需要长期积累，循序渐进提高的，但对于高三学生来说时间紧、任务重，花在语文学科上的时间又少，更没有多少时间花在作文的单项训练上，因此如何在有限的时间当中提高效率，提高语文作文的得分是值得我们老师去探讨的问题。"],
            "bigImgUrl":"http://p.ananas.chaoxing.com/star3/origin/56fcd56ae4b0578413cda211.png",
            "videoUrl":"",
            "courseChapter":[
                {
                    "如何准确审题":[
                        {"chapterNum":"1.1", "chapterName":"高考写作要求"},
                        {"chapterNum":"1.2", "chapterName":"命题作文审题"},
                        {"chapterNum":"1.3", "chapterName":"新材料作文审题"},
                        {"chapterNum":"1.4", "chapterName":"要点小结"}
                    ],
                    "如何恰当立意":[
                        {"chapterNum":"2.1", "chapterName":"立意要明确"},
                        {"chapterNum":"2.2", "chapterName":"立意要集中"},
                        {"chapterNum":"2.3", "chapterName":"立意要深刻"},
                        {"chapterNum":"2.4", "chapterName":"立意要新颖"},
                        {"chapterNum":"2.5", "chapterName":"要点小结"}
                    ],
                    "如何快速构思":[
                        {"chapterNum":"3.1", "chapterName":"高考要求"},
                        {"chapterNum":"3.2", "chapterName":"记叙文的最佳结构——分列标题式"},
                        {"chapterNum":"3.3", "chapterName":"记叙文的最佳结构——夹叙夹议式"},
                        {"chapterNum":"3.4", "chapterName":"记叙文的最佳结构——镜头组合式"},
                        {"chapterNum":"3.5", "chapterName":"记叙文的最佳结构——巧设悬念式"},
                        {"chapterNum":"3.6", "chapterName":"记叙文的最佳结构——文眼立骨式"},
                        {"chapterNum":"3.7", "chapterName":"记叙文的最佳结构——小小说构思"}
                    ],
                    "如何精彩表达":[
                        {"chapterNum":"4.1", "chapterName":"高考要求"},
                        {"chapterNum":"4.2", "chapterName":"文章整体构思要求"},
                        {"chapterNum":"4.3", "chapterName":"议论文的最佳结构——并列式"},
                        {"chapterNum":"4.4", "chapterName":"议论文的最佳结构——层进式"},
                        {"chapterNum":"4.5", "chapterName":"议论文的最佳结构——对照式"},
                        {"chapterNum":"4.6", "chapterName":"议论文的最佳结构——总分式"},
                        {"chapterNum":"4.7", "chapterName":"让词语更传神"},
                        {"chapterNum":"4.8", "chapterName":"让引用更丰富"},
                        {"chapterNum":"4.9", "chapterName":"让句式显灵活"},
                        {"chapterNum":"4.10", "chapterName":"让修辞多样化、让语言含哲理"},
                        {"chapterNum":"4.11", "chapterName":"让风格个性化"}
                    ]
                }
            ]
        },
        {
            "courseid":"87610645",
            "courseName":"高考政治高频考点分析",
            "typeOne":"高考考点串讲",
            "typeTwo":"",
            "keySpeakName":"蔚国娟",
            "keySpeakUnivercity":"北京教育学院",
            "keySpeakPosition":"特级教师",
            "keySpeakIntroduce":"教师简介：蔚国娟，北京市特级教师，北京教育学院宣武分院高中政治教研室主任，北清之慧教育特约专家。教学成果：多次在国家核心教育教学期刊上发表研究论文，参与人民教育出版社为澳门编写高中思想品德课程的教材工作；参与《空中课堂丛书·高中文综》、高中新课标《生活与哲学》实验教科书教学参考用书等书的撰写工作。所获荣誉先后获得北京市优秀班主任“紫禁杯”一等奖、北京市中学政治学科带头人、宣武区模范教师、宣武区名师讲学团成员、宣武区第四届有突出贡献的科教、技术、管理人才。2007～2009学年被聘为北京市骨干教师研修班指导老师；2006～现在，被聘为中国教育学会教育发展研究中心专家团成员；2009年起，被聘为北京师范大学免费教育师范生兼职导师、人民教育出版社高中政治培训团专家；2009、2010年被聘为CCTV中学生频道录像课授课教师。",
            "courseIntroduce":["政治是以经济为基础的上层建筑，是经济的集中表现，是以政治权力为核心展开的各种社会活动和社会关系的总和。","通过本课程，同学们可以分三个方面学习。第一方面：知识结构，例如：如何正确地总结和概括了时代的实践经验和认识成果、怎样了解真正的哲学等。第二方面：考点剖析，把这门课程的高考考点进行分析。第三方面：试题演练，给同学们展示这门课程内容所涉及到近几年的高考试题，并进行讲解高中思想政治课进行马克思列宁主义、毛泽东思想、邓小平理论和“三个代表”重要思想的基本观点教育，以社会主义物质文明、政治文明、精神文明建设常识为基本内容，引导学生紧密结合与自己息息相关的经济、政治、文化生活，经历探究学习和社会实践的过程，领悟辩证唯物主义和历史唯物主义的基本观点和方法，切实提高参与现代社会生活的能力，逐步树立建设中国特色社会主义的共同理想，初步形成正确的世界观、人生观、价值观，为终身发展奠定思想政治素质基础。"],
            "bigImgUrl":"http://p.ananas.chaoxing.com/star/733_434c/1384477609157pxfgp.jpg",
            "videoUrl":"",
            "courseChapter":[
                {
                    "生活智慧与时代精神":[
                        {"chapterNum":"1.1", "chapterName":"高考要求"},
                        {"chapterNum":"1.2", "chapterName":"世界观、具体科学和哲学的关系"},
                        {"chapterNum":"1.3", "chapterName":"哲学的基本问题"},
                        {"chapterNum":"1.4", "chapterName":"哲学与时代精神"},
                        {"chapterNum":"1.5", "chapterName":"哲学与哲学的基本问题考题解析"},
                        {"chapterNum":"1.6", "chapterName":"马克思主义哲学与哲学的基本问题考题解析"},
                        {"chapterNum":"1.7", "chapterName":"相关试题"}
                    ],
                    "探求世界与追求真理":[
                        {"chapterNum":"2.1", "chapterName":"高考要求"},
                        {"chapterNum":"2.2", "chapterName":"物质和意识的关系"},
                        {"chapterNum":"2.3", "chapterName":"运动与物质的关系"},
                        {"chapterNum":"2.4", "chapterName":"意识的本质、能动作用"},
                        {"chapterNum":"2.5", "chapterName":"意识的能动性考题解析"},
                        {"chapterNum":"2.6", "chapterName":"物质和意识综合考题解析"},
                        {"chapterNum":"2.7", "chapterName":"实践和认识的关系"},
                        {"chapterNum":"2.8", "chapterName":"真理的含义和特征"},
                        {"chapterNum":"2.9", "chapterName":"实践的观点贯穿全书"},
                        {"chapterNum":"2.10", "chapterName":"实践和认识综合考题解析"},
                        {"chapterNum":"2.11", "chapterName":"相关试题"}
                    ],
                    "思想方法与创新意识":[
                        {"chapterNum":"3.1", "chapterName":"高考要求"},
                        {"chapterNum":"3.2", "chapterName":"联系的含义和特点"},
                        {"chapterNum":"3.3", "chapterName":"联系的两种方法"},
                        {"chapterNum":"3.4", "chapterName":"发展的普遍性和实质性"},
                        {"chapterNum":"3.5", "chapterName":"联系的特点、方法综合考题解析"},
                        {"chapterNum":"3.6", "chapterName":"联系和发展综合考题解析"},
                        {"chapterNum":"3.7", "chapterName":"矛盾是事物发展的源泉和动力"},
                        {"chapterNum":"3.8", "chapterName":"矛盾即对立统一"},
                        {"chapterNum":"3.9", "chapterName":"矛盾的普遍性和特殊性"},
                        {"chapterNum":"3.10", "chapterName":"理解主次矛盾和矛盾主次方面的区别"},
                        {"chapterNum":"3.11", "chapterName":"辩证的否定观与创新意识"},
                        {"chapterNum":"3.12", "chapterName":"唯物辩证法与形而上学的区别"},
                        {"chapterNum":"3.13", "chapterName":"矛盾的观点综合考题解析"},
                        {"chapterNum":"3.14", "chapterName":"辩证的否定观与创新意识综合考题解析"},
                        {"chapterNum":"3.15", "chapterName":"相关试题"}
                    ],
                    "认识社会与价值选择":[
                        {"chapterNum":"4.1", "chapterName":"相关试题"},
                        {"chapterNum":"4.2", "chapterName":"社会存在和社会意识"},
                        {"chapterNum":"4.3", "chapterName":"价值和价值观"},
                        {"chapterNum":"4.4", "chapterName":"历史唯物主义的基本观点考题解析"},
                        {"chapterNum":"4.5", "chapterName":"历史唯物主义的基本观点及价值观考题解析"},
                        {"chapterNum":"4.6", "chapterName":"价值和价值观考题解析"},
                        {"chapterNum":"4.7", "chapterName":"相关试题"}
                    ],
                    "公民的政治生活":[
                        {"chapterNum":"5.1", "chapterName":"高考要求"},
                        {"chapterNum":"5.2", "chapterName":"我国的国家性质及坚持人民民主专政"},
                        {"chapterNum":"5.3", "chapterName":"公民参与政治生活的主要内容、原则与途径"},
                        {"chapterNum":"5.4", "chapterName":"民主选举与民主管理"},
                        {"chapterNum":"5.5", "chapterName":"民主决策、民主监督及公民有序参与政治生活"},
                        {"chapterNum":"5.6", "chapterName":"公民参与政治生活综合考题解析"},
                        {"chapterNum":"5.7", "chapterName":"相关试题"}
                    ],
                    "为人民服务的政府":[
                        {"chapterNum":"6.1", "chapterName":"高考要求"},
                        {"chapterNum":"6.2", "chapterName":"我国政府的性质、地位及职能"},
                        {"chapterNum":"6.3", "chapterName":"政府职责的有限性及我国政府的组织活动原则"},
                        {"chapterNum":"6.4", "chapterName":"依法行政、民主监督及政府的权威"},
                        {"chapterNum":"6.5", "chapterName":"政府职能的考题解析"},
                        {"chapterNum":"6.6", "chapterName":"相关试题"}
                    ],
                    "发展社会主义民主政治":[
                        {"chapterNum":"7.1", "chapterName":"高考要求"},
                        {"chapterNum":"7.2", "chapterName":"人民代表大会、人大代表及人民代表大会制度"},
                        {"chapterNum":"7.3", "chapterName":"我国的政党制度"},
                        {"chapterNum":"7.4", "chapterName":"我国的民族区域自治制度及宗教政策"},
                        {"chapterNum":"7.5", "chapterName":"发展社会主义民主政治的考题解析"},
                        {"chapterNum":"7.6", "chapterName":"相关试题"}
                    ],
                    "当代国际社会":[
                        {"chapterNum":"8.1", "chapterName":"高考要求"},
                        {"chapterNum":"8.2", "chapterName":"主权国家及国际组织"},
                        {"chapterNum":"8.3", "chapterName":"国家利益、和平与发展及世界多极化的发展趋势"},
                        {"chapterNum":"8.4", "chapterName":"我国外交政策"},
                        {"chapterNum":"8.5", "chapterName":"国际关系及我国外交政策的考题解析"},
                        {"chapterNum":"8.6", "chapterName":"相关试题"}
                    ]
                }
            ]
        },
        {
            "courseid":"87610552",
            "courseName":"高考政治高频考点分析",
            "typeOne":"高考考点串讲",
            "typeTwo":"",
            "keySpeakName":"梁侠",
            "keySpeakUnivercity":"北京师范大学附属实验中学",
            "keySpeakPosition":"特级教师",
            "keySpeakIntroduce":"北京师大附属实验中学政治教研组长，特级教师。北京市政治学科带头人。教育部“跨世纪园丁工程”国家级培训骨干教师，兼任西城区政治学科教研员。北清之慧教育专家。教育部“跨世纪园丁工程”国家级培训骨干教师。北京师范大学中学政治骨干教师班指导教师、北京师范大学教育专业硕士研究生导师、《中国考试》杂志特约编委、光明日报《考试》杂志编委、《高考》杂志学科主编、《半月谈》杂志特约记者、教育部《普通高中课程标准思想政治必修4生活与哲学》2008修订组成员。近年来，每年参加全国高考试题分析与评论工作，研究方向主要是中学政治教学。曾应邀到全国十多个省市讲学，指导高考百余场次，受到广泛好评和欢迎。参加教育部、北京市多项重点科研课题研究。",
            "courseIntroduce":["本课程从高考高频知识点精细解读、高考高频主客观例题解析两大方面详细分析解读高中政治高频考点，主要涉及的知识及考点有：货币、价格及价值规律、消费、生产与经济制度、生产与消费、我国的基本经济制度、企业与公司经营、劳动者、投资与融资、个人收入的分配、国家收入的分配、征税与纳税、市场经济、社会主义市场经济、小康社会的经济建设、经济全球化与对外开放、文化与社会、文化对人的影响、文化的多样性与文化传播、文化的继承与发展、中华文化、弘扬和培育民族精神、走进文化生活、中国特色社会主义文化的发展与繁荣、社会主义精神文明建设。考点知识内容覆盖全面，内容详细，具有较高的实战与备考价值。"],
            "bigImgUrl":"http://p.ananas.chaoxing.com/star/733_434c/1384483127958qhxdc.jpg",
            "videoUrl":"",
            "courseChapter":[
                {
                    "商品、货币、价格":[
                        {"chapterNum":"1.1", "chapterName":"高考要求"},
                        {"chapterNum":"1.2", "chapterName":"货 币"},
                        {"chapterNum":"1.3", "chapterName":"价 格"},
                        {"chapterNum":"1.4", "chapterName":"相关试题"}
                    ],
                    "生产、消费与我国的基本经济制度":[
                        {"chapterNum":"2.1", "chapterName":"高考要求"},
                        {"chapterNum":"2.2", "chapterName":"消 费"},
                        {"chapterNum":"2.3", "chapterName":"生产与经济制度"},
                        {"chapterNum":"2.4", "chapterName":"相关试题"}
                    ],
                    "企业与劳动者、投资理财":[
                        {"chapterNum":"3.1", "chapterName":"高考要求"},
                        {"chapterNum":"3.2", "chapterName":"生产的微观主体一一企业"},
                        {"chapterNum":"3.3", "chapterName":"劳动者"},
                        {"chapterNum":"3.4", "chapterName":"投资与融资"},
                        {"chapterNum":"3.5", "chapterName":"相关试题"}
                    ],
                    "我国的分配制度与财政税收":[
                        {"chapterNum":"4.1", "chapterName":"高考要求"},
                        {"chapterNum":"4.2", "chapterName":"个人收入的分配"},
                        {"chapterNum":"4.3", "chapterName":"国家收入的分配"},
                        {"chapterNum":"4.4", "chapterName":"征税与纳税"},
                        {"chapterNum":"4.5", "chapterName":"相关试题"}
                    ],
                    "社会主义市场经济":[
                        {"chapterNum":"5.1", "chapterName":"高考要求"},
                        {"chapterNum":"5.2", "chapterName":"市场经济基本原理"},
                        {"chapterNum":"5.3", "chapterName":"社会主义市场经济"},
                        {"chapterNum":"5.4", "chapterName":"相关试题"}
                    ],
                    "科学发展与提高开放型经济水平":[
                        {"chapterNum":"6.1", "chapterName":"高考要求"},
                        {"chapterNum":"6.2", "chapterName":"小康社会的经济建设"},
                        {"chapterNum":"6.3", "chapterName":"经济全球化与对外开放"},
                        {"chapterNum":"6.4", "chapterName":"相关试题"}
                    ],
                    "文化生活":[
                        {"chapterNum":"7.1", "chapterName":"高考要求"},
                        {"chapterNum":"7.2", "chapterName":"文化与社会"},
                        {"chapterNum":"7.3", "chapterName":"文化对人的影响"},
                        {"chapterNum":"7.4", "chapterName":"相关试题"}
                    ],
                    "文化传播与继承":[
                        {"chapterNum":"8.1", "chapterName":"高考要求"},
                        {"chapterNum":"8.2", "chapterName":"文化的多样性与文化传播"},
                        {"chapterNum":"8.3", "chapterName":"文化的继承与发展"},
                        {"chapterNum":"8.4", "chapterName":"相关试题"}
                    ],
                    "文化创新、中华文化与民族精神":[
                        {"chapterNum":"9.1", "chapterName":"高考要求"},
                        {"chapterNum":"9.2", "chapterName":"文化创新"},
                        {"chapterNum":"9.3", "chapterName":"灿烂的中华文化"},
                        {"chapterNum":"9.4", "chapterName":"弘扬和培育民族精神"},
                        {"chapterNum":"9.5", "chapterName":"相关试题"}
                    ],
                    "发展中国特色社会主义文化":[
                        {"chapterNum":"10.1", "chapterName":"高考要求"},
                        {"chapterNum":"10.2", "chapterName":"走进文化生活"},
                        {"chapterNum":"10.3", "chapterName":"中国特色社会主义文化的发展与繁荣"},
                        {"chapterNum":"10.4", "chapterName":"社会主义精神文明建设"},
                        {"chapterNum":"10.5", "chapterName":"相关试题"}
                    ]
                }
            ]
        },
        {
            "courseid":"87610519",
            "courseName":"高考语文知识点讲解 文言文部分",
            "typeOne":"高考考点串讲",
            "typeTwo":"",
            "keySpeakName":"刘运秀",
            "keySpeakUnivercity":"北京市第八中学",
            "keySpeakPosition":"特级教师",
            "keySpeakIntroduce":"教师简介：刘运秀，北京第八中学语文教研组长。毕业于首都师范大学中文系，现任北京八中、全国中学语文教学研究会理事。曾被评为西城区首批学科带头人、北京市首批中青年骨干教师，参加首批国家级中青年骨干教师培训，曾被全国中语会教学艺术研究中心评为“全国优秀语文教师”。做为教育专家，现享受政府特殊津贴待遇。教法特色：从教于超常教育实验班的十年中，追求短时高效，并积极运用现代化教学手段，努力提高语文教学效率，用四年时间成功的完成了八年的教学任务，所教班级在历届高考中名列北京市前茅。多次在中国教育电视台、北京电视台授课或举办作文系列讲座，有六张教学光盘在全国发行。教师著作：主编了《超常少年成长的摇篮》一书，参与了《中学学科教学教法精粹》等三本论著的编写，在《中学语文教学》、《现代特殊教育》等报刊发表过多篇论文；录制《2009高频考点透析》等高考辅导录像，曾参加过香港、美国、西班牙的国际教育会议并宣讲论文。参加过人民教育出版社初中语文教材及北京市21世纪基础教育新教材的编写；独立编写了《中学超常教育语文教学大纲》。教学论文曾获全国二等奖、北京市特等奖。",
            "courseIntroduce":["文言文是高考语文的重要组成部分，许多学生在考试中遇到文言文的时候会产生一定的畏难心理，在平时不善于总结归纳，或总结的知识得不到充分利用，在答题的过程中具有一定的盲目性，这些都导致了学生在文言文题型的得分一般都不高。","为了帮助广大考生更好的复习，北京市第八中学的刘运秀老师结合历年高考真题，对高考文言文的出题思路和考题类型进行了详细分析，针对各个考察点逐一讲解，并提出了高效的复习方法和解题策略。","希望给大家能够从讲解中获益，增强在文言文方面的阅读和分析能力。"],
            "bigImgUrl":"http://p.ananas.chaoxing.com/star3/733_434c/570765e8e4b0578413d144a1.jpg",
            "videoUrl":"",
            "courseChapter":[
                {
                    "文言文词法":[
                        {"chapterNum":"1.1", "chapterName":"词类活用"},
                        {"chapterNum":"1.2", "chapterName":"古今异义"},
                        {"chapterNum":"1.3", "chapterName":"一词多义"}
                    ],
                    "文言句式":[
                        {"chapterNum":"2.1", "chapterName":"判断句"},
                        {"chapterNum":"2.2", "chapterName":"被动句"},
                        {"chapterNum":"2.3", "chapterName":"倒装句"},
                        {"chapterNum":"2.4", "chapterName":"省略句"}
                    ],
                    "文言文断句":[
                        {"chapterNum":"3.1", "chapterName":"根据词性、语序"},
                        {"chapterNum":"3.2", "chapterName":"根据特殊句式、固定格式"},
                        {"chapterNum":"3.3", "chapterName":"根据修辞"},
                        {"chapterNum":"3.4", "chapterName":"其他方式"},
                        {"chapterNum":"3.5", "chapterName":"高考试题"}
                    ],
                    "文言文翻译":[
                        {"chapterNum":"4.1", "chapterName":"文言文翻译的考察点"},
                        {"chapterNum":"4.2", "chapterName":"信、达、雅原则"},
                        {"chapterNum":"4.3", "chapterName":"六字翻译法"},
                        {"chapterNum":"4.4", "chapterName":"推断词义的方法"},
                        {"chapterNum":"4.5", "chapterName":"树立采分点的意识"},
                        {"chapterNum":"4.6", "chapterName":"直译的原则"}
                    ],
                    "文言文文意理解":[
                        {"chapterNum":"5.1", "chapterName":"高考选文的特点"},
                        {"chapterNum":"5.2", "chapterName":"文言应试阅读分三步"},
                        {"chapterNum":"5.3", "chapterName":"文意理解试题特点"},
                        {"chapterNum":"5.4", "chapterName":"建立整体的解题审读观"},
                        {"chapterNum":"5.5", "chapterName":"对应的解题方法"}
                    ]
                }
            ]
        },
        {
            "courseid":"87610428",
            "courseName":"英语高考知识点",
            "typeOne":"高考考点串讲",
            "typeTwo":"",
            "keySpeakName":"李俊和",
            "keySpeakUnivercity":"北京第四中学",
            "keySpeakPosition":"特级教师",
            "keySpeakIntroduce":" 北京四中外语教研组组长，北京市骨干教师；北京《中学生英语报》特邀撰稿人，北清之慧教育，简单学习网特约教师。九四年赴美学习， 并在美文学杂志《Mandela》上发表英文小说 “MyGoldenGun”。 主编或参与编写了十几本关于中学外语教学的书籍，多次为青年教师和外地教师作教学辅导讲座。 编写《高中听力宝典》，全国高考英语听力朗读人之一。李老师从事高中英语教学三十多年，不仅有丰富的中学英语教学经验，还曾多次担任中央电视台教育频道、中国教育电视台, 北京电视台和数字电视高考备考节目主讲人。在全国各地(除西藏外)为中学教师做过近百场关于英语教学方法的讲座。论文与著作：李老师目前是国家考试中心《中国考试》杂志特约编委，《光明日报》考试杂志学科顾问。有多篇教学论文在《中国考试》、《中国教育报》、《基础英语教学》等中央和省市级刊物发表，并出版过三十余部教学辅导用书如《中学英语语法手册》、《英语听力宝典》、《优秀高三英语教师应该知道的十二件事》、《五加三英语分册》等。荣誉与奖励：在北京四中教授英语二十三年，担任英语教研组长十余年。获北京市先进教师称号，北京四中优秀园丁奖。2004年被中国外语教学研究会评为全国优秀中小学外语教师。",
            "courseIntroduce":["在高中英语教学中，既不能以语法知识的讲解代替语言实践训练，也不能以单纯的语言实践训练排斥必要的语法知识的讲授。要将两者有机地结合起来，就要以练为主，以讲、导为辅；在练中发现问题，在导中避免问题，在讲中解决问题，恰当地处理好讲、练、导的关系，从而提高课堂教学效率。","高考英语所学知识点内容多，内容一个个之间比较零散，对于同学们的记忆和复习是一份非常大的考验。我们有必要将高中英语知识点进行汇总，这样方便我们的复习。本课程通过李俊和老师详细的为大家总结高中英语知识点及结合历年来的高考试题来更有效的引导同学们弥补对英语知识点认识方面的不足之处，希望能在原来所学的基础上大大提高一步。"],
            "bigImgUrl":"",
            "videoUrl":"",
            "courseChapter":[
                {
                    "三种非谓语动词的使用":[
                        {"chapterNum":"1.1", "chapterName":"动词不定式"},
                        {"chapterNum":"1.2", "chapterName":"ed 还是 ing"},
                        {"chapterNum":"1.3", "chapterName":"分词使用中的几个难点"},
                        {"chapterNum":"1.4", "chapterName":"非谓语动词中的do与doing"}
                    ],
                    "几个重点时态的使用":[
                        {"chapterNum":"2.1", "chapterName":"现在完成时态"},
                        {"chapterNum":"2.2", "chapterName":"过去完成时态"},
                        {"chapterNum":"2.3", "chapterName":"一般现在时与现在进行时"},
                        {"chapterNum":"2.4", "chapterName":"一般过去时与过去进行时"}
                    ],
                    "情态动词的使用":[
                        {"chapterNum":"3.1", "chapterName":"情态动词can, may, must"},
                        {"chapterNum":"3.2", "chapterName":"情态动词 shall, should, dare等"}
                    ],
                    "短语动词的使用":[
                        {"chapterNum":"4.1", "chapterName":"短语动词的分类"},
                        {"chapterNum":"4.2", "chapterName":"含out和 up的短语动词"}
                    ],
                    "被动语态":[
                        {"chapterNum":"5.1", "chapterName":"知识讲解"},
                        {"chapterNum":"5.2", "chapterName":"练习检测"}
                    ],
                    "虚拟语气的使用":[
                        {"chapterNum":"6.1", "chapterName":"虚拟语气的三个公式"},
                        {"chapterNum":"6.2", "chapterName":"虚拟语气的三个公式"}
                    ],
                    "常用动词辨析":[
                        {"chapterNum":"7.1", "chapterName":"知识讲解"},
                        {"chapterNum":"7.2", "chapterName":"练习检测"}
                    ],
                    "冠词的几个用法":[
                        {"chapterNum":"8.1", "chapterName":"不定冠词与定冠词的区别"},
                        {"chapterNum":"8.2", "chapterName":"含有冠词短语的辨别"}
                    ],
                    "代词名词与数词的几个用法":[
                        {"chapterNum":"9.1", "chapterName":"不定代词的使用"},
                        {"chapterNum":"9.2", "chapterName":"名词的单复数"},
                        {"chapterNum":"9.3", "chapterName":"名词同义词的辨析"},
                        {"chapterNum":"9.4", "chapterName":"数词"}
                    ],
                    "形容词与副词几个用法":[
                        {"chapterNum":"10.1", "chapterName":"形容词副词比较级"},
                        {"chapterNum":"10.2", "chapterName":"形容词副词的几个特殊用法"}
                    ],
                    "各类从句的用法指导":[
                        {"chapterNum":"11.1", "chapterName":"介词的使用"},
                        {"chapterNum":"11.2", "chapterName":"连接词语的使用"},
                        {"chapterNum":"11.3", "chapterName":"定语从句"},
                        {"chapterNum":"11.4", "chapterName":"同位语从句与主语从句"}
                    ],
                    "句子的种类":[
                        {"chapterNum":"12.1", "chapterName":"知识讲解"},
                        {"chapterNum":"12.2", "chapterName":"练习检测"}
                    ],
                    "倒装与主谓一致":[
                        {"chapterNum":"13.1", "chapterName":"倒装"},
                        {"chapterNum":"13.2", "chapterName":"主谓一致"}
                    ],
                    "it的用法与强调句型":[
                        {"chapterNum":"14.1", "chapterName":"知识讲解"},
                        {"chapterNum":"14.2", "chapterName":"练习检测"}
                    ],
                    "英语中的口语交际":[
                        {"chapterNum":"15.1", "chapterName":"知识讲解"},
                        {"chapterNum":"15.2", "chapterName":"练习检测"}
                    ],
                    "there be 句型与省略":[
                        {"chapterNum":"16.1", "chapterName":"there be 句型"},
                        {"chapterNum":"16.2", "chapterName":"省略"}
                    ],
                    "单词记忆的几个办法":[
                        {"chapterNum":"17.1", "chapterName":"如何记忆高考词汇"},
                        {"chapterNum":"17.2", "chapterName":"高考要求的构词法知识"},
                        {"chapterNum":"17.3", "chapterName":"常用词语的惯用法"},
                        {"chapterNum":"17.4", "chapterName":"词语搭配"}
                    ],
                    "高考重点词组":[
                        {"chapterNum":"18.1", "chapterName":"知识讲解"}
                    ],
                    "高考试题特点":[
                        {"chapterNum":"19.1", "chapterName":"知识讲解"}
                    ],
                    "高三英语复习策略":[
                        {"chapterNum":"20.1", "chapterName":"知识讲解"}
                    ],
                    "高考听力的应试技巧":[
                        {"chapterNum":"21.1", "chapterName":"试题简介"},
                        {"chapterNum":"21.2", "chapterName":"应试要点"},
                        {"chapterNum":"21.3", "chapterName":"如何备考"}
                    ],
                    "做好单项填空题的几个办法":[
                        {"chapterNum":"22.1", "chapterName":"试题简介"},
                        {"chapterNum":"22.2", "chapterName":"应试要点"},
                        {"chapterNum":"22.3", "chapterName":"备考措施"}
                    ],
                    "完形填空的题型特点与应试注意":[
                        {"chapterNum":"23.1", "chapterName":"试题特点"},
                        {"chapterNum":"23.2", "chapterName":"解题要领"},
                        {"chapterNum":"23.3", "chapterName":"提高措施"}
                    ],
                    "如何提高阅读理解的能力":[
                        {"chapterNum":"24.1", "chapterName":"阅读理解的四类问题与解题方法"},
                        {"chapterNum":"24.2", "chapterName":"准确阅读文章的十大难点"},
                        {"chapterNum":"24.3", "chapterName":"阅读理解中的七选五"}
                    ],
                    "短文改错":[
                        {"chapterNum":"25.1", "chapterName":"试题特点"},
                        {"chapterNum":"25.2", "chapterName":"解题要领"}
                    ],
                    "如何提高英语写作能力":[
                        {"chapterNum":"26.1", "chapterName":"提高英语写作能力的几个办法"},
                        {"chapterNum":"26.2", "chapterName":"写作测试中的四类作文"},
                        {"chapterNum":"26.3", "chapterName":"书面表达测试的应试注意"}
                    ]
                }
            ]
        },
        {
            "courseid":"87610356",
            "courseName":"高考历史高频考点分析 中国近代史部分",
            "typeOne":"高考考点串讲",
            "typeTwo":"",
            "keySpeakName":"曹卫东",
            "keySpeakUnivercity":"北京市朝阳区教研中心",
            "keySpeakPosition":"特级教师",
            "keySpeakIntroduce":"教学成果：《在课程改革背景下重新认识历史教科书》，2006年，《新课程下校本教研探索丛书》华夏出版社出版；《“从内外服联盟到封邦建国”教学案例》，2008年7月，《历史教学》；《理解·创造我对整合处理教材的一点看法》，2009年7月，《历史教学》；《2008年北京市普通高中春季会考历史学科统计分析报告（大纲版）》，2008年6月，北京教育考试院编－北京《开明出版社》；《2009年北京市普通高中春季会考历史学科统计分析报告（新课程版）》，北京教育考试院编。所获荣誉：北京市第十六届中小学“紫禁杯”一等奖、优秀班主任称号（2003年10月）；朝阳区教育系统学科带头人（2006年）；北京市历史学科骨干教师（2008年）。",
            "courseIntroduce":["中国近代史从鸦片战争（1840年）到新中国成立（1949年）为止。一部中国近代史，是一部中国人民的革命史，是一部中华民族抵抗侵略的抗争史，是一部中华民族打倒帝国主义以实现民族解放、打倒封建主义以实现人民富强的斗争史。","同学们由于在中学阶段都已经系统学过中国近代史，对有关的历史事实、重大事件和重要人物，有一个基本的了解。根据这些情况，在学习本课程的过程中，老师通过结合历年来的高考试题来更有效的引导同学们弥补对近代史把握方面的不足之处，希望能在原来所学近代史知识的基础上大大提高一步。"],
            "bigImgUrl":"http://p.ananas.chaoxing.com/star/733_434c/1384148646018inpoi.jpg",
            "videoUrl":"",
            "courseChapter":[
                {
                    "课程概要":[
                        {"chapterNum":"1.1", "chapterName":"对中国近代史的认识"},
                        {"chapterNum":"1.2", "chapterName":"对中国近代史的划分"}
                    ],
                    "鸦片战争与19世纪40、50年代":[
                        {"chapterNum":"2.1", "chapterName":"高考要求"},
                        {"chapterNum":"2.2", "chapterName":"鸦片战争"},
                        {"chapterNum":"2.3", "chapterName":"鸦片战争前的中国社会经济状况"},
                        {"chapterNum":"2.4", "chapterName":"不平等条约内容、鸦片战争对中国的影响"},
                        {"chapterNum":"2.5", "chapterName":"相关试题"}
                    ],
                    "第二次鸦片战争与19世纪60——80年代":[
                        {"chapterNum":"3.1", "chapterName":"高考要求"},
                        {"chapterNum":"3.2", "chapterName":"第二次鸦片战争对中国社会的影响"},
                        {"chapterNum":"3.3", "chapterName":"对太平天国运动的相关评价"},
                        {"chapterNum":"3.4", "chapterName":"洋务运动"},
                        {"chapterNum":"3.5", "chapterName":"中国民族资本主义产生"},
                        {"chapterNum":"3.6", "chapterName":"“中学为体，西学为用”"},
                        {"chapterNum":"3.7", "chapterName":"相关试题"}
                    ],
                    "甲午中日战争与19世纪末的中国":[
                        {"chapterNum":"4.1", "chapterName":"高考要求"},
                        {"chapterNum":"4.2", "chapterName":"《马关条约》及其影响"},
                        {"chapterNum":"4.3", "chapterName":"维新变法的背景及维新思想"},
                        {"chapterNum":"4.4", "chapterName":"维新变法的过程及影响"},
                        {"chapterNum":"4.5", "chapterName":"相关试题"}
                    ],
                    "辛亥革命与20世纪初的中国":[
                        {"chapterNum":"5.1", "chapterName":"高考要求"},
                        {"chapterNum":"5.2", "chapterName":"义和团运动、八国联军侵华"},
                        {"chapterNum":"5.3", "chapterName":"清朝“新政”与“预备立宪”"},
                        {"chapterNum":"5.4", "chapterName":"孙中山与三民主义"},
                        {"chapterNum":"5.5", "chapterName":"辛亥革命、中华民国、反专制斗争"},
                        {"chapterNum":"5.6", "chapterName":"民族资本主义迅速、短暂发展"},
                        {"chapterNum":"5.7", "chapterName":"相关试题"}
                    ],
                    "国民大革命":[
                        {"chapterNum":"6.1", "chapterName":"高考要求"},
                        {"chapterNum":"6.2", "chapterName":"新旧三民主义"},
                        {"chapterNum":"6.3", "chapterName":"新三民主义和三大政策的关系"},
                        {"chapterNum":"6.4", "chapterName":"国民党“一大”"},
                        {"chapterNum":"6.5", "chapterName":"革命高潮"},
                        {"chapterNum":"6.6", "chapterName":"国民革命失败原因与意义"},
                        {"chapterNum":"6.7", "chapterName":"例题解析"},
                        {"chapterNum":"6.8", "chapterName":"相关试题"}
                    ],
                    "新文化运动、五四运动、中国共产党诞生":[
                        {"chapterNum":"7.1", "chapterName":"高考要求"},
                        {"chapterNum":"7.2", "chapterName":"北洋政府的政治（外交）、经济、文化教育"},
                        {"chapterNum":"7.3", "chapterName":"新文化运动与五四运动"},
                        {"chapterNum":"7.4", "chapterName":"中国共产党成立"},
                        {"chapterNum":"7.5", "chapterName":"相关试题"}
                    ],
                    "土地革命时期":[
                        {"chapterNum":"8.1", "chapterName":"高考要求"},
                        {"chapterNum":"8.2", "chapterName":"南昌起义"},
                        {"chapterNum":"8.3", "chapterName":"土地革命"},
                        {"chapterNum":"8.4", "chapterName":"红军长征"},
                        {"chapterNum":"8.5", "chapterName":"西安事变和平解决"},
                        {"chapterNum":"8.6", "chapterName":"例题解析"},
                        {"chapterNum":"8.7", "chapterName":"相关试题"}
                    ],
                    "抗日战争时期":[
                        {"chapterNum":"9.1", "chapterName":"高考要求"},
                        {"chapterNum":"9.2", "chapterName":"国共合作与抗日民族统一战线正式建立"},
                        {"chapterNum":"9.3", "chapterName":"抗战两个战场、抗战的阶段（相持阶段）"},
                        {"chapterNum":"9.4", "chapterName":"抗日战争胜利：原因与意义"},
                        {"chapterNum":"9.5", "chapterName":"例题解析"},
                        {"chapterNum":"9.6", "chapterName":"相关试题"}
                    ],
                    "解放战争时期":[
                        {"chapterNum":"10.1", "chapterName":"高考要求"},
                        {"chapterNum":"10.2", "chapterName":"解放战争——全面爆发"},
                        {"chapterNum":"10.3", "chapterName":"解放战争结果"},
                        {"chapterNum":"10.4", "chapterName":"例题解析"},
                        {"chapterNum":"10.5", "chapterName":"相关试题"}
                    ]
                }
            ]
        },
        {
            "courseid":"87610317",
            "courseName":"高考化学知识点-基础理论部分",
            "typeOne":"高考考点串讲",
            "typeTwo":"",
            "keySpeakName":"田玉凤",
            "keySpeakUnivercity":"北京市第十二中学",
            "keySpeakPosition":"特级教师",
            "keySpeakIntroduce":"教课程深受学生喜欢，教学成绩突出。担任化学教研组长，以科研带动教研，采取多种途径和方法指导青年教师，所指导的青年教师教学与科研成绩显著。使化学教研组成了一个优秀集体。认真进行教学研究，撰写教学研究的总结与论文，参编和主编了大量学术著作。在全国性以及省市级报刊上发表教学论文十几篇，获市级以上一等奖论文有十几篇。论文与著作：高考化学与素质教育 《中国考试》 00 年 7 期 ( 中国考试中心 )；问题解决教学模式构建创新精神和创造能力《化学教学中创新教育的研究》（人教社）；运用现代信息技术提高课堂教学质量 《化学教育》02年10期 （中国化学会）；实验室制取氨气的探究性教学实践 《教学仪器与实验》04年3月 ( 教育部主办 )；2004年夏季高考理综试题分析与05年化学复习建议 《信息技术与课程整合》05年1期 (清华大学主办 )；《中学化学教学中促进学生探究学习教学模式的探索》 “ 国际纯粹与应用化学联合会（简称 IUPAC ）第 40 届学术大会 ” 上宣读， 文章摘要收录在大会文集。教育教学研究著作：课外天地丛书《化学小实验》 华文出版社；《高中》学生实用高考必备《化学》 中国青年出版社；《名师3轮点击新高考》（化学） 北师大出版社；《高考冲刺》（化学） 中国少儿出版社；《中学化学教学中促进学生探究学习的研究》 清华同方光盘出版社；《新课标中学生百科全书》 中国大百科出版社。荣誉与奖励：国务院特殊津贴专家、北京市化学特级教师、北清之慧特约专家、北京市优秀教师。",
            "courseIntroduce":[""],
            "bigImgUrl":"http://p.ananas.chaoxing.com/star/733_434c/1394780403556bqdrp.",
            "videoUrl":"",
            "courseChapter":[
                {
                    "物质结构与元素周期律":[
                        {"chapterNum":"1.1", "chapterName":"原子结构"},
                        {"chapterNum":"1.2", "chapterName":"元素周期律和元素周期表"},
                        {"chapterNum":"1.3", "chapterName":"化学键"}
                    ],
                    "化学能与热能":[
                        {"chapterNum":"2.1", "chapterName":"反应热"},
                        {"chapterNum":"2.2", "chapterName":"热化学方程式"},
                        {"chapterNum":"2.3", "chapterName":"化学能与热能转化的典型实验"},
                        {"chapterNum":"2.4", "chapterName":"盖斯定律与有关计算"}
                    ],
                    "化学反应速率":[
                        {"chapterNum":"3.1", "chapterName":"化学反应速率"},
                        {"chapterNum":"3.2", "chapterName":"实验探究方案设计"},
                        {"chapterNum":"3.3", "chapterName":"化学平衡"},
                        {"chapterNum":"3.4", "chapterName":"化学反应限度"}
                    ],
                    "水溶液中的离子平衡":[
                        {"chapterNum":"4.1", "chapterName":"弱电解质的电离"},
                        {"chapterNum":"4.2", "chapterName":"水的电离和溶液的pH"},
                        {"chapterNum":"4.3", "chapterName":"盐的水解及其应用"},
                        {"chapterNum":"4.4", "chapterName":"难溶电解质溶解平衡"}
                    ],
                    "原电池原理及其应用":[
                        {"chapterNum":"5.1", "chapterName":"原电池原理"},
                        {"chapterNum":"5.2", "chapterName":"原电池原理的应用"},
                        {"chapterNum":"5.3", "chapterName":"电解原理及其应用"},
                        {"chapterNum":"5.4", "chapterName":"电解的应用"}
                    ]
                }
            ]
        },
        {
            "courseid":"87610193",
            "courseName":"高考化学知识点 基本概念部分",
            "typeOne":"高考考点串讲",
            "typeTwo":"",
            "keySpeakName":"熊美容",
            "keySpeakUnivercity":"北京大学附属中学",
            "keySpeakPosition":"高级教师",
            "keySpeakIntroduce":"熊美容老师，北大附中青年化学骨干教师。在教学中注重以学生为本、关注每一位学生的教育思想，勤于在教学方法和教学效果上下功夫，善于在课堂中营造师生互动、轻松活泼的气氛，形成一套较有特色的教学风格。以“爱心、责任心和个人魅力”管理班级，注重充分发挥学生的特长，善于调动学生的积极性，尤其在后进生管理中有自己独特的方法，所带班级年年被评为优秀班集体，多次被评为区级优秀青年教师和优秀班主任。",
            "courseIntroduce":["大家知道的，从2007年新课程高考开始，2010年报考化学专业的考生减少到2008年的53%，2012年之后自主招生大部分都不考化学，高中化学教育边缘化趋势非常严重，这就是流行说法——“化学危机”。作为自然科学重要的基础学科，如何防止基础教育中被边缘化，2010年就已经成为教育部和高校高度重视的问题，看2011——2013高考理综，全卷压轴题（倒数第二集团试题）全部是化学，重要程度不言而喻。","化学基本概念与基本理论是化学的最基本内容与最基础的知识，是学习的难点，学生的分化点，更是高考的重点。为了更有效地帮助广大中学生牢固掌握基础知识，开阔学生的视野，本课程将基础知识和考试内容有机地结合在一起，按新课标的要求，将基础知识分解成章来编写，将每章的知识点列成目录形式，做到知识点简明扼要，重点突出，以点带面，步步提高。"],
            "bigImgUrl":"http://p.ananas.chaoxing.com/star/733_434c/1383036002754qarjn.jpg",
            "videoUrl":"",
            "courseChapter":[
                {
                    "物质的组成、性质与变化":[
                        {"chapterNum":"1.1", "chapterName":"高考要求"},
                        {"chapterNum":"1.2", "chapterName":"物质的组成"},
                        {"chapterNum":"1.3", "chapterName":"四个有关质量的概念辨析"},
                        {"chapterNum":"1.4", "chapterName":"同位素、同素异形体、同系物、同分异构体的区别和联系"},
                        {"chapterNum":"1.5", "chapterName":"物质的性质和变化"},
                        {"chapterNum":"1.6", "chapterName":"相关试题"}
                    ],
                    "物质的分类":[
                        {"chapterNum":"2.1", "chapterName":"高考要求"},
                        {"chapterNum":"2.2", "chapterName":"分类的重要性"},
                        {"chapterNum":"2.3", "chapterName":"常见分类方法"},
                        {"chapterNum":"2.4", "chapterName":"例题解析"},
                        {"chapterNum":"2.5", "chapterName":"相关试题"}
                    ],
                    "阿伏加德罗定律及其应用":[
                        {"chapterNum":"3.1", "chapterName":"高考要求"},
                        {"chapterNum":"3.2", "chapterName":"阿伏加德罗定律的内容"},
                        {"chapterNum":"3.3", "chapterName":"阿伏加德罗定律的应用"},
                        {"chapterNum":"3.4", "chapterName":"阿伏加德罗定律高考例题解析"},
                        {"chapterNum":"3.5", "chapterName":"高考中有关阿伏加德罗常数的考查"},
                        {"chapterNum":"3.6", "chapterName":"相关试题"}
                    ],
                    "氧化还原反应":[
                        {"chapterNum":"4.1", "chapterName":"高考要求"},
                        {"chapterNum":"4.2", "chapterName":"氧化还原反应中的规律及应用"},
                        {"chapterNum":"4.3", "chapterName":"氧化还原反应中的相关概念及考查"},
                        {"chapterNum":"4.4", "chapterName":"常见的氧化剂与还原剂及变价特点"},
                        {"chapterNum":"4.5", "chapterName":"陌生氧化还原反应方程式的书写"},
                        {"chapterNum":"4.6", "chapterName":"相关试题"}
                    ],
                    "化学反应与能量变化":[
                        {"chapterNum":"5.1", "chapterName":"高考要求"},
                        {"chapterNum":"5.2", "chapterName":"化学反应中的能量变化及盖斯定义的应用"},
                        {"chapterNum":"5.3", "chapterName":"热化学方程式的书写"},
                        {"chapterNum":"5.4", "chapterName":"燃烧热 中和热的概念"},
                        {"chapterNum":"5.5", "chapterName":"相关试题"}
                    ],
                    "中和热的测定":[
                        {"chapterNum":"6.1", "chapterName":"高考要求"},
                        {"chapterNum":"6.2", "chapterName":"中和热的测定实验"},
                        {"chapterNum":"6.3", "chapterName":"中和热测定例题解析"},
                        {"chapterNum":"6.4", "chapterName":"相关试题"}
                    ],
                    "胶体的性质和应用":[
                        {"chapterNum":"7.1", "chapterName":"高考要求"},
                        {"chapterNum":"7.2", "chapterName":"分散系"},
                        {"chapterNum":"7.3", "chapterName":"胶体的性质"},
                        {"chapterNum":"7.4", "chapterName":"胶体的应用及其他"},
                        {"chapterNum":"7.5", "chapterName":"例题解析"},
                        {"chapterNum":"7.6", "chapterName":"相关试题"}
                    ],
                    "溶液的概念及性质":[
                        {"chapterNum":"8.1", "chapterName":"高考要求"},
                        {"chapterNum":"8.2", "chapterName":"溶解平衡"},
                        {"chapterNum":"8.3", "chapterName":"饱和溶液与不饱和溶液"},
                        {"chapterNum":"8.4", "chapterName":"固体溶解度"},
                        {"chapterNum":"8.5", "chapterName":"气体溶解度"},
                        {"chapterNum":"8.6", "chapterName":"相关试题"}
                    ],
                    "离子反应及其应用":[
                        {"chapterNum":"9.1", "chapterName":"高考要求"},
                        {"chapterNum":"9.2", "chapterName":"涉及离子反应的相关概念辨析"},
                        {"chapterNum":"9.3", "chapterName":"离子共存"},
                        {"chapterNum":"9.4", "chapterName":"离子方程式正误判断"},
                        {"chapterNum":"9.5", "chapterName":"离子反应型的推断"},
                        {"chapterNum":"9.6", "chapterName":"与用量有关的离子方程式的书写"},
                        {"chapterNum":"9.7", "chapterName":"相关试题"}
                    ],
                    "物质的量":[
                        {"chapterNum":"10.1", "chapterName":"高考要求"},
                        {"chapterNum":"10.2", "chapterName":"物质的量及其计算"},
                        {"chapterNum":"10.3", "chapterName":"物质的量浓度及其应用"},
                        {"chapterNum":"10.4", "chapterName":"一定浓度溶液的配制和误差分析"},
                        {"chapterNum":"10.5", "chapterName":"相关试题"}
                    ]
                }
            ]
        },
        {
            "courseid":"87610130",
            "courseName":"高考化学知识点-元素化合物部分",
            "typeOne":"高考考点串讲",
            "typeTwo":"",
            "keySpeakName":"胡尚生",
            "keySpeakUnivercity":"北京二外附中",
            "keySpeakPosition":"特级教师",
            "keySpeakIntroduce":"研究领域：胡尚生北京二外附中化学特级教师，高级老师职称，安徽省化学会理事，全国高中化学新课程实施先进个人，亳州市学科带头人，亳州市优秀教师。论文与著作：他撰写的学术论文有多篇分别在《化学教育》《化学教学》《高中数理化》《黑龙江科技信息》《淮南师范学院学报》《青苹果》等学术期刊发表，还有多篇学术论文在国家和省市主管部门举行的论文评比中荣获一等奖；他主持两项省级课题均圆满结题，其中一项在安徽省优秀课题评比中荣获一等奖。荣誉与奖励：他是《1+1同步学习高中化学必修1》、《1+1同步学习高中化学必修2》《学教新思维》的主编。他辅导的学生21人次在安徽青少年科技创新论坛、安徽省青少年科技创新大赛奖、亳州市青少年科技创新大赛奖中获奖。",
            "courseIntroduce":["《普通高中化学课程标准(实验)》中明确规定了化学教学要从化学学科特点出发,结合素质教育的目标要求,倡导以科学探究为主的多元化学习方式,密切教学与社会、科技之间的联系.新课程标准为新时期的高中化学教学提出了新的工作要求,也给高中化学教学的理论和实践带来了新的挑战。","涵盖高考化学多个化学反应公式及化合物特性，根据高考化学试题综合程度高一题可能多考点的特点，将高考化学知识点分类进行整合,包括化学实验、化学常见反应公式等多个高考考点有利于高三考生有效进行高考化学复习。"],
            "bigImgUrl":"http://p.ananas.chaoxing.com/star/733_434c/1392081607505cgejf.jpg",
            "videoUrl":"",
            "courseChapter":[
                {
                    "钠及其化合物":[
                        {"chapterNum":"1.1", "chapterName":"钠单质及焰色反应"},
                        {"chapterNum":"1.2", "chapterName":"钠的氧化物和氢氧化物"},
                        {"chapterNum":"1.3", "chapterName":"碳酸钠和碳酸氢钠"}
                    ],
                    "铝及其化合物":[
                        {"chapterNum":"2.1", "chapterName":"镁单质和铝单质"},
                        {"chapterNum":"2.2", "chapterName":"氧化铝、氢氧化铝和偏铝酸钠的主要性质及应用"},
                        {"chapterNum":"2.3", "chapterName":"铝离子、氢氧化铝和偏铝酸根之间的转化关系"}
                    ],
                    "铁铜及其化合物":[
                        {"chapterNum":"3.1", "chapterName":"铁单质"},
                        {"chapterNum":"3.2", "chapterName":"铁的重要化合物"},
                        {"chapterNum":"3.3", "chapterName":"亚铁离子、铁离子的检验"},
                        {"chapterNum":"3.4", "chapterName":"铜及其重要化合物"}
                    ],
                    "碳硅及其化合物":[
                        {"chapterNum":"4.1", "chapterName":"碳及其重要化合物"},
                        {"chapterNum":"4.2", "chapterName":"硅及其重要化合物"},
                        {"chapterNum":"4.3", "chapterName":"硅酸盐及无机非金属材料"}
                    ],
                    "氮及其化合物":[
                        {"chapterNum":"5.1", "chapterName":"氮及其重要氧化物"},
                        {"chapterNum":"5.2", "chapterName":"氨与铵盐"},
                        {"chapterNum":"5.3", "chapterName":"硝酸及硝酸盐"}
                    ],
                    "硫及其化合物":[
                        {"chapterNum":"6.1", "chapterName":"硫及其重要氧化物"},
                        {"chapterNum":"6.2", "chapterName":"硫酸"},
                        {"chapterNum":"6.3", "chapterName":"硫酸的工业生产"}
                    ],
                    "氯及其化合物":[
                        {"chapterNum":"7.1", "chapterName":"氯单质及其重要化合物"},
                        {"chapterNum":"7.2", "chapterName":"氯气的制备"},
                        {"chapterNum":"7.3", "chapterName":"卤素及其化合物"}
                    ],
                    "元素及其化合物综合":[
                        {"chapterNum":"8.1", "chapterName":"无机推断专题"},
                        {"chapterNum":"8.2", "chapterName":"典型例题分析"},
                        {"chapterNum":"8.3", "chapterName":"高考例题解析"}
                    ]
                }
            ]
        },
        {
            "courseid":"87610079",
            "courseName":"高考化学知识点——有机化学部分",
            "typeOne":"高考考点串讲",
            "typeTwo":"",
            "keySpeakName":"白无瑕",
            "keySpeakUnivercity":"北京师范大学第二附属中学",
            "keySpeakPosition":"特级教师",
            "keySpeakIntroduce":"白无瑕 全国著名中学化学特级教师、北京市化学学科带头人，任教于北京师范大学第二附属中学，高考化学试题命题专家。",
            "courseIntroduce":["有机化学知识是历年高考必考内容之一，例如有机物的分类、结构与组成、有机反应类型、有机物的相互转化、有机物的制取和合成以及石油化工、煤化工等，考生历来把这一单元的考题作为得分项目，不会轻易放弃或疏忽，既使略有小错，也会懊丧不已。","本课程将有机化学知识和考试内容有机地结合在一起，按新课标的要求，将有机化学知识分解成章来编写，将每章的知识点列成目录形式，做到知识点简明扼要，重点突出，以点带面，步步提高。"],
            "bigImgUrl":"http://p.ananas.chaoxing.com/star/733_434c/1390633815115xwamn.jpg",
            "videoUrl":"",
            "courseChapter":[
                {
                    "有机化学的基础知识":[
                        {"chapterNum":"1.1", "chapterName":"高考要求"},
                        {"chapterNum":"1.2", "chapterName":"有机物的分类"},
                        {"chapterNum":"1.3", "chapterName":"有机物的分类 例题解析"},
                        {"chapterNum":"1.4", "chapterName":"有机物的命名"},
                        {"chapterNum":"1.5", "chapterName":"有机物的命名 例题解析"},
                        {"chapterNum":"1.6", "chapterName":"相对分子质量、有机分子式的确定"},
                        {"chapterNum":"1.7", "chapterName":"相对分子质量、有机分子式的确定 例题解析"},
                        {"chapterNum":"1.8", "chapterName":"分子式的不饱和度（不饱和键数）"},
                        {"chapterNum":"1.9", "chapterName":"有机分子结构表示方法"},
                        {"chapterNum":"1.10", "chapterName":"有机分子结构表示方法 例题解析"},
                        {"chapterNum":"1.11", "chapterName":"有机分子的空间构型及例题解析"}
                    ],
                    "同分异构体":[
                        {"chapterNum":"2.1", "chapterName":"高考要求"},
                        {"chapterNum":"2.2", "chapterName":"同分异构体和同系物、同种物质的区别及异构方式"},
                        {"chapterNum":"2.3", "chapterName":"同分异构体和同系物、同种物质的区别及异构方式 例题解析"},
                        {"chapterNum":"2.4", "chapterName":"同分异构体数目判断"},
                        {"chapterNum":"2.5", "chapterName":"同分异构体数目判断 例题解析"},
                        {"chapterNum":"2.6", "chapterName":"酯类有机物的同分异构体书写方法及例题解析"},
                        {"chapterNum":"2.7", "chapterName":"根据同分异构体的信息确定有机物结构及例题解析"}
                    ],
                    "烃及烃的衍生物的性质":[
                        {"chapterNum":"3.1", "chapterName":"高考要求"},
                        {"chapterNum":"3.2", "chapterName":"各类有机物具有的官能团和性质"},
                        {"chapterNum":"3.3", "chapterName":"各类有机物具有的官能团和性质 例题解析"},
                        {"chapterNum":"3.4", "chapterName":"常见官能团及例题解析"},
                        {"chapterNum":"3.5", "chapterName":"有机反应类型"},
                        {"chapterNum":"3.6", "chapterName":"有机反应类型 例题解析"}
                    ],
                    "糖类、氨基酸和蛋白质":[
                        {"chapterNum":"4.1", "chapterName":"高考要求"},
                        {"chapterNum":"4.2", "chapterName":"糖类"},
                        {"chapterNum":"4.3", "chapterName":"糖类 例题解析"},
                        {"chapterNum":"4.4", "chapterName":"氨基酸、蛋白质"},
                        {"chapterNum":"4.5", "chapterName":"氨基酸、蛋白质 例题解析"},
                        {"chapterNum":"4.6", "chapterName":"油脂"},
                        {"chapterNum":"4.7", "chapterName":"油脂 例题解析"}
                    ],
                    "有机合成":[
                        {"chapterNum":"5.1", "chapterName":"加聚反应和缩聚反应"},
                        {"chapterNum":"5.2", "chapterName":"加聚反应和缩聚反应 例题解析"},
                        {"chapterNum":"5.3", "chapterName":"有机物结构推断"},
                        {"chapterNum":"5.4", "chapterName":"有机物结构推断 例题解析"},
                        {"chapterNum":"5.5", "chapterName":"有机合成"},
                        {"chapterNum":"5.6", "chapterName":"有机合成 例题解析"}
                    ],
                    "有机实验":[
                        {"chapterNum":"6.1", "chapterName":"高考要求"},
                        {"chapterNum":"6.2", "chapterName":"有机混合物的分离和提纯"},
                        {"chapterNum":"6.3", "chapterName":"有机混合物的分离和提纯 例题解析"},
                        {"chapterNum":"6.4", "chapterName":"典型有机物的验证与鉴别"},
                        {"chapterNum":"6.5", "chapterName":"典型有机物的验证与鉴别 例题解析"},
                        {"chapterNum":"6.6", "chapterName":"重要有机实验"},
                        {"chapterNum":"6.7", "chapterName":"重要有机实验 例题解析"}
                    ]
                }
            ]
        },
        {
            "courseid":"87610027",
            "courseName":"高中地理高频考点分析——人文地理",
            "typeOne":"高考考点串讲",
            "typeTwo":"",
            "keySpeakName":"杨红",
            "keySpeakUnivercity":"北京市陈经纶中学",
            "keySpeakPosition":"特级教师",
            "keySpeakIntroduce":"研究领域：从教29年来，一直工作在教学一线，连续十年把关高三教学，多年参与高三高考模拟试题的命制。主编《新课程高考地理备考与活动教学》、《高中地理新课程有效教学创新设计》等专著。先后在《信息技术与课程整合》、《中国多媒体教学学报》、《中学地理教学参考》、《北京教育教学研究》、《考试》、《北京考试报》等杂志，发表了《中学地理多途径自主探究学习方式的研究》、《网络环境实践探究案例“城市交通运输”》、《地方课程与学生的成长发展》、《高考地理主干知识导学》、《运用简易天气图分析常见天气系统的特点》、《构建模式图探索地球上水的运动规律》、《研读2009高考试题确定2010备考策略》等论文和学术文章；承担市区级研究课题，“中学地理多途径自主探究学习方式的研究”获北京市基础教育教学成果奖二等奖，教学论文获国家级一等奖。多次完成市区级公开课，和省级、市区级专题讲座。荣誉与奖励：杨红，北京市陈经纶中学，地理特级教师，曾荣获北京市先进工作者、北京市优秀教师、北京市市级学科教学带头人、全国优秀中学地理教育工作者、全国优秀科技辅导员等荣誉称号。兼任北京市教育学会第八届理事会理事，朝阳区教育学会第七、八届理事会委员、理事，朝阳区教育学会中学地理教育分会会长，朝阳区地理兼职教研员，朝阳区高考模拟试题命题专家组成员。北京市陈经纶中学杨红获得的荣誉称号：2010年4月北京市先进工作者、2009年12月北京市特级教师、2009年3月全国优秀中学地理教育工作者、2007年12月北京市中学市级学科教学带头人、2006年9月北京市优秀教师、2004年12月北京市中学市级骨干教师、2001年7月北京市中学市级中青年骨干教师、2010年1月朝阳区教育系统学科带头人、2008年4月朝阳教育劳动奖章、2008年6月全国优秀科技辅导员、2011年6月全国优秀指导教师一等奖等。北京市陈经伦中学杨红获得的教育教学成果奖：2009年8月北京市基础教育教学成果奖、2006年12月朝阳区第二届教育教学成果奖、2011年12月朝阳区第七届教育教学提名奖、2012年12月朝阳区第八届教育教学成果奖。",
            "courseIntroduce":["人文地理，是探讨各种人文现象的地理分布、扩散和变化，以及人类社会活动的地域结构的形成和发展规律的一门学科，是地理学的两个主要分支学科之一。","“人文”二字与自然地理学的“自然”二字相对应，泛指各种社会、政治、经济和文化现象。人文地理学一般有广义与狭义之分，广义的人文地理学包括社会文化地理学、政治地理学、经济地理学等，狭义的人文地理学则指社会文化地理学。"],
            "bigImgUrl":"http://p.ananas.chaoxing.com/star/733_434c/1389927173777baika.jpg",
            "videoUrl":"",
            "courseChapter":[
                {
                    "课程概要":[],
                    "人口的变化":[
                        {"chapterNum":"2.1", "chapterName":"考点分析"},
                        {"chapterNum":"2.2", "chapterName":"不同人口增长模式的主要特点及地区分布"},
                        {"chapterNum":"2.3", "chapterName":"人口迁移的主要原因"},
                        {"chapterNum":"2.4", "chapterName":"环境承载力与人口合理容量的区别"},
                        {"chapterNum":"2.5", "chapterName":"地域文化对人口的影响"}
                    ],
                    "城市与城市化":[
                        {"chapterNum":"3.1", "chapterName":"考点分析"},
                        {"chapterNum":"3.2", "chapterName":"城市的空间结构及其形成原因"},
                        {"chapterNum":"3.3", "chapterName":"不同规模城市服务功能的差异"},
                        {"chapterNum":"3.4", "chapterName":"城市化的进程和特点"},
                        {"chapterNum":"3.5", "chapterName":"地域文化对城市的影响"}
                    ],
                    "生产活动与地域联系":[
                        {"chapterNum":"4.1", "chapterName":"考点分析"},
                        {"chapterNum":"4.2", "chapterName":"农业区位因素，主要农业地域类型特点及其形成条件"},
                        {"chapterNum":"4.3", "chapterName":"农业生产活动对地理环境的影响"}
                    ],
                    "工业生产活动与环境":[
                        {"chapterNum":"5.1", "chapterName":"考点分析"},
                        {"chapterNum":"5.2", "chapterName":"工业区位因素，工业地域的形成条件与发展特点"},
                        {"chapterNum":"5.3", "chapterName":"工业生产活动对地理环境的影响"}
                    ],
                    "人类地域联系与环境":[
                        {"chapterNum":"6.1", "chapterName":"考点分析"},
                        {"chapterNum":"6.2", "chapterName":"生产活动中地域联系的重要性和主要方式"},
                        {"chapterNum":"6.3", "chapterName":"交通运输方式和布局的变化对聚落空间形态和商业网点布局的影响"}
                    ],
                    "人类与地理环境的协调发展":[
                        {"chapterNum":"7.1", "chapterName":"考点分析"},
                        {"chapterNum":"7.2", "chapterName":"人地关系思想的历史演变——重点解读"},
                        {"chapterNum":"7.3", "chapterName":"人类所面临的主要环境问题"},
                        {"chapterNum":"7.4", "chapterName":"可持续发展的基本内涵，协调人地关系的主要途径"},
                        {"chapterNum":"7.5", "chapterName":"走可持续发展之路"}
                    ]
                }
            ]
        },
        {
            "courseid":"87609947",
            "courseName":"高考地理高频考点分析—把握新课标地理试题特点",
            "typeOne":"高考考点串讲",
            "typeTwo":"",
            "keySpeakName":"田佩淮",
            "keySpeakUnivercity":"清华大学附属中学",
            "keySpeakPosition":"特级教师",
            "keySpeakIntroduce":"田佩淮，男，1955年11月5日生，汉族，陕西省丹凤市人。清华附中高级教师，2000年被评为特级教师。研究领域：田佩淮老师长期从事中学地理教学的研究和实践，从教以来，担任19届高三毕业班地理教学，高考成绩优异，多次总评分获重点中学第一。近年来除担任高三教学外，在全国各地做多场关于高考复习讲座，深受师生欢迎。多次在CCTV10和一些网站做地理高考复习讲座。论文与著作：多篇文章发表在全国，省级刊物上，并多次获全国，省论文评比一，二等奖；参与并负责多项国家，省级教学科研课题；参加编写了教育部门主持的教辅书，优秀教案选若干。撰写有《中国中学生百科全书》《胜券在握》《高考讲练测》《历年高考试题精选解析》《考点大梳理》等多部书籍。承担北京市资金资助课题《促进学生多元智能发展的地理教学策略研究》，结题并受好评。荣誉与奖励：田佩淮，清华大学附属中学地理组组长，95年为市级教坛新星；获安徽省中青年地理优质课一等奖；98年市优秀教师，师德标兵；2000年为骨干教师国家级培训班学员，并被评为优秀学员；全国优秀地理教师。还是北京市特级教师，国家级骨干教师、中国地理学会会员，中国教育学会地理教学研究会会员。",
            "courseIntroduce":["2013年全国新课标版《考试大纲》地理学科与去年《考试大纲》相比略有变化：强调了“高考应具有较高的信度、效度，必要的区分度和适当的难度”。","本课程田佩淮老师将带领我们来认识新课程标准下的试题特点，然后介绍进入高三我们该“如何智慧复习获取高分？如何睿智答题获取高分？”在深入分析高考考点的同时，结合历年高考地理真题进行剖析、讲解。","高三复习要清楚两个问题，第一：现在高考考什么，在命题上有什么样的特色；第二：应对高考命题的特色我们应该怎么做，如何做我们才会取得更好的复习效率，我们在高三复习的过程中性价比才能更高。"],
            "bigImgUrl":"http://p.ananas.chaoxing.com/star/733_434c/1386039000191zteoj.jpg",
            "videoUrl":"",
            "courseChapter":[
                {
                    "智慧复习获取高分":[
                        {"chapterNum":"1.1", "chapterName":"试题中材料中的信息解读"},
                        {"chapterNum":"1.2", "chapterName":"图例表示的地理事物形成答题已知条件"},
                        {"chapterNum":"1.3", "chapterName":"图例与“设问”结合明确答题内容取向"},
                        {"chapterNum":"1.4", "chapterName":"答题警惕图例中“设置陷阱”"},
                        {"chapterNum":"1.5", "chapterName":"审题至“上” 信息为“王”"}
                    ],
                    "睿智答题获取高分":[
                        {"chapterNum":"2.1", "chapterName":"学会运用概念答题"},
                        {"chapterNum":"2.2", "chapterName":"相似情境迁移原理"},
                        {"chapterNum":"2.3", "chapterName":"描述事物特征要有答题思维模板"}
                    ],
                    "地球运动的地理意义":[
                        {"chapterNum":"3.1", "chapterName":"高考要求"},
                        {"chapterNum":"3.2", "chapterName":"晨昏线知识考查"},
                        {"chapterNum":"3.3", "chapterName":"区时的计算"},
                        {"chapterNum":"3.4", "chapterName":"正午太阳高度角变化"},
                        {"chapterNum":"3.5", "chapterName":"昼夜长短变化"},
                        {"chapterNum":"3.6", "chapterName":"相关试题"}
                    ],
                    "水循环和洋流":[
                        {"chapterNum":"4.1", "chapterName":"高考要求"},
                        {"chapterNum":"4.2", "chapterName":"水循环"},
                        {"chapterNum":"4.3", "chapterName":"水循环例题解析"},
                        {"chapterNum":"4.4", "chapterName":"洋流"},
                        {"chapterNum":"4.5", "chapterName":"洋流例题解析"},
                        {"chapterNum":"4.6", "chapterName":"相关试题"}
                    ],
                    "地表形态的变化":[
                        {"chapterNum":"5.1", "chapterName":"高考要求"},
                        {"chapterNum":"5.2", "chapterName":"地球的圈层结构及各圈层的主要特点及地壳内部物质循环过程"},
                        {"chapterNum":"5.3", "chapterName":"地表形态变化的内、外力因素"},
                        {"chapterNum":"5.4", "chapterName":"地质构造和人类生产"},
                        {"chapterNum":"5.5", "chapterName":"著名山系及火山、地震分布与板块运动的关系"},
                        {"chapterNum":"5.6", "chapterName":"相关试题"}
                    ],
                    "自然环境的整体性和差异性":[
                        {"chapterNum":"6.1", "chapterName":"高考要求"},
                        {"chapterNum":"6.2", "chapterName":"整体性和差异性"},
                        {"chapterNum":"6.3", "chapterName":"纬度地带性"},
                        {"chapterNum":"6.4", "chapterName":"经度地带性"},
                        {"chapterNum":"6.5", "chapterName":"垂直地带性"},
                        {"chapterNum":"6.6", "chapterName":"相关试题"}
                    ],
                    "锋面和气旋":[
                        {"chapterNum":"7.1", "chapterName":"高考要求"},
                        {"chapterNum":"7.2", "chapterName":"主干知识梳理"},
                        {"chapterNum":"7.3", "chapterName":"锋面与天气"},
                        {"chapterNum":"7.4", "chapterName":"相关试题"}
                    ],
                    "大气热力性质和运动":[
                        {"chapterNum":"8.1", "chapterName":"高考要求"},
                        {"chapterNum":"8.2", "chapterName":"对流层大气大气受热过程"},
                        {"chapterNum":"8.3", "chapterName":"热力环流和大气水平运动"},
                        {"chapterNum":"8.4", "chapterName":"相关试题"}
                    ],
                    "风带气压带和季风":[
                        {"chapterNum":"9.1", "chapterName":"高考要求"},
                        {"chapterNum":"9.2", "chapterName":"三圈环流"},
                        {"chapterNum":"9.3", "chapterName":"七带六风"},
                        {"chapterNum":"9.4", "chapterName":"海陆对气压带、风带的破坏和季风形成"},
                        {"chapterNum":"9.5", "chapterName":"相关试题"}
                    ],
                    "经纬网知识":[
                        {"chapterNum":"10.1", "chapterName":"高考要求"},
                        {"chapterNum":"10.2", "chapterName":"经纬网定方向"},
                        {"chapterNum":"10.3", "chapterName":"利用经纬网量算距离"},
                        {"chapterNum":"10.4", "chapterName":"经纬网例题讲解"},
                        {"chapterNum":"10.5", "chapterName":"相关试题"}
                    ]
                }
            ]
        }
      ]
    };