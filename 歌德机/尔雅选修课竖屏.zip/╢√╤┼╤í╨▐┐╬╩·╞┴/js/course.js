
// JavaScript Document
var bookstr="";
bookstr+='<div class="liDtail" style="display: none">';
for(var book=0; book<books.list.length;book++){
    bookstr+='<div class="source"><a><input type="hidden" value="'+books.list[book].courseid+'"><dl><dt><img src="'+books.list[book].bigImgUrl+'"></dt><dd class="sourceNameOne">'+books.list[book].courseName+'</dd><dd class="speakName">'+books.list[book].keySpeakPosition+' （'+books.list[book].keySpeakUnivercity+'）</dd></dl></a></div>';

    if(book>0){
        var chaoDaiType0=books.list[book].typeOne;
        var chaoDaiType1=books.list[book-1].typeOne;
    }

    if(chaoDaiType0!=chaoDaiType1){
        bookstr+='</div><div class="liDtail" style="display: none">';
    }
}
bookstr+='</div>';
$("#tab_box").append(bookstr);

var jsonName;
function gainVideoList(id){
  var  listStr="";
    for(var key in books.list){
        if(books.list[key].courseid==id){
            listStr+="<div class='contentL'>";
            listStr+="<div class='source'>";
            listStr+="<img src='"+books.list[key].bigImgUrl+"'>";
            listStr+="<div class='sourceName'>";
            listStr+="<h1 title='"+books.list[key].courseName+"'>"+books.list[key].courseName+"</h1>";
            listStr+="<span>"+books.list[key].keySpeakName+"</span>";
            listStr+="</div>";
            listStr+="</div>";

            listStr+="<div class='speakMes'>";
            listStr+="<img src='QR_codes/"+books.list[key].courseid+".png'>";
            listStr+=" <p>主讲人："+books.list[key].keySpeakName+"</p>";
            listStr+=" <p>主讲人："+books.list[key].keySpeakUnivercity+"</p>";
            listStr+=" <p>主讲人信息：</p>";
            listStr+=" <p class='speakIntro'>"+books.list[key].keySpeakIntroduce+"</p>";
            for(var i=0; i< books.list[key].courseIntroduce.length;i++){
                listStr+=" <p class='speakIntro'>"+books.list[key].courseIntroduce[i]+"</p>";
            }
            listStr+="</div>";
            listStr+="</div>";

            listStr+="<div class='contentR'>";
            listStr+="<h2>课程章节</h2>";
            var tittle=books.list[key].courseChapter;
            for(var key1 in tittle){
                var m=1;
                  for(var key2 in tittle[key1]){
                      console.log(key2);
                      listStr+="<div class='catalog'>";
                      listStr+="<div class='firstCatalog'>";
                      listStr+="<a href=''>";
                      listStr+="<div class='numOne'>"+m+"</div>";
                      listStr+="<div class='tittleOne'>"+key2+"</div>";
                      listStr+="</a>";
                      listStr+=" <div class='clear'></div>";
                      listStr+="</div>";
                      listStr+="<ul>";
                      var tittleOne=tittle[key1][key2];
                      for(var key3 in tittleOne){
                          listStr+="<li>";
                          listStr+="<a href=''>";
                          listStr+="<div class='num'>"+tittleOne[key3].chapterNum+"</div>";
                          listStr+="<div class='tittle'>"+tittleOne[key3].chapterName+"</div>";
                          listStr+="</a>";
                          listStr+="</li>";
                      }


                      listStr+="</ul>";
                      listStr+="<div class='clear'></div>";
                      listStr+="</div>";
                      m++;
                  }

            }
            $(".contentOne").html(listStr);
        }
    }

}

pager(12,1,5,'data.js');