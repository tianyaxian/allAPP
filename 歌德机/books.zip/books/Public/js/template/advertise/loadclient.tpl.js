(function(){

etdk["tpl"] = etdk["tpl"] || {};

etdk["tpl"] ["crab_child"] = _.template("<div class='footer_children absolute'><img src='<%=etdk.g._IMG_%>/children.png'/></div>");

etdk["tpl"] ["ship_cloud"] = _.template("<div class='footer_ship absolute'><img src='<%=etdk.g._IMG_%>/ship.png'/></div><div class='footer_wave absolute'></div>");

})();